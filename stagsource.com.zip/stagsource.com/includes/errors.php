<?php
/*********************************************************************************************
	Author 	: V V VIJESH
	Date	: 08-Nov-2010
	Purpose	: Constant value definition
*********************************************************************************************/
	// Error Constant
	define("ER_00001", "Error!");
	define("ER_00002", "Javasript is currently not supported/disabled by this browser. Please enable JavaScript for full functionality.");
	define("ER_00003", "Coming Soon..");
	
?>