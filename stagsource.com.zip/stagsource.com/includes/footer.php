</div>
			</div>
			<div id="left_bttm"><img src="images/left_bttm.jpg" /></div>
		</div>
		<div id="right">
			<div id="right_box">
				<div id="home_animation2">
					<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="211" height="165">
						<param name="movie" value="animation/animation2.swf" />
						<param name="quality" value="high" />
						<embed src="animation/animation2.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="211" height="165"></embed>
					</object>
				</div>
			</div>
			<div id="right_box_space"></div>
			<div id="right_box">
				<div id="home_animation2">
					<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="195" height="145">
						<param name="movie" value="animation/animation3.swf" />
						<param name="quality" value="high" />
						<embed src="animation/animation3.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="195" height="145"></embed>
					</object>
				</div>
			</div>
			<div id="right_box_space"></div>
			<div id="right_box"> <span class="red"><a href="about.html"><br />
				About Us </a></span><br />
				<br />
				Experienced <br />
				<br />
				Trusted Professionals <br />
				<br />
				Friendly Staff</div>
			<div id="right_box_space"></div>
			<div id="right_box1"> <span class="red"><a href="contact.html">Contact Us</a></span> <br />
				(602) 553-8122 (office)<br />
				(855) 553-8122 (toll free)<br />
				(602) 957-1582 (fax)<br />
				9:00AM - 6:00 PM (M-F)<br />
				<a href="mailto:info@legalresourceonline.com" class="red">info@legalresourceonline.com</a></div>
		</div>
	</div>
	<div id="bttm"><img src="images/bttm.jpg" /></div>
	<div id="footer_space"></div>
</div>
</body>
</html>
