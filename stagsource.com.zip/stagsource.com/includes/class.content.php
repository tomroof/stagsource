<?php
/*********************************************************************************************
	Author 	: V V VIJESH
	Date	: 14-April-2011
	Purpose	: Content class
*********************************************************************************************/
    class content
	{
		protected	$_properties		= array();
		public		$error				= '';
		public		$message			= '';
		public		$warning			= '';
		private		$no_content_option	= array();
		
		public $content_type_array		= array('article'=>'Article', 'product'=>'Product', 'qoute'=>'Quote', 'question_answer'=>'Question Answer', 'community'=>'Community', 'vendor'=>'Vendor', 'facebook'=>'Facebook', 'twitter'=>'Twitter', 'instagram'=>'Instagram', 'poll'=>'Poll', 'picture_poll'=>'Picture Poll', 'video'=>'Video', 'image'=>'Image', 'slideshow_album'=>'Slide show album', 'dancer'=>'Dancer', 'event'=>'Event');

        function __construct($content_id = 0)
		{
            $this->error	= '';
			$this->message	= '';
			$this->warning	= false;
			
			if($content_id > 0 || $content_id != '')
			{
				$this->initialize($content_id);
			}
        }
		
		function __get($property_name)
        {
			if (array_key_exists($property_name, $this->_properties))
			{
				return $this->_properties[$property_name];
			}

			return null;
        }

		public function __set($property_name, $value)
		{
			return $this->_properties[$property_name] = $value;
		}
		
		public function __destruct() 
		{
			unset($this->_properties);
			unset($this->error);
			unset($this->message);
		}
		
		//Initialize object variables.
		private function initialize($content_id)
		{
			$database	= new database();
			
			
			if(is_numeric( $content_id ))
			{
				$sql	= "SELECT *	 FROM content WHERE content_id = '$content_id'";
			}
			else
			{
				$sql	= "SELECT *	 FROM content WHERE seo_url = '$content_id'";
			}
			//print $sql;
			$result		= $database->query($sql);
			
			if ($result->num_rows > 0)
			{
				$this->_properties	= $result->fetch_assoc();
			}
		}
		
		// Save the Content details
		public function save()
		{
			$database	= new database();
			if(!$this->check_content_exist($this->name, $this->content_id) && !$this->check_seo_url_exist($this->seo_url, $this->content_id))
			{
				if ( isset($this->_properties['content_id']) && $this->_properties['content_id'] > 0) 
				{
					$sql	= "UPDATE content SET 
								name = '". $database->real_escape_string($this->name)  ."',
								category_id = '". $database->real_escape_string($this->category_id)  ."',
								seo_url = '". $database->real_escape_string($this->seo_url)  ."',
								title = '". $database->real_escape_string($this->title)  ."',
								meta_description = '". $database->real_escape_string($this->meta_description)  ."',
								meta_keywords = '". $database->real_escape_string($this->meta_keywords)  ."',
								content = '". $database->real_escape_string($this->content)  ."',
								author = '". $database->real_escape_string($this->author)  ."',
								modified_date = NOW() 
								WHERE content_id = '$this->content_id'";
				}
				else 
				{
					$sql		= "INSERT INTO content 
								(name,category_id, seo_url, title, meta_description, meta_keywords, content, author, added_date, modified_date, order_id) 
								VALUES ('" . $database->real_escape_string($this->name) . "',
										'" . $database->real_escape_string($this->category_id) . "',
										'" . $database->real_escape_string($this->seo_url) . "',
										'" . $database->real_escape_string($this->title) . "',
										'" . $database->real_escape_string($this->meta_description) . "',
										'" . $database->real_escape_string($this->meta_keywords) . "',
										'" . $database->real_escape_string($this->content) . "',
										'" . $database->real_escape_string($this->author) . "',
										NOW(),
										NOW(),
										'" . $database->real_escape_string($this->order_id) . "'
										)";
				}
				//print $sql;
				$result			= $database->query($sql);
				
				if($database->affected_rows == 1)
				{
					if($this->content_id == 0)
					{
						$this->content_id	= $database->insert_id;
					}
				}
				$this->initialize($this->content_id);
				$this->message = cnst11;
				return true;
			}
			else
			{
				return false;	
			}
		}
		
		//The function check the content name exist or not
		public function check_content_exist($name='', $content_id=0)
		{
			$output		= false;
			$database	= new database();
			if($name == '')
			{
				$this->message	= "Page name should not be empty!";
				$this->warning	= true;
			}
			else
			{
				if($content_id > 0)
				{
					$sql	= "SELECT *	 FROM content WHERE name = '" . $database->real_escape_string($name) . "' AND content_id != '" . $content_id . "'";
				}
				else
				{
					$sql	= "SELECT *	 FROM content WHERE name = '" . $database->real_escape_string($name) . "'";
				}
				//print $sql;
				$result 	= $database->query($sql);
				if ($result->num_rows > 0)
				{
					$this->message	= "Page name is already exist!";
					$this->warning	= true;
					$output 		= true;
				}
				else
				{
					$output			= false;
				}
			}
			return $output;	
		}
		
		//The function check the seo url exist or not
		public function check_seo_url_exist($seo_url='', $content_id=0)
		{
			$output		= false;
			$database	= new database();
			if($seo_url == '')
			{
				$this->message	= "SEO URL should not be empty!";
				$this->warning	= true;
			}
			else
			{
				if($content_id > 0)
				{
					$sql	= "SELECT *	 FROM content WHERE seo_url = '" . $database->real_escape_string($seo_url) . "' AND content_id != '" . $content_id . "'";
				}
				else
				{
					$sql	= "SELECT *	 FROM content WHERE seo_url = '" . $database->real_escape_string($seo_url) . "'";
				}
				//print $sql;
				$result 	= $database->query($sql);
				if ($result->num_rows > 0)
				{
					$this->message	= "SEO URL is already exist!";
					$this->warning	= true;
					$output 		= true;
				}
				else
				{
					$output			= false;
				}
			}
			return $output;	
		}
		
		// Remove the current object details.
		public function remove()
		{
			$database	= new database();
			if ( isset($this->_properties['content_id']) && $this->_properties['content_id'] > 0) 
			{
				$sql = "DELETE FROM content WHERE content_id = '" . $this->content_id . "'";
				try
				{
					if($result 	= $database->query($sql)) 
					{
						if ($database->affected_rows > 0)
						{
							$this->message = cnst12;	// Data successfully removed!
						}
					}
					else 
					{
						throw new Exception(cnst13);	// Selected record is not found!
					}
				}
				catch (Exception $e)
				{
					$this->message	= "Exception: ".$e->getMessage();
					$this->warning	= true;
				}
			}
		}
		
		// Remove selected items
		public function remove_selected($content_ids)
		{
			$database	= new database();
			if(count($content_ids)>0)
			{		
				foreach($content_ids as $content_id)
				{
					$content		= new content($content_id);
					$image_seo_url = $content->image_name;
					if(file_exists(DIR_NEWS . $image_name))
					{
						unlink(DIR_NEWS . $image_name);
					}
					if(file_exists(DIR_NEWS . 'thumb_' . $image_name))
					{
						unlink(DIR_NEWS . 'thumb_' . $image_name);
					}
					
					$sql = "DELETE FROM content WHERE content_id = '" . $content_id . "'";
					try
					{
						if($result 	= $database->query($sql)) 
						{
							if ($database->affected_rows > 0)
							{
								$this->message = cnst12;	// Data successfully removed!
							}
						}
						else 
						{
							throw new Exception(cnst13);	// Selected record is not found!
						}
					}
					catch (Exception $e)
					{
						$this->message	= "Exception: ".$e->getMessage();
						$this->warning	= true;
					}							   
				}		  		   
			}
		}
		
		public function get_my_content()
		{
			$database	= new database();
			$title	= $_SESSION[MEMBER_ID];
			$sql		= "SELECT * FROM content WHERE title = $title ORDER BY content_date DESC";
			$result		= $database->query($sql);
			$idate		= 0;
			if ($result->num_rows > 0)
			{	
				while($data=$result->fetch_object())
				{
					$i++;
					$content_serial_value++;
					$row_num++;
			      	$class_name= (($row_type%2) == 0) ? "even" : "odd";	
					
					$idate			= explode('-', $data->content_date);
				  	$content_date	= $idate[2] . '-' .  $idate[1] . '-' . $idate[0];
					echo "<tr>
							<td align='center'>$i</td>
							<td>$content_date</td>
							<td>$data->description</td>
							<td><a href='$data->content_url' target='_blank'><img src='images/view-content.png' border='0' title='View'></a></td>
						</tr>";
				}
			}
			else
			{
				echo "<tr><td colspan='4' align='center'>Sorry.. No records found !!</td></tr>";
			}
		}
		
		public function display_list()
		{
			$database				= new database();
			$validation				= new validation(); 
			$param_array			= array();
			$sql					= "SELECT * FROM content ";
			$drag_drop				= '';
			
			//$search_cond_array[]	= " title = '$this->title' ";
			//$param_array[]			= "title=$this->title";
			if(isset($_REQUEST['search_word']) || $_REQUEST['category_id'] > 0 ) 
			{
				$search_word	= functions::clean_string($_REQUEST['search_word']);
				if(!empty($search_word))
				{
					$validation->check_blank($search_word, 'Search word', 'search_word');					
					if (!$validation->checkErrors())
					{
						$param_array[]			= "search=true";
						$param_array[]			= "search_word=" . htmlentities($search_word);
						$search_cond_array[]	= " name like '%" . $database->real_escape_string($search_word) . "%' OR title like '%" . $database->real_escape_string($search_word) . "%' OR seo_url like '%" . $database->real_escape_string($search_word) . "%'";	
					}
				}
				
				if($_REQUEST['category_id'] > 0)
				{
						$param_array[]="category_id =".$_REQUEST['category_id'];			
						$search_cond_array[]="category_id  = '".$database->real_escape_string($_REQUEST['category_id'])."'";		
				}
				// Drag and dorp ordering is not available in search
				$drag_drop 						= ' nodrag nodrop ';
			}
			
			if(count($search_cond_array)>0) 
			{ 
				$search_condition	= " WHERE ".join(" AND ",$search_cond_array); 
				$sql				.= $search_condition;
			}
						
			$sql 			= $sql . " ORDER BY created_date DESC, content_id DESC";
			$result			= $database->query($sql);
			
			$this->num_rows = $result->num_rows;
			functions::paginate($this->num_rows);
			$start			= functions::$startfrom;
			$limit			= functions::$limits;
			$sql 			= $sql . " limit $start, $limit";
			$result			= $database->query($sql);
			
			$param=join("&amp;",$param_array); 
			$this->pager_param=$param;
			
			if ($result->num_rows > 0)
			{				
				$i 			= 0;
				$row_num	= functions::$startfrom;
				$page		= functions::$startfrom > 0 ? (functions::$startfrom / PAGE_LIMIT) + 1 : 1;
				
			   	echo '
				<tr class="lightColorRow nodrop nodrag" style="display:none;">
					<td colspan="9"  class="noBorder">
						<input type="hidden" id="show"  name="show" value="0" />
               			<input type="hidden" id="content_id" name="content_id" value="0" />
						<input type="hidden" id="show_content_id" name="show_content_id" value="0" />
						<input type="hidden" id="num_rows" name="num_rows" value="' . $result->num_rows . '" />
						<input type="hidden" id="page" name="page" value="' . $page . '" />
					</td>
                </tr>';
				
				while($data=$result->fetch_object())
				{
					$i++;
					$content_serial_value++;
					$row_num++;
			      	$class_name= (($row_type%2) == 0) ? "even" : "odd";	
					$status			= $data->status == 'Y' ? 'Active' : 'Inactive';
					$status_image	= $data->status == 'Y' ? 'icon-active.png' : 'icon-inactive.png';
					
					$show_menu			= $data->show_menu == 'Y' ? 'Active' : 'Inactive';
					$show_menu_image	= $data->show_menu == 'Y' ? 'icon-active.png' : 'icon-inactive.png';
					$category			= new category($data->category_id);
					
					echo '
						<tr id="' . $data->content_id . '" class="' . $class_name . $drag_drop . '" >
							<td class="alignCenter pageNumberCol">' . $row_num . '</td>
							<td class="noBorder handCursor" onclick="javascript: open_content_details(\''.$data->content_id.'\',\'details_div_'.$i.'\',false,\'\',\''.$content_serial_value.'\');"  title="Click here to view details">' . functions::deformat_string($data->name) . '</td>
							<td class="noBorder " >' . functions::deformat_string($category->name) . '</td>';
							//<td class="widthAuto"><a href="#" title="Click here to view details" onClick="javascript:open_content_details(\''.$data->content_id.'\',\'details_div_'.$i.'\',false,\'\',\''.$content_serial_value.'\');return false;">' . functions::deformat_string($data->name) . '</a></td>
							
						echo '<td class="widthAuto">'. $data->seo_url .'<!--<a href="'. URI_ROOT .  $data->seo_url .'" target="_blank"><img  src="images/external_link.png"></a>--></td>
							<!--<td class="alignCenter">'.  functions::get_format_date($data->modified_date, "d-m-Y") .'</td>-->
							<td class="alignCenter">';
							
								if(!in_array($data->content_id, $this->no_content_option) && $data->content_id > 4)
								{
									/*echo '<a href="manage_content_option.php?content_id=' . $data->content_id . '"><img src="images/icon-content_option.png" alt="Option" title="Option" width="15" height="16" /></a>';*/
								}
								echo '
							</td>
							<td class="alignCenter">';
							if($data->status_edit == 'Y')
							{
								echo '<a title="Click here to update status" class="handCursor" onclick="javascript: change_content_status(\'' . $data->content_id . '\', \'' . $i . '\');" ><img id="status_image_' . $i . '" src="images/' . $status_image . '" alt ="' . $status  . '" title ="' . $status  . '"></a>';
							}
							else if($data->content_id < 5)
							{
								echo '<img id="status_image_' . $i . '" src="images/' . $status_image . '" alt ="' . $status  . '" title ="' . $status  . '">';	
							}
							echo '</td>
							<td class="alignCenter">';
							if($data->show_menu_edit == 'Y')
							{
								echo '<a title="Click here to update menu option" class="handCursor" onclick="javascript: change_menu_option(\'' . $data->content_id . '\', \'' . $i . '\');" ><img id="menu_option_image_' . $i . '" src="images/' . $show_menu_image . '" alt ="' . $show_menu  . '" title ="' . $show_menu  . '"></a>';
							}
							/*else
							{
								echo '<img id="menu_option_image_' . $i . '" src="images/' . $show_menu_image . '" alt ="' . $show_menu  . '" title ="' . $show_menu  . '">';	
							}*/
							echo '</td>
							<td class="alignCenter">
								<!--<a href="register_content.php?content_id=' . $data->content_id . '"><img src="images/icon-edit.png" alt="Edit" title="Edit" width="15" height="16" /></a>-->
							</td>
							<td class="alignCenter deleteCol">';
							if($data->status_edit == 'Y')
							{
								echo '
								<!--<label><input type="checkbox" name="checkbox[' . $data->content_id . ']" id="checkbox" /></label>-->';
							}
							echo '</td>
						</tr>
						<tr id="details'.$i.'" class="expandRow" >
								<td id="details_div_'.$i.'" colspan="10" height="1" ></td>
							</tr>
						';
					$row_type++;
				}
				$param=join("&amp;",$param_array); 
				$this->pager_param=$param;
			}
			else
			{
				$this->pager_param1 = join("&",$param_array);
				if(isset($_GET['page']))
				{
					$currentPage = $_GET['page'];
				}
				if($currentPage>1)
				{
					$currentPage = $currentPage-1;
					if($this->pager_param=="")
					{
						$urlQuery = 'manage_content.php?page='.$currentPage;
					}
					else
					{
						$urlQuery = 'manage_content.php?'.$this->pager_param1.'&page='.$currentPage;	
					}
					functions::redirect($urlQuery);
				}
				else
				{
					echo "<tr><td colspan='7' align='center'><div align='center' class='warningMesg'>Sorry.. No records found !!</div></td></tr>";
				}
			}
		}
		
		// The function is used to change the status.
		public static function update_status($content_id, $status = '')
		{		
			$database		= new database();
			$content			= new content($content_id);
			//$current_status = $content->status;
			if($status == '')
			{
				$status =  $content->status == 'Y' ? 'N' : 'Y';
			}
			
			$sql		= "UPDATE content 
						SET status = '". $status . "'
						WHERE content_id = '" . $content_id . "'";
			$result 	= $database->query($sql);
			return $status;
		}
		
		// The function is used to change the status.
		public static function update_show_menu($content_id, $show_menu = '')
		{		
			$database		= new database();
			$content		= new content($content_id);
			//$current_show_menu = $content->show_menu;
			if($show_menu == '')
			{
				$show_menu =  $content->show_menu == 'Y' ? 'N' : 'Y';
			}
			
			$sql		= "UPDATE content 
						SET show_menu = '". $show_menu . "'
						WHERE content_id = '" . $content_id . "'";
			$result 	= $database->query($sql);
			return $show_menu;
		}
		
		public static function get_breadcrumbs($title, $client_side=false)
		{
			if($client_side)
			{
				$bread_crumb[]			= "<a href='tutorial.php'>Gallery</a>";
			}
			else
			{		
				$page_id				= page::get_page_id('manage_tutorial.php');	// Get the page id
				$page					= new page($page_id);
				$bread_crumb[]			= "<a href='". functions::deformat_string($page->name) ."'>" . functions::deformat_string($page->description) . "</a>";
			}
			
			$tutorial_category 		= new tutorial_category($title);
			$bread_crumb[]			= functions::deformat_string($tutorial_category->name);
			
			if(count($bread_crumb)>0)
			{
				$bread_crumbs=join(" >> ",$bread_crumb);
			}
			return $bread_crumbs;
		}
		
		// Functoion update the list order
		public function update_list_order($list_array, $page_number)
	{
		$database		= new database();
		$limit			= PAGE_LIMIT;
		$id_array		= array();
		
		//print_r($list_array);
		
		foreach ($list_array as $id)
		{
			if($id == '')
			{
				continue;
			}
			$id_array[] = $id;
		}
		
		//print_r($id_array);
		if($page_number > 1)
		{
			$order_id = (($page_number - 1) * PAGE_LIMIT) + 1 ; //1
		}
		else
		{
			$order_id = count($id_array);
		}
		
		//echo count($id_array);
		for($i = 0; $i < count($id_array); $i++ )
		{
			$sql = "UPDATE content SET order_id = '" . $order_id . "' WHERE content_id = '" . $id_array[$i] . "'";
			echo $sql;
			$database->query($sql);
			$order_id++;
		}
	}
	
		
		public static function get_latest_list($count = 0)
		{
			$database			= new database();
			$portfolio_array 	= array();
			if($count > 0)
			{
				$sql	= "SELECT * FROM content ORDER BY content_date DESC Limit 0, $count";
			}
			else
			{
				$sql	= "SELECT * FROM content ORDER BY content_date DESC";
			}
			//print $sql;
			$result				= $database->query($sql);
			if ($result->num_rows > 0)
			{
				while($data = $result->fetch_object())
				{
					?>
					<div class="content">
					<?php echo functions::get_sub_string(functions::deformat_string($data->description),180); ?> <a href="content.php#content<?php echo $data->content_id; ?>">Read more</a>
					</div>
					<?php
				}
			}
		}
		
		public static function get_menu($static_menu = '')
		{
			$database			= new database();
			$portfolio_array 	= array();
			$sql				= "SELECT * FROM content WHERE  show_menu = 'Y' AND status = 'Y' ORDER BY name DESC";
			//print $sql;
			$result				= $database->query($sql);
			echo '<ul><li><a href="' . URI_ROOT . '">Home</a></li>';
			if ($result->num_rows > 0)
			{
				while($data = $result->fetch_object())
				{
					?>
					<li><a href="<?php echo functions::deformat_string($data->seo_url); ?>"><?php echo functions::deformat_string($data->name); ?></a></li>
					<?php
				}
			}
			echo $static_menu . '</ul>';
		}
		
		public static function get_random_content()
		{
			$database	= new database();
			$sql		= "SELECT * FROM content ORDER BY Rand() Limit 0, 1";
			//print $sql;
			$result		= $database->query($sql);
			if ($result->num_rows > 0)
			{
				$data = $result->fetch_object();
				echo functions::deformat_string($data->description);
			}
		}
		
		public function get_content_list()
		{
			$database			= new database();
			$param_array		= array();
			$search_condition	= '';
			$sql 				= "SELECT * FROM content";
					
			$sql				.= $search_condition;
			$sql 				= $sql . " ORDER BY content_date DESC";
			$result				= $database->query($sql);
			
			$this->num_rows = $result->num_rows;
			//functions::paginate($this->num_rows);
			functions::paginateclient($this->num_rows, 0, 0, 'CLIENT');
			$start			= functions::$startfrom;
			$limit			= functions::$limits;
			$sql 			= $sql . " limit $start, $limit";
			//print $sql;
			$result			= $database->query($sql);
			
			$param=join("&amp;",$param_array); 
			$this->pager_param=$param;
			
			$content_array		= array();
			if ($result->num_rows > 0)
			{				
				$i 			= 0;
				$row_num	= functions::$startfrom;
				$page		= functions::$startfrom > 0 ? (functions::$startfrom / FRONT_PAGE_LIMIT) + 1 : 1;			
				while($data=$result->fetch_object())
				{
					$i++;
					
					if($i != 1)
					{
						echo '<div id="content_content_crossline"></div>';	
					}
					
					?>
					<a name="content<?php echo $data->content_id; ?>"></a>
					<div id="content_black_heading">
						<div id="content_white_area">
							<div id="content_image"><img src="<?php echo URI_NEWS . 'thumb_' . $data->image_name; ?>" /></div>
							<div id="content_date"><?php echo functions::get_format_date($data->content_date, "dS M");	?></div>
						</div>
						<div id="content_black_area">
							<div id="affliates_content">
								<h1><?php echo functions::deformat_string($data->title); ?></h1>
								<?php echo nl2br(functions::deformat_string($data->description)); ?>	
							</div>
						</div>
					</div>
					<?php
				}
				$param=join("&amp;",$param_array); 
				$this->pager_param=$param;
			}
			else
			{
				echo "<div align='center' class='warningMesg'>Sorry.. No records found !!</div>";
			}
		}
			
		
		public function get_article_big_array()
		{
			$big_array		= array();
			$database		= new database();
			$sql 			= "SELECT * FROM content WHERE content_type='article' AND image_size='1' AND status='Y' ORDER BY content_id DESC";
			$result				= $database->query($sql);
			if ($result->num_rows > 0)
			{
				while($data=$result->fetch_object())
				{
					$big_array[] 	= $data->content_id;	
					$image_name 	= $data->content_thumbnail;
					if(!file_exists(DIR_CONTENT.'thumb_'.$image_name) && $image_name != '')
					{	
						$size_1	= getimagesize(DIR_CONTENT.$image_name);
						$imageLib = new imageLib(DIR_CONTENT.$image_name);
						//$imageLib->resizeImage(BOOK_MIN_WIDTH, BOOK_MIN_HEIGHT,3);
						/*if($size_1[0] > $size_1[1])
						{
							$imageLib->resizeImage(BOOK_MIN_WIDTH, BOOK_MIN_HEIGHT, 2);
						}
						else if($size_1[0] < $size_1[1])
						{
							$imageLib->resizeImage(BOOK_MIN_WIDTH, BOOK_MIN_HEIGHT, 1);
						}
						else
						{
							$imageLib->resizeImage(BOOK_MIN_WIDTH, BOOK_MIN_HEIGHT, 3);	
						}*/
						$imageLib->resizeImage(CONTENT_BIG_THUMB_WIDTH, CONTENT_BIG_THUMB_HEIGHT, 0);	
						$imageLib->saveImage(DIR_CONTENT.'thumb1_'.$image_name, 90);
						unset($imageLib);
					}
				}
			}
			
			return $big_array;
			
		}
		
		
		public function get_article_small_array()
		{
			$small_array		= array();
			$database		= new database();
			$sql 			= "SELECT * FROM content WHERE content_type='article' AND image_size='0' AND status='Y' ORDER BY content_id DESC";
			$result				= $database->query($sql);
			if ($result->num_rows > 0)
			{
				while($data=$result->fetch_object())
				{
					$small_array[] = $data->content_id;
					$image_name 	= $data->content_thumbnail;
					
					if(!file_exists(DIR_CONTENT.'thumb_'.$image_name) && $image_name != '')
					{	
						$size_1	= getimagesize(DIR_CONTENT.$image_name);
						$imageLib = new imageLib(DIR_CONTENT.$image_name);
						
						$imageLib->resizeImage(CONTENT_SMALL_THUMB_WIDTH, CONTENT_SMALL_THUMB_HEIGHT, 0);	
						$imageLib->saveImage(DIR_CONTENT.'thumb1_'.$image_name, 90);
						unset($imageLib);
					}
			
				}
			}
			
			return $small_array;
			
		}
		
		public function get_article_array($category_id = 0)
		{
			$param_array			= array();
			$database		= new database();
			if($category_id > 0)
			{
				$sql 			= "SELECT * FROM content WHERE content_type='article' AND category_id=$category_id  AND status='Y' ORDER BY content_id DESC";
			}
			else
			{
				$sql 			= "SELECT * FROM content WHERE content_type='article'  AND status='Y' ORDER BY content_id DESC";
			}
			
			$result				= $database->query($sql);
			$this->num_rows = $result->num_rows;
			functions::paginateclient_article($this->num_rows, 0, 0, 'CLIENT');
			$start			= functions::$startfrom1;
			$limit			= functions::$limits1;
			$sql 			= $sql . " limit $start, $limit";
			$result			= $database->query($sql);
			
			if(isset($_GET['id']))
			{
				//$param_array[] ="id=".$_GET['id'];
			}
			
			$param=join("&amp;",$param_array); 
			$this->pager_param=$param;
			
			if ($result->num_rows > 0)
			{
				while($data=$result->fetch_object())
				{
					//$small_array[] = $data->content_id;
					$image_name 	= $data->content_thumbnail;
					
					if(!file_exists(DIR_CONTENT.'thumb_'.$image_name) && $image_name != '')
					{	
						$size_1	= getimagesize(DIR_CONTENT.$image_name);
						$imageLib = new imageLib(DIR_CONTENT.$image_name);
						if($data->image_size == 0)
						{
							$imageLib->resizeImage(CONTENT_SMALL_THUMB_WIDTH, CONTENT_SMALL_THUMB_HEIGHT, 0);	
						}
						else
						{
							$imageLib->resizeImage(CONTENT_BIG_THUMB_WIDTH, CONTENT_BIG_THUMB_HEIGHT, 0);
						}
						$imageLib->saveImage(DIR_CONTENT.'thumb1_'.$image_name, 90);
						unset($imageLib);
						$img	= 'thumb1_'.$image_name;
					}
					else
					{
						$img	= 'thumb_'.$image_name;
					}
					
					$title    ='';
					$desc     = '';
					$desc1	  = '';
					
					?>
					<li>
                    	<div class="product_box">
                    		<?php if($data->image_size == 0)
							{ ?>
                            	
                                    <div class="product_boximg ">
                                        <img src="<?php echo URI_CONTENT.$img;?>" >
                                        <div class="caption">
                                            <div class="blur">
                                          </div>
                                            <div class="caption-text">
                                                <h1><?php echo functions::deformat_string($data->title); ?></h1>
                                                <p>
                                                    <?php echo substr(strip_tags(functions::deformat_string($data->content)), 0, 250); ?>
                                                </p>
                                            </div>
                                      </div>
                                  </div>
                            <?php } else { ?>
                            	
                                <div class="product_boximg ">
                                    <img src="<?php echo URI_CONTENT.$img;?>" style="height:450px;" >
                                    <div class="caption" >
                                        <div class="blur" style="height:506px;">
                                        </div>
                                        <div class="caption-text" >
                                             <h1><?php echo functions::deformat_string($data->title); ?></h1>
                                            <p >
                                                 <?php echo substr(strip_tags(functions::deformat_string($data->content)), 0, 400); ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>   
                                
                                
                                <div class="prd_contentbox">
                                    <?php echo functions::deformat_string($data->title); ?>
                                    <div class="comment_favbox">
                                        <div class="comment">
                                            0
                                        </div>
                                        <div class="fav">
                                            15
                                        </div>
                                    </div>
                                </div>
                            </div>
                         </li>
					<?php
				}
			}
			else
			{
				echo '<li>Sorry..... No Results Found</li>';	
			}
						
		}
		
	}
?>