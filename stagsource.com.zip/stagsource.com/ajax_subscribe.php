<?php
 
include('includes/config.php');
$subscribe= new subscribe();
$subscribe->email=$_REQUEST['email'];
if($subscribe->save())
{
	echo "1";
	
}
else echo "0";

?>