<?php
/*********************************************************************************************
Author 	: V V VIJESH
Date	: 02-April-2011
Purpose	: 
*********************************************************************************************/

ob_start();
session_start();

require_once ('includes/config.php');
$page_name = functions::get_page_name();

if($page_name=='content.php')
{
   $page_name = functions::get_page_name_only();
}
//$page =explode('/',$_SERVER['REQUEST_URI']);

if($_SERVER['QUERY_STRING']!='' && $page_name != 'faq.php')
{
	$page = explode('id=',$_SERVER['QUERY_STRING']);
	
	$page_id = $page[1];
}

?>
	<script type="text/javascript" src="<?php echo URI_ROOT ?>js/jquery.reveal.js"></script>
   <!-- <script type="text/javascript" src="js/foundation.min.js"></script>-->
	<link rel="stylesheet" href="<?php echo URI_ROOT ?>css/reveal.css">

	<!--<script type="text/javascript" src="<?php echo URI_LIBRARY; ?>fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script>
	<script type="text/javascript" src="<?php echo URI_LIBRARY; ?>fancybox/source/jquery.fancybox.js?v=2.1.5"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo URI_LIBRARY; ?>fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />-->


<script src="<?php echo URI_LIBRARY; ?>jquery/jquery-validate.js" ></script>
<script type="text/javascript" src="<?php echo URI_ROOT ?>js/md5.js"></script>

<script type="text/javascript">
$(document).ready(function ()
{
	$('#login_btn').click(function(e) {
		e.preventDefault();
		
		<?php if(!isset($_COOKIE['remember'])) { ?>
			$('#username').val('');
			$('#password').val('');
		<?php } ?>	
		
		$('label.error').hide();
		$('.error').removeClass('error');
		$('#login_error').hide();
		
		var modalLocation = $(this).attr('data-reveal-id');
		$('#'+modalLocation).reveal($(this).data());
	});
	
	$('#forgot_btn').click(function(e) {
		e.preventDefault();
		$('#email').val('');
		$('label.error').hide();
		$('.error').removeClass('error');
		$('#forgot_error').hide();
		$('.close-reveal-modal').focus().click();
		var modalLocation = $(this).attr('data-reveal-id');
		$('#'+modalLocation).reveal($(this).data());
	});
	
	/*$('#bachelorparty_btn').click(function(e) {
		e.preventDefault();
		var modalLocation = $(this).attr('data-reveal-id');
		$('#'+modalLocation).reveal($(this).data());
	});*/
	
	
		
	
	$("#frm_login").validate({
/*		errorLabelContainer: "ul",
		errorElement: "em",
		wrapper: "li",*/
		wrapper:'span',
		
		rules: {
			username: {
			   required:true,
			   minlength: 4,
			   maxlength: 25
			},
           password: {
				required: true,
				maxlength: 15,
				minlength: 5
			}
		},
		messages: {
			username: {
				required: "Username is required",
				minlength: "Username should be atleast {0} characters ",
				maxlength: "Username not more than {0} characters "
			},
			password: {
				required: "Password is required",
				minlength: "Password should be atleast {0} characters",
				maxlength: "Password not more than {0} characters"
			}
		},
		showErrors: function (errorMap, errorList) {
   			this.defaultShowErrors();
    		$.each(errorList, function (i, error) {
				$('label.error').css("padding-left", ".0em");
    		});
		}
		
		
		/*errorPlacement: function(error, element) {         
       		//error.insertBefore(element);
			//error.css("margin", "0 0 0 5px");
			
			//$(element).attr("placeHolder", error[0].innerHTML);
			//error.insertBefore(element.parent().next('div').children().first());
			//error.addClass('arrow');
        	//error.insertAfter(element);
   		}*/
		
			
	}); 
	
	
	$("#frm_forgot").validate({		
		rules: {
			email: {
			   required:true,
			   email: true,
			  minlength: 4,
			  maxlength: 25
			}
		},
		messages: {
			email: {
						required:"Email is required",
						email	: "Please enter a valid email address",
						minlength: "Email should be atleast {0} characters ",
						maxlength: "Email not more than {0} characters " 
					}
		},
		showErrors: function (errorMap, errorList) {
   			this.defaultShowErrors();
    		$.each(errorList, function (i, error) {
				$('label.error').css("padding-left", ".0em");
    		});
		}		
	}); 
	
	
	$('.login_txtfield').keypress(function(e) {
		$('#message').hide();
        if(e.which == 13) {
            jQuery(this).blur();
            jQuery('#save').focus().click();
        }
    });
	
	
	$('#save').click(function() {
		if($("#frm_login").valid())
		{
			var remember = 0;
			if($('#remember').attr('checked')) {
    			remember = 1;
			} else {
    			remember= 0;
			}
			
			var pass_hash = CryptoJS.MD5($('#password').val());
			$.ajax(
			{
				type: "POST",
				cache: false,
				url: "<?php echo URI_ROOT ?>ajax_login.php?username="+$('#username').val()+"&password="+pass_hash+"&remember="+remember,
				success: function (data)
				{
					var row = data.split('<>');
					if(row[0] == 1)
					{
						window.location='index.php';	
					}
					else 
					{
						$('#login_error').html(row[1]);
						$('#login_error').show();
					}
				}
			});
		}
	});
	
	$('#forgot').click(function() {
		if($("#frm_forgot").valid())
		{
			$.ajax(
			{
				type: "POST",
				cache: false,
				url: "<?php echo URI_ROOT ?>ajax_forgot_password.php?email="+$('#email').val(),
				success: function (data)
				{
					var row = data.split('<>');
					if(row[0] == 1)
					{
						$('.close-reveal-modal').focus().click();
						//Password reset instructions have been sent to your email.
						
						//var modalLocation = $('#confirm').attr('data-reveal-id');
						$('#confirm').reveal($(this).data());
		
						/*$('#forgot_error').html('Password reset instructions have been sent to your email.');
						$('#forgot_error').show();*/
						
						//window.location='index.php';	
					}
					else 
					{
						$('#forgot_error').html(row[1]);
						$('#forgot_error').show();
					}
				}
			});
		}
	});
});

function expand_one(){
	
    $("#expand_first").show(300);
	//$("#content_first_"+id).hide(300);
}
function collaps_one(){
 
 $("#expand_first").hide(300); 

}


function show_contact_popup()
{
	$.ajax(
    {
        type: "POST",
        cache: false,
        url: "popup_contact.php",
        success: function (data)
	    {
            $.fancybox(data);
        }
    });
}

function show_message(message)
{
	$.ajax(
	{
		type: "POST",
		cache: false,
		url: "<?php echo URI_ROOT ?>popup_show_message.php?popup=1&message=" + message,
		success: function (data)
		{
			$.fancybox(data);
		}
	});
}

</script>


<header class="header">
	<section class="login_signupbox">
	<div class="login_signupboxinner">
		<div class="login_socialmediabox">
        
        <?php if(!isset($_SESSION[USER_ID])) { ?>
			<div class="login">
				<!--<a href="#">Login</a>-->
                <a style="cursor:pointer;" id="login_btn" class="big-link" data-reveal-id="loginBox" data-animation="fadeAndPop">Login</a>
			</div>
			<div class="login">
				<a href="#">Signup</a>
                <!--<a href="#" id="signup_btn" class="big-link" data-reveal-id="signUp" data-animation="fadeAndPop">Signup</a>-->
			</div>
         <?php } else { ?>
         	<div class="login">
				<a href="<?php echo URI_ROOT ?>logout.php">Logout</a>
			</div>
			<div class="login">
				<a href="#">Profile</a>
			</div>
         
         <?php } ?>
         
			<a href="#"><i class="icn_fb"></i></a>
			<a href="#"><i class="icn_pintrest"></i></a>
			<a href="#"><i class="icn_twitter"></i></a>
			<a href="#"><i class="icn_google"></i></a>
			<a href="#"><i class="icn_rss"></i></a>
		</div>
	</div>
	</section>
	<section class="nav_box">
	<div class="nav_box_inner">
		<figure class="logo"><a href="<?php echo URI_ROOT ?>"><img src="<?php echo URI_ROOT ?>images/logo.png" width="157" height="54"></a></figure>
        <div class="navmobile">
        	<div class="row">
<a href="#hide1" class="hide" id="hide1" onClick="expand_one();"><b><img class="mrleft3" src="<?php echo URI_ROOT ?>images/nav-icon.png"></b></a> 
<a href="#show1" class="show" id="show1" onClick="collaps_one();" ><b><img class="mrleft3" src="<?php echo URI_ROOT ?>images/nav-icon.png"></b></a>

<!--LIST POSTS-->
<div class="list" id="expand_first" style="display:none;">
    <ul>
        <a href="<?php echo URI_ROOT ?>"><li>Home</li></a>
        <a href="<?php echo URI_ROOT ?>category/bachelor"><li>Bachelor</li></a>
        <a href="<?php echo URI_ROOT ?>category/wedding"><li>Wedding</li></a>
        <a href="<?php echo URI_ROOT ?>category/honeymoon"><li>Honeymoon</li></a>
        <a href="<?php echo URI_ROOT ?>category/advice"><li>Advice</li></a>
        <a href="<?php echo URI_ROOT ?>category/style"><li>Style</li></a>
        <a href="<?php echo URI_ROOT ?>category/gifts"><li>Gifts</li></a>
        <a href="<?php echo URI_ROOT ?>category/community"><li>Community</li></a>
    </ul>
</div>
</div>
        </div>
		<nav class="nav">
		<ul>
        	<?php
				$page_1 = str_replace('/','', $page_id);
			
			?>
            
			<a href="<?php echo URI_ROOT ?>">
			<li <?php echo ($page_name =='index.php') ? 'class="active"' : ''; ?>>Home</li>
			</a>
			<a href="<?php echo URI_ROOT ?>category/bachelor" >
				<li <?php echo ($page_name =='category.php' && $page_1 == 'bachelor') ? 'class="active"' : ''; ?>>Bachelor</li>
			</a>
			<!--<a style="cursor:pointer;" id="bachelorparty_btn" class="big-link" data-reveal-id="bachelorparty" data-animation="fadeAndPop">-->
            <a href="<?php echo URI_ROOT ?>category/wedding">
			<li <?php echo ($page_name =='category.php' && $page_1 == 'wedding') ? 'class="active"' : ''; ?>>Wedding</li>
			</a>
			<a href="<?php echo URI_ROOT ?>category/honeymoon">
			<li <?php echo ($page_name =='category.php' && $page_1 == 'honeymoon') ? 'class="active"' : ''; ?>>Honeymoon</li>
			</a>
            <a href="<?php echo URI_ROOT ?>category/advice">
			<li <?php echo ($page_name =='category.php' && $page_1 == 'advice') ? 'class="active"' : ''; ?>>Advice</li>
			</a>
			<a href="<?php echo URI_ROOT ?>category/style">
			<li <?php echo ($page_name =='category.php' && $page_1 == 'style') ? 'class="active"' : ''; ?>>Style</li>
			</a>
			<a href="<?php echo URI_ROOT ?>category/gifts">
			<li <?php echo ($page_name =='category.php' && $page_1 == 'gifts') ? 'class="active"' : ''; ?>>Gifts</li>
			</a>
			<a href="<?php echo URI_ROOT ?>category/community">
			<li <?php echo ($page_name =='category.php' && $page_1 == 'community') ? 'class="active"' : ''; ?>>Community</li>
			</a>
		</ul>
		</nav>
	</div>
	</section>
	</header>
    
    
    <div id="loginBox" class="reveal-modal">
<div class="login_box">
	<h1>User Login</h1>
    <div class="connect_fb"></div>
    <div class="or"><img src="<?php echo URI_ROOT ?>images/or.jpg" ></div>
     <form id="frm_login" name="frm_login" method="post" autocomplete="off">
     
    <div class="login_error" id="login_error" style="display:none;"></div>
    <div class="login_fieldbox">
    	<input type="text" name="username" id="username"  value="<?php echo $_COOKIE['remember_me']; ?>" class="login_txtfield" placeholder="Username">
    </div>
    <div class="login_fieldbox">
    	<input type="password" name="password" id="password"  value="<?php echo $_COOKIE['remember_pass']; ?>" class="login_txtfield" placeholder="Password" maxlength="15">
    </div>
    <div class="forgot_remember">
    <div class="login_chkbox">
    <fieldset class="checkboxes"><label class="label_check" for="remember"><input name="remember" id="remember" value="1" type="checkbox" <?php if(isset($_COOKIE['remember'])) { echo 'checked="checked"'; } else { echo ''; }	?>/></label></fieldset>
    </div>
    <span class="reme">Remember me</span> <span class="frgtpwd"><a style="cursor:pointer;" id="forgot_btn" class="big-link" data-reveal-id="forgotPass" data-animation="fadeAndPop">Forgot password</a></span>
    <input name="save" id="save" type="button" value="Sign in" class="btn_signin">
    </form>
    </div>
</div>
<a class="close-reveal-modal">&#215;</a>
</div>

<div id="forgotPass" class="reveal-modal">
<div class="forgot_box">
	<h1>Reset Your Password</h1>
   	<div class="reset_txt">Forgot your password? No problem! Enter your email and we will send you instructions on how to reset your password. </div>
    
     <div class="forgot_error" id="forgot_error" style="display:none;"></div>
     
	 <form id="frm_forgot" name="frm_forgot" method="post" autocomplete="on">
    <div class="login_fieldbox">
    	<input name="email" id="email" type="text" class="login_txtfield" placeholder="Email">
    </div>
   
   
    <div class="forgot_remember">
   
    <input name="forgot" id="forgot" type="button" value="Send Reset Password Email" class="btn_forgot">
    </form>
    </div>
</div>
<a class="close-reveal-modal" >&#215;</a>
</div>

<div id="confirm" class="reveal-modal">
<div class="forgot_box" style="min-height:70px">
   	<div class="reset_txt" style="margin-left:20px; font-size:12px">Password reset instructions have been sent to your email.</div>

</div>
<a class="close-reveal-modal" >&#215;</a>
</div>


<div id="signUp" class="reveal-modal">
<div class="login_box">
	<h1>Sign Up</h1>
    <div class="connect_fb"></div>
    <div class="or"><img src="<?php echo URI_ROOT ?>images/or.jpg" ></div>
    <div class="login_fieldbox">
    	<input name="" type="text" class="login_txtfield" placeholder="Username">
    </div>
    <div class="login_fieldbox">
    	<input name="" type="text" class="login_txtfield" placeholder="Password">
    </div>
    <div class="forgot_remember">
    <div class="login_chkbox">
    <fieldset class="checkboxes"><label class="label_check" for="checkbox-04"><input name="sample-checkbox-04" id="checkbox-04" value="4" type="checkbox" /></label></fieldset>
    </div>
    <span class="reme">Remember me</span> <span class="frgtpwd"><a href="#">Forgot password</a></span>
    <input name="" type="button" value="Sign in" class="btn_signin">
    </div>
</div>
<a class="close-reveal-modal">&#215;</a>
</div>


<div id="bachelorparty" class="reveal-modal">
<div class="login_box">
	<i class="left_seach_heading_icn"><img src="<?php echo URI_ROOT ?>images/curated_hed_icn.jpg" width="74" height="62"></i>
    <div class="bachelor_party_hd">Bachelor Party</div>
    <div class="pickur_loc">Pick yout Location
    	<div class="pickur_locselctlarge">
        	<select name="type_annonce" class="ordinnary_text_form" id="6">
					<option value="%">Filter Items By Type</option>
					<option value="1">Sample New</option>
					<option value="2">Sample old</option>
					<option value="3">Sample New</option>
				</select>
        </div>
    </div>
    <div class="price_rangeb">Price Range
    <input name="" type="text" class="price_rangetxt" value="$500 - $2000">
    </div>
    <div class="price_rangeb">Party Size
    <div class="price_rangetxt2 pd_lft">
    <select name="type_annonce" class="ordinnary_text_form" id="7">
					<option value="%">5 - 10</option>
					<option value="1">10 - 20</option>
					<option value="2">20 - 30</option>
					<option value="3">30 - 100</option>
				</select>
    </div>
    </div>
    <input name="" type="button" value="Submit" class="bc_btn_submit">
</div>
<a class="close-reveal-modal">&#215;</a>
</div>

