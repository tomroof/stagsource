<?php
/*********************************************************************************************
Author 	: V. V. VIJESH
Date	: 10-Nov-2011
Purpose	: Content page
*********************************************************************************************/
ob_start("ob_gzhandler");
session_start();
include_once("includes/config.php");

$content_id	= (isset($_REQUEST['id']) &&  $_REQUEST['id']) != '' ? $_REQUEST['id'] : '';

$content	= new content($content_id);

if($content->status == 'N')
{
	functions::redirect("under-construction.html");
	exit;
}
else if($content->content_id == 0)
{
	functions::redirect("page-not-found.html");
	exit;
}




if( $content_id	 == 'index.html') //$content->content_id == 1 ||
{
	functions::redirect("index.php");
	exit;
}

// Set template details
$template 					= new template();
$template->type				= 'CLIENT';
$template->title			= functions::deformat_string($content->title);
$template->meta_keywords	= functions::format_text_field($content->meta_keywords);
$template->meta_description	= functions::format_text_field($content->meta_description);
$template->js				= '';
$template->css				= '';
$template->right_menu		= true;
$template->heading();
?>




<section class="contentwrapper">
	<div class="content_inner">

        <h1><?php  echo functions::deformat_string($content->title) ?></h1> <br />
        <p><?php  echo $content->content ?></p>
        <br />

	</div>
	</section>


<?php
$template->footer();
?>
