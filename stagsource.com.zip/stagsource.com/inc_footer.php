
<script>
	$(document).ready(function() {
	
		$("#subscribe").click(function()
		{
			validate();
		});
		
		$("#email_footer").keyup(function()
		{
			//validate();
		});
		
		function validate()
		{
			$('.warningMesg').html('');
 			$('.warningMesg').hide('');			
			var email =$.trim($("#email_footer").val());
			
			
			if(email=='')
			{
				show_alert('email_footer', 'Email cannot be blank');
			}
			else if(is_email(email))
			{
				show_alert( 'email_footer','Invalid email address');
			}
			else
			{
				$.ajax(
				{
					type: "POST",
					cache: false,
					url: "ajax_subscribe.php?email="+email,
					success: function (data)
					{
						if( $.trim(data)=="1")
						{
							$("#email_footer").val("");
							$('#message_email_footer').hide();
							show_message("Thank you for subscribing, stay tuned for news! ");
						}
						else
						{
							$('#message_email_footer').html("You are already subscribed news letter!");
							$('#message_email_footer').show();	
						}
					}
				});
			}
		}
	
	});
function show_alert(id, message)
{
	$('#message_' + id).html(message);
	$('#message_' + id).show();
}
function is_email(input)
{
    var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
   
        if (re.test(input))
        {
            return false;
        }

    return true;
}</script>


    <footer class="footer">
    <section class="keepintouch">
      <div class="keepintouch_inner">
      	<h1>Keep in touch</h1>
        <p>Stay where you are. We'll push the news to you.</p>
        <div class="subscribe_box">
        <div class="sub_email">
        
        <form name="subform" id="subform" method="POST" action="">
        	<input name="email_footer" id="email_footer" type="text"  placeholder="Enter email address...">
            <div id="message_email_footer" class="warningMesg" style=" display:none;  float:left; width:100%; text-align:left; padding-top:0; color:#F00; font-size:12px; "></div>
            </div>
            <div class="btn_subscribe">
            <input name="subscribe" id="subscribe" value="SUBSCRIBE" type="button">
            </div>
          </form>
        </div>
        <div class="footer_social_link">
        	<div class="twit_footer">TWITTER</div>
            <div class="fb_footer">FACEBOOK</div>
            <div class="google_footer">GOOGLE+</div>
        </div>
      </div>
    </section>
    <section class="footer_nav">
      <div class="footer_nav_inner">
      	<div class="nav_footer">
        <div class="footer_navbox">
        STAGSOURCE
       	  <ul>
            
            	<li><a href="<?php echo URI_ROOT ?>">Home</a></li>
            	<li><a href="#">Writers</a></li>
            	<li><a href="#">About</a></li>
            </ul>
            </div>
            <div class="footer_navbox">
        ABOUT
        	<ul>
            
            	<li><a href="#">Blog</a></li>
            	<li><a href="<?php echo URI_ROOT ?>licence-agreement.html">License agreement</a></li>
            	<li><a href="<?php echo URI_ROOT ?>privacy-policy.html">Privacy policy</a></li>
            </ul>
            </div>
            <div class="footer_navbox">
        HELP
        	<ul>
            
            	<li><a href="#">Documentation</a></li>
            	<li><a href="#">Discussions</a></li>
            	<li><a href="#">Contact</a></li>
            </ul>
            </div>
            <div class="footer_navbox">
        STAGSOURCE
        	<ul>
            
            	<li><a href="#">Facebook</a></li>
            	<li><a href="#">Twitter</a></li>
            	<li><a href="#">Google+</a></li>
            	<li><a href="#">App.net</a></li>
            </ul>
            </div>
        </div>
      </div>
      <div class="copyright_box">&copy; <?php echo functions::deformat_string(SITE_NAME); ?>. All rights reserved</div>
    </section>
    </footer>