
function clearText(thefield){
    if(thefield.defaultValue==thefield.value)
        thefield.value = ""
}

function fillText(thefield){
    if(thefield.value=="")
        thefield.value=thefield.defaultValue
}



