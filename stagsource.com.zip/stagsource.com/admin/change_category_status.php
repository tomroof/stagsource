<?php
	/*********************************************************************************************
			Author 	: V V VIJESH
			Date	: 20-Nov-2010
			Purpose	: Change category status
	*********************************************************************************************/
	ob_start();
	session_start();
	include_once("../includes/config.php");

	$category_id	= $_REQUEST['category_id'];
	
	$status = category::update_status($category_id);
	echo ($status == 'Y') ? 1 : 0;
?>