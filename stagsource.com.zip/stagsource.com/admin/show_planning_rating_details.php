<?php 

ob_start();

session_start();

include_once("../includes/config.php");



$show				= (	isset($_REQUEST['show']) &&  ($_REQUEST['show'] > 0) ) ? trim($_REQUEST['show']) : 0;

$planning_rating_id	= (	isset($_REQUEST['planning_rating_id']) &&  ($_REQUEST['planning_rating_id'] > 0) ) ? trim($_REQUEST['planning_rating_id']) : 0;

$planning_rating		= new planning_rating($planning_rating_id);



if($show==1)

{

	?>

	<div class="expandSubContent">

	<table cellpadding="0" cellspacing="0" width="100%" class="expandDataTable">


		<tr >

			<td width="14%">Rating</td>

            <td>

				<?php

				echo functions::deformat_string($planning_rating->rating);

				?>

			 </td>

		</tr>
        
        <tr >

			<td>Comment</td>

            <td>

				<?php

				echo nl2br(functions::deformat_string($planning_rating->comment));

				?>

			 </td>

		</tr>
        
        
        <?php if($planning_rating->rating_name != '') { ?>
        <tr >

			<td>Name</td>

            <td>

				<?php

				echo functions::deformat_string($planning_rating->rating_name);

				?>

			 </td>

		</tr>
       <?php } ?>
       
       <?php if($planning_rating->email != '') { ?>
        <tr >

			<td>Email</td>

            <td>

				<?php

				echo functions::deformat_string($planning_rating->email);

				?>

			 </td>

		</tr>
       <?php } ?>
       
        <tr >

			<td>Status</td>

            <td>

				<?php

				echo ($planning_rating->status == 'Y') ? 'Active': 'Inactive';

				?>

			 </td>

		</tr>

        <tr >

			<td>Added Date</td>

            <td>

				<?php

				echo date('d-m-Y', strtotime($planning_rating->added_date));

				?>

			 </td>

		</tr>
	</table>

	</div>

	<?php 

}

?>

