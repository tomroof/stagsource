<?php

/*********************************************************************************************

Author 	: V V VIJESH

Date	: 14-April-2011

Purpose	: Register testimonial

*********************************************************************************************/

ob_start();

session_start();

include_once("../includes/config.php");



// Check the admin user is loged in or not

if (!isset($_SESSION[ADMIN_ID]))

{

	functions::redirect("login.php");

	exit;

}


 $planning_id		= (isset($_REQUEST['planning_id']) &&  $_REQUEST['planning_id']) > 0 ? $_REQUEST['planning_id'] : 0;
 
 $planning 		=  new planning($planning_id);
 if($planning->planning_id == 0)
 {
	functions::redirect("manage_planning.php");
	exit; 
 }


$planning_rating_id	= (isset($_REQUEST['planning_rating_id']) &&  $_REQUEST['planning_rating_id']) > 0 ? $_REQUEST['planning_rating_id'] : 0;

$planning_rating 	= new planning_rating($planning_rating_id);

if($planning_rating_id > 0)
{
	$page_title = 'Edit Rating & Comment';
}
else
{
	$page_title = 'Add Rating & Comment';
}

$description_length	= 5000;

$default_page_title		= 'Manage Rating & Comments';
$default_page_uri		= 'manage_planning_rating.php';
// Cancel button action starts here
if(isset($_POST['cancel']))	
{
	functions::redirect($default_page_uri . "?planning_id=" . $planning_id);
	//functions::redirect($default_page_uri);
}

$comment_length 			= 1000;
// Set template details
$template 				= new template();
$template->type			= 'ADMIN';
$template->left_menu	= true;
$template->admin_id		= $_SESSION[ADMIN_ID];
//$template->title		= $page_title;
$template->js			= '
<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>

<script type="text/javascript" language="javascript">
	
	function validate_form()

	{

		var forms = document.register_rating;


		/*if (!check_selected(forms.rating, "Rating is required!"))

		{	return false;	}*/
		
		if(forms.rating.value == "")
		{
			alert("Rating is required!");
			return false;	
		}
		
		if (!check_blank(forms.comment, "Comment is required!"))
		{	return false;	}
		
		if(forms.email.value != "")
		{
			if (!check_email(forms.email, "Email is invalid!"))

			{	return false;	}	
		}

		return true;

	}



</script>';
	
$template->heading();
// Save button action starts here
if(isset($_POST['save']))
{

	$planning_rating						= new planning_rating();
	$planning_rating->planning_rating_id		= $planning_rating_id;
	$planning_rating->planning_id	             = $planning_id;
	$planning_rating->rating				= functions::clean_string($_POST['rating']);
	$planning_rating->comment				= functions::clean_string($_POST['comment']);
	$planning_rating->rating_name					= functions::clean_string($_POST['rating_name']);
	$planning_rating->email					= functions::clean_string($_POST['email']);
    $planning_rating->status				= functions::clean_string($_POST['status']);
	
	$validation							= new validation();
	//$validation->check_blank($planning_rating->title, "Title", "title");
	$validation->check_blank($planning_rating->comment, "Comment", "comment");
	if($planning_rating->email != '')
	{
		$validation->check_email($planning_rating->email, "Email", "email");
	}
	
	$validation->check_blank($planning_rating->status, "Status", "status");
	
	$flag = 0;
	if($planning_rating->rating == "")
	{
		echo $flag =1;	
	}
	
	if (!$validation->checkErrors() && $flag == 0)
	{
		echo "here";
		if($planning_rating->save())
		{
		  if($planning_rating_id == 0)
		  {
			$planning_rating->planning_rating_id		= 0;
			$planning_rating->title	= '';
			$planning_rating->description	= '';
		  }
		}
		
		
		if(!$planning_rating->warning){
			$json_var 	= '{"title":"Success", "text":"'.$planning_rating->message.'","type":"success","width":"100%","url":"manage_planning_rating.php?planning_id='.$planning_id.'"}';
			$notify 	= new notify();
			$notify->show_message($json_var);
		}
		
	}
	else
	{
		$planning_rating->error	= $validation->getallerrors();
		if($flag ==1) $planning_rating->error['rating'] = 'Rating is required';
		//print_r($planning_rating->error);
	}
	if($planning->warning)
	{
		$json_var 	= '{"title":"Error", "text":"'.$planning->message.'","type":"error","width":"100%"}';
		$notify 	= new notify();
		$notify->show_message($json_var);
	}
}
else if (!isset($_POST["save"]))
{
	$planning_rating	= new planning_rating($planning_rating_id);
}
?>

<script language="javascript" type="text/javascript">



</script>

<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
	<tr>
		<td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
		<td class="topRepeat">&nbsp;</td>
		<td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
	<tr>
		<td rowspan="2" class="leftRepeat">&nbsp;</td>
		<td bgcolor="#FFFFFF"><div class="contentHeader">
				<div class="pageTitle">
					<?php 
					if($planning_rating->planning_rating_id > 0)
					{
						$page_title = 'Edit Rating & Comment';
					}
					echo functions::deformat_string($page_title);
					?>

				</div>
				<div class="contentSublinks txtBold"> <img src="images/add-campaign.png" alt="<?php echo functions::deformat_string($default_page_title); ?>" title="<?php echo functions::deformat_string($default_page_title); ?>" width="24" height="24" class="imgBlock" /> <a href="<?php echo $default_page_uri."?planning_id=".$planning_id; ?>"><?php echo functions::deformat_string($default_page_title); ?></a> </div>
			</div>
			<?php if(!empty($planning_rating->message)) { ?>
			<span class="<?php echo $planning_rating->warning ? 'warningMesg' : 'infoMesg'; ?>  formPageWidth"> <?php echo $planning_rating->message; ?> </span>
			<?php } ?>
			<div class="spacer"></div></td>
		<td rowspan="2" class="rightRepeat">&nbsp;</td>
	</tr>
	<tr>
		<td bgcolor="#FFFFFF"><form name="register_rating" id="register_rating" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data" >
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="form">
					<tr>
						<td width="16%">Rating<span class="txtRed">*</span></td>
						<td><select  id="rating" name="rating" tabindex="1" size="1" class="dropdown">
                        <option value="" >--Select Rating--</option>

                        <?php

                       

                        for($i = 0; $i <= 10;)
                        {
                            $select = ' ';

                            if($i == $planning_rating->rating)
                            {
                                $select = ' selected ';
                            }                         

                            echo '<option  value="' . $i  . '" '. $select .'>' . functions::deformat_string($i) . '</option>';
							$i += 0.5 ;
                        }

                        ?>

                      </select>
							<div class="spacer"></div></td>
					</tr>
                    
                    

                    <tr>
						<td>Comment<span class="txtRed">*</span></td>
						<td><textarea name="comment" id="comment" cols="45" rows="4" class="textarea" tabindex="2" oonKeyDown="limitText(this.form.comment,this.form.countdown1,<?php echo $comment_length; ?>);"  onkeyup="limitText(this.form.comment,this.form.countdown1,<?php echo $comment_length; ?>);"><?php echo functions::format_text_field($planning_rating->comment); ?></textarea>
							<?php if(!empty($planning_rating->error["comment"])) { ?>
							<span id="errmesg" class="error"> <?php echo $planning_rating->error["comment"]; ?></span>
							<?php } ?>
							</label>
							<br>
							Maximum characters: <?php echo $comment_length; ?> You have
							<input name="countdown1" id="countdown1" type="text" class="admincontent" <?php if($planning_rating->comment!=""){?>value="<?php echo  $comment_length - strlen($planning_rating->comment);?>"<?php }else{?> value="<?php echo $comment_length; ?>"<?php }?> size="5" readonly>
							characters left.<br />
							<div class="spacer"></div></td>
					</tr>
                    
                    <tr>

						<td >Name</td>

						<td><label>

								<input type="text" name="rating_name" id="rating_name" tabindex="3" class="textbox" maxlength="100" value="<?php echo functions::format_text_field($planning_rating->rating_name); ?>"  />

							</label>

							<?php if(!empty($planning_rating->error["rating_name"])) { ?>

							<span id="errmesg" class="error"> <?php echo $planning_rating->error["rating_name"]; ?> </span>

							<?php } ?>

							<div class="spacer"></div></td>

					</tr>
                    
                    
                    <tr>

						<td >Email</td>

						<td><label>

								<input type="text" name="email" id="email" tabindex="4" class="textbox" maxlength="100" value="<?php echo functions::format_text_field($planning_rating->email); ?>"  />

							</label>

							<?php if(!empty($planning_rating->error["email"])) { ?>

							<span id="errmesg" class="error"> <?php echo $planning_rating->error["email"]; ?> </span>

							<?php } ?>

							<div class="spacer"></div></td>

					</tr>
                    
                    <tr >

						<td>Status <span class="txtRed">*</span></td>

						<td><input type="radio" id="status1" name="status" value="Y" <?php echo functions::format_text_field($planning_rating->status) == 'Y' ||  functions::format_text_field($planning_rating->status) == '' ? ' checked="checked" ' : ''; ?>  class="checkbox" tabindex="5"  />

							Active&nbsp;&nbsp;

							<input type="radio" id="status2" name="status" value="N" <?php echo functions::format_text_field($planning_rating->status) == 'N' ? ' checked="checked" ' : ''; ?>  class="checkbox" tabindex="6"  />

							Inactive

							<?php if(!empty($planning_rating->error["status"])) { ?>

							<span id="errmesg" class="error"> <?php echo $planning_rating->error["status"]; ?></span>

							<?php } ?>

							<div class="spacer"></div></td>

					</tr>
                    
					<tr>
						<td></td>
						<td ><input type="submit" id="button" name="save" value="Save" class="submit" title="Save" tabindex="7" onclick="javascript:return validate_form();" />
							<input type="submit" id="cancel" name="cancel" value="Cancel" class="submit" title="Cancel" tabindex="8" />
							<div class="spacer"></div></td>
					</tr>
					<tr>
						<td colspan="2" class="txtTheme required"><span class="txtRed">*</span> Required fields</td>
					</tr>
				</table>
				<input type="hidden" id="planning_id" name="planning_id" value="<?php echo $planning_id; ?>" />
				<input type="hidden" id="planning_rating_id" name="planning_rating_id" value="<?php echo $planning_rating->planning_rating_id; ?>" />

			</form></td>

	</tr>

	<tr>
		<td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
		<td class="bottomRepeat">&nbsp;</td>
		<td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
</table>
<script language="javascript" type="text/javascript">
//limitText(document.forms['register_room'].description,document.forms['register_room'].countdown2, '<?php echo $description_length; ?>');
function limitText(limitField, limitCount, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		limitCount.value = limitNum - limitField.value.length;
	}
}
</script>
<?php 
	$template->footer();
?>

