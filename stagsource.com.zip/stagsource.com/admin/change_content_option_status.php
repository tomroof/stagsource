<?php
	/*********************************************************************************************
			Author 	: V V VIJESH
			Date	: 20-Nov-2010
			Purpose	: Change content status
	*********************************************************************************************/
	ob_start();
	session_start();
	include_once("../includes/config.php");

	$content_option_id 	= $_REQUEST['content_option_id'];
	
	 $latestwork_status = content_option::update_status($content_option_id);
	echo ($latestwork_status == 'Y') ? 1 : 0;
?>