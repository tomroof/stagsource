<?php 
ob_start();
session_start();
include_once("../includes/config.php");

$show	= (	isset($_REQUEST['show']) &&  ($_REQUEST['show'] > 0) ) ? trim($_REQUEST['show']) : 0;

$planning_id=$_GET['planning_id'];
if($show==1)
{
	$planning 		= new planning($planning_id);
	$party_type		= new party_type($planning->party_type_id);
	$vendor_type	= new vendor_type($planning->vendor_type_id);
	$property_type	= new property_type($planning->property_type_id);
	$location   	= new location($planning->location_id);
	$country 		= new country($planning->country_id);
	
	
	$amenities_str = '';
	$your_pick_str = '';
	
	$ids 	= explode(',',$planning->your_picks);
	for($i=0; $i< count($ids); $i++)
	{
		$facility = new facility($ids[$i]);
		$your_pick_str   .= ($i == 0) ? $facility->name: ', '. $facility->name;	
	}
	
	$ids 	= explode(',',$planning->amenities);
	for($i=0; $i< count($ids); $i++)
	{
		$amenities = new amenities($ids[$i]);
		$amenities_str   .= ($i == 0) ? $amenities->name: ', '. $amenities->name;	
	}
	
	$web_url 	= str_replace('http://', '', $planning->website);
	
?>
<div class="expandSubContent">
<table cellpadding="0" cellspacing="0" width="100%" class="expandDataTable">

	<tr class="">
    	<td width="18%">Party Type</td><td><?php echo functions::format_text_field($party_type->name);?></td></tr>
    	<td width="18%">Vendor Type</td><td><?php echo functions::format_text_field($vendor_type->name);?></td></tr>
        
		<?php if($vendor_type->vendor_type_id == 1) { ?>
    		<td width="18%">Property Type</td><td><?php echo functions::format_text_field($property_type->name);?></td></tr>
        <?php } ?>
        
		<td width="18%">Vendor Name</td><td><?php echo utf8_encode(functions::format_text_field($planning->vendor_name));?></td></tr>
          <?php if($planning->phone != '') { ?>
		<tr><td>Phone</td><td><?php echo functions::format_text_field($planning->phone);?></td></tr>
        <?php } 
		if($planning->address != '') { ?>
		<tr><td>Address</td><td><?php echo nl2br(functions::format_text_field($planning->address));?></td></tr>
        <?php } 
		 ?>
        <tr><td>City/Location</td><td><?php echo functions::format_text_field($location->name);?></td></tr>
        <tr><td>Country</td><td><?php echo  functions::deformat_string($country->country_name); ?></td></tr>
		<tr><td>Postcode</td><td><?php echo functions::format_text_field($planning->postcode);?></td></tr>
        <?php if($planning->website != '') { ?>
        <tr><td>Website</td><td><a href="http://<?php  echo $web_url; ?>" target="_blank"><?php echo $web_url; ?></a></td></tr>
        <?php }
		if($planning->email != '') { ?>
        <tr><td>Email</td><td><a href="mailto:<?php echo functions::format_text_field($planning->email);?>"><?php echo functions::format_text_field($planning->email);?></a></td></tr>
        <?php } 
		if($planning->budget_range > 0) { ?>
        <tr><td>Budget Range</td><td><?php echo functions::format_text_field($planning->budget_range_array[$planning->budget_range]);?></td></tr>
        <?php } 
		if($planning->cost_range > 0) { ?>
        <tr><td>Cost Range</td><td><?php echo functions::format_text_field($planning->cost_range_array[$planning->cost_range]);?></td></tr>
        <?php } ?>
       
        <?php if($vendor_type->vendor_type_id == 1) { ?>
            <tr><td style="vertical-align:top;">Price</td><td>&dollar;<?php echo functions::format_text_field($planning->price);?> / <?php echo functions::format_text_field($planning->price_type_array[$planning->price_type]) ?></td></tr>
            <tr><td>Hotel fee included</td><td><?php echo ($planning->planning_fee == 'Y') ? 'Yes': 'No';?></td></tr>
            <?php if($planning->overview != '') { ?>
            <tr><td style="vertical-align:top;">Overview/Write-Up</td><td><?php echo nl2br(utf8_encode(functions::format_text_field($planning->overview))) ;?></td></tr>
            <?php } 
			if($planning->your_picks != '') { ?>
            <tr><td>What you will love</td><td><?php echo functions::format_text_field($your_pick_str) ;?></td></tr>
            <?php } 
            if($planning->your_picks_description != '') { ?>
            <tr><td style="vertical-align:top;">What you will love - Description</td><td><?php echo nl2br(functions::format_text_field($planning->your_picks_description)) ;?></td></tr>
            <?php } 
            if($planning->amenities != '') { ?>
            <tr><td>Amenities</td><td><?php echo functions::format_text_field($amenities_str) ;?></td></tr>
            <?php }
            if($planning->features != '') { ?>
            <tr><td style="vertical-align:top;">Hotel Features</td><td><?php echo nl2br(functions::format_text_field($planning->features)) ;?></td></tr>
            <?php } 
            if($planning->location_description != '') { ?>
            <tr><td style="vertical-align:top;">Hotel Location</td><td><?php echo nl2br(functions::format_text_field($planning->location_description)) ;?></td></tr>
            <?php } 
            if($planning->guest_favourites != '') { ?>
            <tr><td style="vertical-align:top;">Guest Favourites</td><td><?php echo nl2br(functions::format_text_field($planning->guest_favourites)) ;?></td></tr>	
            <?php } 
		} else {
        	if($planning->overview != '') { ?>
            <tr><td style="vertical-align:top;">Overview/Write-Up</td><td><?php echo nl2br(utf8_encode(functions::format_text_field($planning->overview))) ;?></td></tr>
            <?php } 
            if($planning->whywe_like != '') { ?>
            <tr><td style="vertical-align:top;">Why we like it</td><td><?php echo nl2br(utf8_encode(functions::format_text_field($planning->whywe_like))) ;?></td></tr>	
          <?php   }
         } ?>	
        
		<tr><td>Status</td><td><?php echo functions::format_text_field($planning->status)== 'Y' ?  'Active' : 'Inactive' ;?></td></tr>
		<tr><td>Added Date</td><td><?php echo date('d-m-Y', strtotime($planning->added_date)) ;?></td></tr>
	</tr>
</table>
</div>
<?php 
}
?>
