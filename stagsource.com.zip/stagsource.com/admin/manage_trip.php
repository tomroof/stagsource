<?php
/*********************************************************************************************
Date	: 14-April-2011
Purpose	: Manage video
*********************************************************************************************/
ob_start();
session_start();
include_once("../includes/config.php");

// Check the admin user is loged in or not
if (!isset($_SESSION[ADMIN_ID]) && !isset($_SESSION[AGENT_ID]))
{
	functions::redirect("login.php");
	exit;
}

$page_title				= 'Manage Trips';	
$template 				= new template();
$template->type			= 'ADMIN';
$template->left_menu	= true;
$template->admin_id		= $_SESSION[ADMIN_ID];
$template->js			= '
<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'trip.js"></script>
<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>
<script type="text/javascript" language="javascript" src="' . URI_LIBRARY . 'jquery/jquery.tablednd.js"></script>

<script type="text/javascript" src="' . URI_LIBRARY . 'fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script> 
<script type="text/javascript" src="' . URI_LIBRARY . 'fancybox/source/jquery.fancybox.js?v=2.1.3"></script>
<link rel="stylesheet" type="text/css" href="' . URI_LIBRARY . 'fancybox/source/jquery.fancybox.css?v=2.1.2" media="screen" />

<script type="text/javascript" language="javascript">

<!--

	function validate_form()

	{

		var forms = document.search_form;
		
		/*if (!check_blank(forms.search_word, "Search word is required "))

		{	return false;	}*/
		
		if(forms.search_word.value == "" && forms.party_type_id.value == "0" && forms.vendor_type_id.value == "0" && forms.location_id.value == "0")
		{
			alert("Either enter search word or select any option");
			return false;	
		}

		return true;

	}

	//-->

</script>

';


$template->heading();

$trip 		= new trip();
if(isset($_REQUEST['search'])){
	$trip->search = true;	
}
if(isset($_REQUEST['search_word'])){
	$trip->search_word = $_REQUEST['search_word'];	
}


if(isset($_REQUEST['location_id'])){
	$trip->location_id = $_REQUEST['location_id'];	
}


if(isset($_REQUEST['search_word'])) 
{
	
	$trip->search_word=$search_word	   = functions::clean_string($_REQUEST['search_word']);
	 
		$validation		= new validation();
		if($_REQUEST['search'] == 'Go'){
		//$validation->check_four_object($search_word, $trip->office_id, $trip->beds,$trip->trip_status_id, 'either select office, number of beds, status, or  enter trip code', 'search_word');
	   }	
	
	
	if ($validation->checkErrors())
	{
		$trip->error	= $validation->getallerrors();
	}
}	

if(isset($_POST['action_type']) && $_POST['action_type']=="delete")
{
	$selected_id	= array();
	if( count($_POST['checkbox']) > 0)
	{   
		foreach($_POST['checkbox'] as $id => $val)
		{
			$selected_id[] = $id;
		}
		$trip->remove_selected($selected_id);
	}
	else
	{
		//$trip->warning = "Select atleast one category to delete";
		$trip->warning = true;
	}
	if(!$trip->warning)
		{
					
			$json_var 	= '{"title":"Success", "text":"'.$trip->message.'","type":"success","width":"100%","url":"manage_trip.php"}';
			$notify 	= new notify();
			$notify->show_message($json_var);
		}
}
?>
<?php

if(isset($_SESSION['message_object']))
{
	$notify = unserialize($_SESSION['message_object']);
	$notify->show_message_redirect();	
	unset($_SESSION['message_object']);
}

?>

 
 
 
<script type="text/javascript" language="javascript">
	
			
		$(document).ready(function()
		{
			/*$("#dd-list").tableDnD(
			{
				onDrop: function(table, row)
				{
					var page = document.getElementById("page").value;
					var order = $.tableDnD.serialize() + "&action=update_order"  + "&page=" + page;
					//alert(order);
					$.post("ajax_update_trip_order.php", order, function(theResponse){ }); 
				}
			});
			$("a.grouped_elements").fancybox();*/
		});
		
		
		
	</script>

<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
	<tr>
		<td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
		<td colspan="2" class="topRepeat">&nbsp;</td>
		<td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
	<tr>
		<td rowspan="3" class="leftRepeat">&nbsp;</td>
		<td colspan="2" bgcolor="#FFFFFF"><div class="pageSearchContainer">
				<div class="pageTitle"><?php echo functions::deformat_string($page_title); ?></div>
       
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="pageSearch">
                   
					<tr>
						<td class="pageSearchLeft">&nbsp;</td>
						<td class="pageSearchBg"><form name="search_form" method="post" action="manage_trip.php">
								<div class="searchLabel txtBold txtMedium">Search By Trip Name</div>
								<div class="searchBox">
									<input name="search_word"  id="search_word" type="text" class="textbox" value="<?php echo functions::format_text_field($trip->search_word); ?>" tabindex="1" />
									<?php if(!empty($trip->error["search_word"])) { ?>
									<span id="errmesg" class="error"><?php echo $trip->error["search_word"]; ?> </span>
									<?php } ?>
								</div>
                          
                                
								<!--<div class="searchBox">
									 <select  id="vendor_type_id" name="vendor_type_id" tabindex="3" size="1" class="dropdown">
                                    <option value="0" >--Select Vendor type--</option>
                                     <?php

										$vendor_type_array = vendor_type::get_vendor_type_options();
				
										for($i = 0; $i < count($vendor_type_array); $i++)
										{
											$select = ' ';
				
											if($vendor_type_array[$i]->vendor_type_id == $trip->vendor_type_id)
											{
												$select = ' selected ';
											}                         
				
											echo '<option  value="' . $vendor_type_array[$i]->vendor_type_id  . '" ' . $select . '>' . functions::deformat_string($vendor_type_array[$i]->name ) . '</option>';
				
										}
				
										?>
                                  </select>
								</div>-->
								<div class="searchBox">
									<select  id="location_id" name="location_id" tabindex="4" size="1" class="dropdown">
                                        <option value="0" >--Select City/Location--</option>
                                        <?php

										$location_array = location::get_location_options();
				
										for($i = 0; $i < count($location_array); $i++)
										{
											$select = ' ';
				
											if($location_array[$i]->location_id == $trip->location_id)
											{
												$select = ' selected ';
											}                         
				
											echo '<option  value="' . $location_array[$i]->location_id  . '" ' . $select . '>' . functions::deformat_string($location_array[$i]->name ) . '</option>';
										}
				
										?>
                                      </select>
								</div>
								
							
								<div class="submitBtnArea">
									<input type="submit" id="search" name="search"  class="go" value="Go" title="Search" tabindex="5" onclick="javascript:return validate_form();"/>
								</div>
								<div class="submitBtnArea noMarginRight">
									<input type="button" id="view_all" name="view_all" class="submit" value="View All" title="View All" tabindex="6" onClick="javascript:location.href='manage_trip.php';"  />
								</div>
								<input type="hidden" id="page" name="page" value="1" />
							</form></td>
						<td class="pageSearchRight">&nbsp;</td>
					</tr>
				</table>
			</div>
			
			<!--<div class="contentSublinks txtBold">
				<?php
			$page_name	= 'register_trip.php';
			$page_title	= 'Add Wedding trip';
			?><div class="spacer"></div>
				<img src="images/icon-property.png" alt="<?php echo $page_title; ?>" title="<?php echo $page_title; ?>" width="24" height="24" class="imgBlock" /> <a href="<?php echo $page_name; ?>"><?php echo $page_title; ?></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				
				 </div>-->
			<div class="clearFloat"></div>
			<div class="spacer"></div></td>
		<td rowspan="3" class="rightRepeat">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="2" bgcolor="#FFFFFF"><form id="list_form" name="list_form" method="post">
				<table border="0" cellspacing="0" cellpadding="0" class="listing" id="dd-list">
					<tr class="header nodrop nodrag">
						<td class="pageNumberCol alignCenter">No.</td>
						<td class="widthAuto">Trip Name</td>
						<td class="alignCenter joiningDateCol">Start Date</td>
                        <td class="alignCenter joiningDateCol">End Date</td>
						<td class="widthAuto">Location</td>
                        <td class="widthAuto">Created By</td>
                        <td class="statusCol">Status</td>
                        <td class="alignCenter statusCol">Poll</td>
                        <td class="alignCenter statusCol">Invitations</td>
						<td class="alignCenter statusCol">Discussion</td>						
                        <td class="alignCenter statusCol">Ideas</td>
						<td class="alignCenter statusCol">Itinerary</td>
                        <td class="alignCenter statusCol">Expenses</td>
						
					</tr>
					<tr class="lightColorRow nodrop nodrag">
						<td  class="noBorder" colspan="13">&nbsp;</td>
                       
						<!--<td class="noBorder alignCenter"><input type="checkbox" name="t_select_all" id="t_select_all" onclick="javascript:return toggle_select_all('t_select_all','list_form');" /></td>-->
					</tr>
					<?php
						$trip->display_list();
			?>
				</table>
				<?php
			if($trip->num_rows > 0)
			{
			?>
				<table border="0" cellspacing="0" cellpadding="0" class="listing noBorderTop">
					<tr class="footer">
						<td class="noBorder alignRight"><?php
							/*if(isset($_REQUEST['search']) && !isset($_REQUEST['view_all'])) 
							{
								echo '<div class="note txtTheme floatLeft"><span class="txtRed">Note : </span>Ordering is not available with search functionality.</div>';
							}
							else
							{
								echo '<div class="note txtTheme floatLeft"><span class="txtRed">Note : </span>Click and drag the particular row to change the menu item order. Numbering will get updated once the page gets refreshed.</div>';						
							}*/
							?>
							<!--<span>
							<input name="Submit" type="button" value="Check All" class="checkUncheckBtn" onclick="javascript:return select_all('list_form');" />
							/
							<input name="Submit" type="button" value="Uncheck All" class="checkUncheckBtn" onclick="javascript:return unselect_all('list_form');" />
							</span>--></td>
						<td  class="noBorder alignCenter deleteCol">&nbsp;<!--<a style="cursor:pointer;" onclick="return delete_all('list_form', 't_select_all', 'wedding trip');"><img src="images/icon-delete.png" alt="Delete" title="Delete" width="19" height="19" /></a>--></td>
					</tr>
				</table>
				<?php
			}
			?>
				<input type="hidden" name="action_type" value="">
				<input type="hidden" name="search" id="search" value="<?php echo($trip->search);?>" />
				<input type="hidden" name="search_word" id="search_word" value="<?php echo($trip->search_word);?>" />
			</form></td>
	</tr>
	<tr>
		<td colspan="2" bgcolor="#FFFFFF" ><div class="pagination alignCenter">
				<?php 
			$limit1			= functions::$limits;
			$page =  $_GET['page'];
			functions::paginate($trip->num_rows, 1, $trip->pager_param);
			?>
				<div class="clear"></div>
			</div></td>
	</tr>
	<tr>
		<td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
		<td colspan="2" class="bottomRepeat">&nbsp;</td>
		<td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
</table>
<!-- This contains the hidden content for inline calls -->
<?php 
	$template->footer();
?>
