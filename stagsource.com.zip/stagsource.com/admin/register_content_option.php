<?php

/*********************************************************************************************

Author 	: V V VIJESH

Date	: 14-April-2011

Purpose	: Register content_option

*********************************************************************************************/

ob_start();

session_start();

include_once("../includes/config.php");



// Check the admin user is loged in or not

if (!isset($_SESSION[ADMIN_ID]))

{

	functions::redirect("login.php");

	exit;

}



$content_id	= (isset($_REQUEST['content_id']) &&  $_REQUEST['content_id']) > 0 ? $_REQUEST['content_id'] : 0;

//echo "pid=".$content_id;

//exit;

$content 	= new content($content_id);

$content_id	= $content->content_id;



if($content_id == 0)

{

	functions::redirect("manage_content.php?content_id=" . $content_id);

	exit;

}



$content_option_id	= (isset($_REQUEST['content_option_id']) &&  $_REQUEST['content_option_id']) > 0 ? $_REQUEST['content_option_id'] : 0;





$default_page_title		= 'Manage  Option';

$default_page_uri		= 'manage_content_option.php'. "?content_id=" . $content_id;



// Cancel button action starts here

if(isset($_POST['cancel']))	

{

	functions::redirect($default_page_uri);

}



$content_option_length 			= 1000;

// Set template details

$template 				= new template();

$template->type			= 'ADMIN';

$template->left_menu	= true;

$template->admin_id		= $_SESSION[ADMIN_ID];

//$template->title		= $page_title;

//echo URI_LIBRARY;

$template->js			= '

<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>

<script type="text/javascript" language="javascript">



	function fnSetDateFormat(oDateFormat)

	{

		oDateFormat[\'FullYear\'];		

		oDateFormat[\'Year\'];			

		oDateFormat[\'FullMonthName\'];	

		oDateFormat[\'MonthName\'];		

		oDateFormat[\'Month\'];			

		oDateFormat[\'Date\'];			

		oDateFormat[\'FullDay\'];			

		oDateFormat[\'Day\'];				

		oDateFormat[\'Hours\'];			

		oDateFormat[\'Minutes\'];			

		oDateFormat[\'Seconds\'];			

	

		var sDateString;	

		sDateString = oDateFormat[\'Date\'] +"-"+ oDateFormat[\'Month\'] +"-"+ oDateFormat[\'FullYear\'];	

	

		return sDateString;

	}

	function validate_form()

	{

		var forms = document.register_content_option;

		if (!check_blank(forms.title, "Title is required!"))

		{	return false;	}

		if (!check_blank(forms.description, "Description is required!"))

		{	return false;	}
		if (forms.image_required.value == 1)
		{
			if (!check_blank(forms.image_name, "Logo is required!"))
			{	return false;	}
		}

		if (forms.image_required.value == 1)

		{

			if (!check_blank(forms.image_name, "Image is required!"))

			{	return false;	}

		}

		return true;

	}

	
/*function popup_crop_window(image_name)
	{
		url = "crop_image.php?image="+image_name+"&upload_dir_name=content_option&max_width='. BRAND_PORTRAIT_MAX_WIDTH .'&thumb_width='. BRAND_PORTRAIT_THUMB_WIDTH .'&thumb_height='. BRAND_PORTRAIT_THUMB_HEIGHT .'";
		window.open(url,"CropGalleryImage","width=900,height=600,scrollbars=yes,menubar=no");
	}
	*/

</script>';

$template->heading();


//$max_upload_limit	= 1024 * 2;
//$allowed_extensions	= 'jpg,jpeg';
//$image_size			= array(BRAND_PORTRAIT_MIN_WIDTH,BRAND_PORTRAIT_MIN_HEIGHT,BRAND_PORTRAIT_MAX_WIDTH,BRAND_PORTRAIT_MAX_HEIGHT, BRAND_PORTRAIT_THUMB_WIDTH, BRAND_PORTRAIT_THUMB_HEIGHT, 0, 0);





// Save button action starts here

if(isset($_POST['save']))

{

	$content_option						= new content_option();

	$content_option->content_option_id	= $content_option_id;

	$content_option->content_id			= $content_id;

	$content_option->title				= functions::clean_string($_POST['title']);
	
	
	//$current_image_name		= functions::clean_string($_POST['current_image_name']);

	$content_option->description		= functions::clean_string($_POST['description']);
	
	//$current_image_name		= functions::clean_string($_POST['current_image_name']);
	
 	//$uploaded_image_name	= $_FILES['image_name'];


	

	$validation		= new validation();

	$validation->check_blank($content_option->title, "Title", "title");

	//$validation->check_blank($content_option->news_date, "Content Option Date", "news_date");	

	$validation->check_blank($content_option->description, "Description", "description");	

	/*if($content_option_id == 0 || is_uploaded_file($uploaded_image_name['tmp_name']))
	{
		//$validation->check_image_size($uploaded_image_name, 'Photo' , "image_name", $image_size);
		$validation->is_uploaded($uploaded_image_name, 'Logo' , "image_name");
	}*/

	if (!$validation->checkErrors())

	{

	$functions		= new functions;
		/*if($content_option_id == 0 || is_uploaded_file($uploaded_image_name['tmp_name']))
		{
			//	echo "here2<br>";
			//$image_name		= $crop_content_option_image_name = $functions->upload_file($uploaded_image_name, DIR_CONTENT_OPTION, 'jpeg,jpg', $max_upload_limit);
			$image_name		= $crop_content_option_image_name = $functions->upload_image($uploaded_image_name, DIR_CONTENT_OPTION, $allowed_extensions, $max_upload_limit, true, false, '', $image_size, false);
			if(!$functions->warning && $current_image_name != '')
			{
				//echo DIR_CONTENT_OPTION . $current_image_name;
				
					//echo "here3<br>";
				if(file_exists(DIR_CONTENT_OPTION . $current_image_name))
				{
						//echo "here4<br>";
					unlink(DIR_CONTENT_OPTION . $current_image_name);
				}
				if(file_exists(DIR_CONTENT_OPTION . 'thumb_' . $current_image_name))
				{
						//echo "here5<br>";
					uncontent_option(DIR_CONTENT_OPTION . 'thumb_' . $current_image_name);
				}
			}
		}
		else
		{
			$image_name		= $current_image_name;
		}*/
		
		
			if(!$functions->warning)
		{
			$content_option->image_name	= $image_name;
			if($content_option->save())
			{
				if($content_option_id == 0)
				{
					$content_option->content_option_id		= 0;
					$content_option->title		= '';
					$content_option->description	= '';
					
				}
			}
		}
		else
		{
			$content_option->message	= $functions->message;
			$content_option->warning	= $functions->warning;
		}
	}
	else
	{
		$content_option->error	= $validation->getallerrors();
		$content_option->warning				 =true;
			
	}
	
	
		
	if(!$content_option->warning)
		{
		  	 $json_var 	= '{"title":"Success", "text":"'.$content_option->message.'","type":"success","width":"100%","url":"manage_content_option.php?content_id='.$content_id.'"}';
			
		  	$notify 	= new notify();
		  	$notify->show_message($json_var);
		}
		if($content_option->warning)
		{
		  	$json_var 	= '{"title":"Error", "text":"'.$content_option->message.'","type":"error","width":"100%"}';
		  	$notify 	= new notify();
		  	$notify->show_message($json_var);
		}

}

else if (!isset($_POST["save"]))

{

	$content_option	= new content_option($content_option_id);

}

?>

<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">

	<tr>

		<td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>

		<td class="topRepeat">&nbsp;</td>

		<td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>

	</tr>

	<tr>

		<td rowspan="2" class="leftRepeat">&nbsp;</td>

		<td bgcolor="#FFFFFF"><div class="contentHeader">

				<div class="pageTitle">

					<?php

					$page_title		= 'Add Option';

					if($content_option->content_option_id > 0)

					{

						$page_title = 'Edit Content Option';

					}

					echo functions::deformat_string($page_title);

					?>

				</div>

				<div class="contentSublinks txtBold"> <img src="images/manage-content_option.png" alt="<?php echo functions::deformat_string($default_page_title); ?>" title="<?php echo functions::deformat_string($default_page_title); ?>" width="24" height="24" class="imgBlock" /> <a href="<?php echo $default_page_uri; ?>"><?php echo functions::deformat_string($default_page_title); ?></a> </div>

			</div>

			

			<div class="spacer"></div></td>

		<td rowspan="2" class="rightRepeat">&nbsp;</td>

	</tr>

	<tr>

		<td bgcolor="#FFFFFF"><form name="register_content_option" id="register_content_option" method="post" action="" enctype="multipart/form-data" >

				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="form">

					<tr>

						<td width="22%" >Title<span class="txtRed">*</span></td>

						<td  width="88%"><input type="text" id="title" name="title" value="<?php echo functions::format_text_field($content_option->title); ?>" class="textbox" maxlength="50" tabindex="1" />

							<?php if(!empty($content_option->error["title"])) { ?>

							<span id="errmesg" class="error"> <?php echo $content_option->error["title"]; ?></span>

							<?php } ?>

							<div class="spacer"></div></td>

					</tr>

					<tr>

						<td>Description<span class="txtRed">*</span></td>

						<td><label>

								<textarea name="description" id="description" cols="45" rows="5" class="textarea" tabindex="2" onKeyDown="limitText(this.form.description,this.form.countdown2,<?php echo $content_option_length; ?>);" onKeyUp="limitText(this.form.description,this.form.countdown2,<?php echo $content_option_length; ?>);"><?php echo functions::format_text_field($content_option->description); ?></textarea>

								<?php if(!empty($content_option->error["description"])) { ?>

								<span id="errmesg" class="error"> <?php echo $content_option->error["description"]; ?></span>

								<?php } ?>

							</label>

							<br>

							Maximum characters: <?php echo $content_option_length; ?> You have

							<input name="countdown2" id="countdown2" type="text" class="admincontent" <?php if($content_option->description!=""){?>value="<?php echo  $content_option_length - strlen($content_option->description);?>"<?php }else{?> value="<?php echo $content_option_length; ?>"<?php }?> size="5" readonly>

							characters left.<br />

							<div class="spacer"></div></td>

					</tr>
                    <?php
                    /*	<tr>
						<td width="12%">Logo<?php
						if($content_option_id == 0)
						{
							echo '<span class="txtRed">*</span>';
						}
						?>
						</td>
						<td width="88%"><table width="100%" border="0" cellpadding="0" cellspacing="0">
								<tbody>
									<tr>
										<td width="100">
												<input name="image_name" id="image_name" tabindex="3" type="file">
												<?php if(isset($content_option->error["image_name"])) { ?>
												<span id="errmesg" class="error"> <?php echo $content_option->error["image_name"]; ?> </span>
												<?php 
												}
												if($content_option->content_option_id>0)
												{
												if($content_option->image_name!='' && file_exists(DIR_CONTENT_OPTION.$content_option->image_name))
												{
													echo '<img src="image_resize.php?image='.$content_option->image_name.'&dir=content_option&width=150&height=120"    border="0" />';
												?>
												
												<!--<img src="<?php echo URI_BRAND_PORTRAIT.$content_option->image_name; ?>" border="0" />-->
												<?php
													}
												}
												
												?>
												
											
																
										</td>
									</tr>
									<tr>
										<td style="padding-left: 20px;" width="155" align="left"></td>
									</tr>
								</tbody>
							</table>
							<span class="info"> (Allowed Image Type: jpg,jpeg <br>
							Min. image size: <?php echo BRAND_PORTRAIT_MIN_WIDTH; ?> X <?php echo BRAND_PORTRAIT_MIN_HEIGHT; ?> pixels <br>
							Max. image size: <?php echo BRAND_PORTRAIT_MAX_WIDTH; ?> X <?php echo BRAND_PORTRAIT_MAX_HEIGHT; ?> pixels)</span>
							<div class="spacer"></div></td>
					</tr>*/
                    ?>

					<tr>

						<td></td>

						<td ><input type="submit" id="button" name="save" value="Save" class="submit" title="Save" tabindex="4" onclick="javascript:return validate_form();" />

							<input type="submit" id="cancel" name="cancel" value="Cancel" class="submit" title="Cancel" tabindex="5" />

							<div class="spacer"></div></td>

					</tr>

					<tr>

						<td colspan="2" class="txtTheme required"><span class="txtRed">*</span> Required fields</td>

					</tr>

				</table>

				<input type="hidden" id="content_option_id" name="content_option_id" value="<?php echo $content_option->content_option_id; ?>" />

				<input type="hidden" id="current_image_name" name="current_image_name" value="<?php echo functions::format_text_field($content_option->image_name); ?>" />

				<input type="hidden" id="image_required" name="image_required" value="<?php echo $content_option_id == 0 ? 1 : 0; ?>" />

			</form></td>

	</tr>

	<tr>

		<td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>

		<td class="bottomRepeat">&nbsp;</td>

		<td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>

	</tr>

</table>

<script language="javascript" type="text/javascript">

limitText(document.forms['register_content_option'].description,document.forms['register_content_option'].countdown2, '<?php echo $content_option_length; ?>');

function limitText(limitField, limitCount, limitNum) {



	if (limitField.value.length > limitNum) {

		limitField.value = limitField.value.substring(0, limitNum);

	} else {

		limitCount.value = limitNum - limitField.value.length;

	}

}

</script>

<?php 

	$template->footer();

?>

