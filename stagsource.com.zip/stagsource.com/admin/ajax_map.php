<?php
/*********************************************************************************************
Author 	: V. V. VIJESH
Date	: 15-Apr-2011
Purpose	: Signup member
*********************************************************************************************/
ob_start("ob_gzhandler");
session_start();
include_once("../includes/config.php");

$property_id	   = (isset($_REQUEST['property_id']) &&  $_REQUEST['property_id']) > 0 ? $_REQUEST['property_id'] : 0;

$schools_name	  = (isset($_REQUEST['schools_name']) &&  $_REQUEST['schools_name']) > 0 ? $_REQUEST['schools_name'] : '';
$long_split		= (isset($_REQUEST['long_split']) &&  $_REQUEST['long_split']) > 0 ? $_REQUEST['long_split'] : '';
$lat_split		 = (isset($_REQUEST['lat_split']) &&  $_REQUEST['lat_split']) > 0 ? $_REQUEST['lat_split'] : '';
$address		   = (isset($_REQUEST['address']) &&  $_REQUEST['address']) > 0 ? $_REQUEST['address'] : '';
$city			  = (isset($_REQUEST['city']) &&  $_REQUEST['city']) > 0 ? $_REQUEST['city'] : '';
$state			 = (isset($_REQUEST['state']) &&  $_REQUEST['state']) > 0 ? $_REQUEST['state'] : '';
$country		   = (isset($_REQUEST['country']) &&  $_REQUEST['country']) > 0 ? $_REQUEST['country'] : '';
$phone			 = (isset($_REQUEST['phone']) &&  $_REQUEST['phone']) > 0 ? $_REQUEST['content_id'] : '';
$website	       = (isset($_REQUEST['website']) &&  $_REQUEST['website']) > 0 ? $_REQUEST['website'] : '';



$schools	= new schools();

$schools->property_id=$property_id;
$schools->schools_name=$schools_name;
$schools->long_split=$long_split;
$schools->lat_split=$lat_split;
$schools->address=$address;
$schools->city=$city;
$schools->state=$state;
$schools->country=$country;
$schools->phone=$phone;
$schools->website=$website;

$schools->save();


?>