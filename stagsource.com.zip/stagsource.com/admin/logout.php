<?php
	/*********************************************************************************************
	Author 	: Dhaval Dave
	Date	: 7th Oct 2010
	Purpose	: This page is used for logout from admin panel.
	*********************************************************************************************/
	ob_start();
	session_start();

	include_once("../includes/config.php");
	include_once("../includes/class.validation.php");
	include_once("../includes/class.function.php");

	$_SESSION[ADMIN_ID]	= '';
	session_unset($_SESSION[ADMIN_ID]);

	functions::redirect("index.php");
?>