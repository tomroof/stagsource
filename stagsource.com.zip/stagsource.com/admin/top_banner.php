<?php
	/*********************************************************************************************
			Author 	: V V VIJESH
			Date	: 10-Nov-2010
			Purpose	: Admin top banner
	*********************************************************************************************/
	ob_start();
	session_start();
	include_once("../includes/config.php");
	?>
<div class="header">
    <div class="logo"><a href="<?php echo URI_ADMIN; ?>"><img src="images/company-logo.png" alt="<?php echo functions::deformat_string(SITE_NAME);?>"  title="<?php echo functions::deformat_string(SITE_NAME);?>"/></a></div>
    <div class="rightBlock">
        <div id="clock" class="timeDate txtSmall"></div>
        <?php
		if(DEVELOPMENT_STAGE && ($_SESSION[ADMIN_ID] == 1))
		//$admin_id_array	= array(1,2);
		//if(in_array($_SESSION[ADMIN_ID], $admin_id_array))
		{
			?>    
			<div class="selectTheme txtSmall">
				<div class="themeColorSelect">Select Theme</div>
				<div class="themeColorSelect"><a style="cursor:pointer" title="Change theme" onclick="javascript: change_admin_theme('<?php echo $_SESSION[ADMIN_ID]; ?>', 'blue');" ><img src="images/blue/theme-blue.jpg" alt="Theme Blue" title="Theme Blue" width="15" height="15" /></a></div>
				<div class="themeColorSelect"><a style="cursor:pointer" title="Change theme" onclick="javascript: change_admin_theme('<?php echo $_SESSION[ADMIN_ID]; ?>', 'orange');" ><img src="images/orange/theme-orange.jpg" alt="Theme Orange" title="Theme Orange" width="15" height="15" /></a></div>
				<div class="themeColorSelect"><a style="cursor:pointer" title="Change theme" onclick="javascript: change_admin_theme('<?php echo $_SESSION[ADMIN_ID]; ?>', 'green');" ><img src="images/green/theme-green.jpg" alt="Theme Green" title="Theme Green" width="15" height="15" /></a></div>
				<div class="themeColorSelect"><a style="cursor:pointer" title="Change theme" onclick="javascript: change_admin_theme('<?php echo $_SESSION[ADMIN_ID]; ?>', 'gray');" ><img src="images/gray/theme-grey.jpg" alt="Theme Grey" title="Theme Gray" width="15" height="15" /></a></div>
			</div>
			<?php
		}
		?>
    </div>
</div>