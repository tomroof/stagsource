<?php
/*********************************************************************************************
Author 	: V V VIJESH
Date	: 14-April-2011
Purpose	: Register member
*********************************************************************************************/
ob_start();
session_start();
include_once("../includes/config.php");
set_time_limit(0);

// Check the admin user is loged in or not
if (!isset($_SESSION[ADMIN_ID]))
{
	functions::redirect("login.php");
	exit; }
$member_id	= (isset($_REQUEST['member_id']) &&  $_REQUEST['member_id']) > 0 ? $_REQUEST['member_id'] : 0;
if($member_id > 0)
{
	$page_title = 'Edit Member';}
else
{
	$page_title = 'Add Member';}

$default_page_title		= 'Manage Member';
$default_page_uri		= 'manage_member.php';
// Cancel button action starts here
if(isset($_POST['cancel']))	
{
	functions::redirect($default_page_uri);}
$address_length 			= 250;
// Set template details
$template 				= new template();
$template->type			= 'ADMIN';
$template->left_menu	= true;
$template->admin_id		= $_SESSION[ADMIN_ID];
//$template->title		= $page_title;
$template->js			= '
<script type="text/javascript" language="javascript" src="' . URI_LIBRARY . 'jquery/jquery-min.js"></script>
<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>
<script type="text/javascript" language="javascript">

	
	function validate_form()
	{
		var forms = document.register_member;
		
	
		if (!check_blank(forms.first_name, "First name  is required!"))
		{	return false;	}
		if (!check_blank(forms.surname, "Surname  is required!"))
		{	return false;	}
		if (!check_blank(forms.address, "Address is required!"))
		{	return false;	}
	
		if (!check_blank(forms.contact_number, "Contact Number is required!"))
		{	return false;	}
		if (!check_blank(forms.email, "Email is required!"))
		{	return false;	}
		if (!check_email(forms.email, "Email is invalid!"))
		{	return false;	}
		/*if (!check_blank(forms.username, "Username is required!"))
		{	return false;	}*/
		
		if(forms.add_edit.value=="add")
		{
			/*if (!check_length(forms.username, 4, 100, "Username  should be more than 4 letters!"))
			{	return false;	}*/
			if (!check_blank(forms.password, "Password  is required!"))
			{	return false;	}
			if (!check_blank(forms.confirm_password, "Confirm Password is required!"))
			{	return false;	}
			if (!check_length(forms.password, 5, 15, "Password  should be between 5 to 15 characters!"))
			{	return false;	}
			if (!check_length(forms.confirm_password, 5, 15, "Confirmation password should be between 5 to 15 characters!"))
			{	return false;	}
			if (!check_compare(forms.password, forms.confirm_password, "Confirmation password is not matching!"))
            {	return false;	}
		}
		
		if(forms.image_name.value != "")
		{
			if(!isValidImage(forms.image_name.value))
		  	{
		  		alert("Invalid file selection!");
			    return false;
	     	 }	
		}
		
		return true;
	}
	
	
	function isValidImage(filename)
    { 
   		file_value = filename;
		var checkimg = file_value.toLowerCase();
		if (!checkimg.match(/(\.jpg|\.jpeg|\.)$/))
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	</script>';


	$template->heading();
	
	$max_upload_limit		= 1024 * 3;
	$allowed_extensions		= 'jpg,jpeg';
	$image_size				= array(MEMBER_MIN_WIDTH,MEMBER_MIN_HEIGHT,MEMBER_MAX_WIDTH,MEMBER_MAX_HEIGHT, MEMBER_THUMB_WIDTH, MEMBER_THUMB_HEIGHT, 0, 0);
	
// Save button action starts here
if(isset($_POST['save']))
{
	$member						= new member();
	$member->member_id			= $member_id;
	$member->username			= functions::clean_string($_POST['email']);
	$member->password			= functions::clean_string($_POST['password']);
	$member->confirm_password	= functions::clean_string($_POST['confirm_password']);
	
	$member->contact_number	= functions::clean_string($_POST['contact_number']);
	$member->contact_person	= functions::clean_string($_POST['contact_person']);
	$member->email			= functions::clean_string($_POST['email']);
	$member->first_name		= functions::clean_string($_POST['first_name']);
	$member->surname		= functions::clean_string($_POST['surname']);
	$member->job_type			= functions::clean_string($_POST['job_type']);
	$member->address	= functions::clean_string($_POST['address']);
	$member->post_code	= functions::clean_string($_POST['post_code']);
	$member->status		= functions::clean_string($_POST['status']);
		
	$uploaded_image_name		= $_FILES['image_name'];
	$current_image_name		= functions::clean_string($_POST['current_image_name']);
		
	$validation		= new validation();
	//$validation->check_blank($member->username, "Username", "username");
	if($member_id ==0)
	{
		 $validation->check_blank($member->password, "Password", "password");
		$validation->check_length($member->password, 5, 15, " Password", "password");
		 $validation->check_blank($member->confirm_password, "Confirmation Password", "confirm_password");
		$validation->check_length($member->confirm_password, 5, 15, "Confirmation Password", "confirm_password");
		$validation->check_compare($member->password, $member->confirm_password, "Confirmation password", "confirm_password");	
	}

	if(is_uploaded_file($uploaded_image_name['tmp_name']))
	{
		$validation->check_min_image_size($uploaded_image_name, 'Image' , "image_name", $image_size);
		//$validation->check_image_size($uploaded_image_name, 'Image' , "image_name", $image_size);
		$validation->is_uploaded($uploaded_image_name, 'Image' , "image_name");
	}		
	
	$validation->check_blank($member->contact_number, "Contact number", "contact_number");
	$validation->check_blank($member->first_name, "First name", "first_name");
	$validation->check_blank($member->surname, "Surname", "surname");
	$validation->check_blank($member->address, "Address", "address");
	$validation->check_blank($member->status, "Status", "status");

	if (!$validation->checkErrors())
	{
		$functions		= new functions;
		if(is_uploaded_file($uploaded_image_name['tmp_name']))
		{
			
			$image_name		= $crop_image_name = $functions->upload_image($uploaded_image_name, DIR_MEMBER, $allowed_extensions, $max_upload_limit, true, false, '', $image_size, false);
			if(!$functions->warning && $current_image_name != '')
			{
				if(file_exists(DIR_MEMBER . $current_image_name))
				{
					unlink(DIR_MEMBER . $current_image_name);
				}
				if(file_exists(DIR_MEMBER . 'thumb_'. $current_image_name))
				{
					unlink(DIR_MEMBER . 'thumb_'. $current_image_name);
				}
				if(file_exists(DIR_MEMBER . 'thumb1_'. $current_image_name))
				{
					unlink(DIR_MEMBER . 'thumb1_'.$current_image_name);
				}
				if(file_exists(DIR_MEMBER . 'thumbresize_'. $current_image_name))
				{
					unlink(DIR_MEMBER . 'thumbresize_'.$current_image_name);
				}
			}
		}
		else
		{
			$image_name		= $current_image_name;
		}
	
		if(!$functions->warning)
		{
			$member->image_name	= $image_name;	
			if($member->save())
			{
				if($member_id == 0)
				{				
					$member->member_id				= 0;
					$member->username				= '';
					$member->password				= '';
					$member->confirm_password		= '';
					$member->contact_number		= '';
					$member->email					= '';
					$member->first_name				= '';
					$member->surname				= '';
					$member->job_type				= '';
					$member->address				= '';
					$member->status				= '';
					//$member->image_name				= '';
					
				}
			}
			
			if(!$member->warning)
			{
				if($crop_image_name != '')
				{
					$json_var 	= '{"title":"Success", "text":"'.$book->message.'","type":"success","width":"100%","url":"manage_member.php?member_id='.$member->member_id.'"}';
				}
				else
				{
					$json_var 	= '{"title":"Success", "text":"'.$book->message.'","type":"success","width":"100%","url":"manage_member.php"}';
				}
				
				$notify 	= new notify();
				$notify->show_message($json_var);
			}
			
		}
		else
		{
			$member->message	= $functions->message;
			$member->warning	= $functions->warning;	
		}
	}
	else
	{
		$member->error	= $validation->getallerrors();
		$member->warning = true;
		if($member->error['image_name'] != '') $member->message = $member->error['image_name'];
	}
	/*if(!$member->warning)
	{
		//$message	= "Success message";
		$json_var 	= '{"title":"Success", "text":"'.$member->message.'","type":"success","width":"100%","url":"manage_member.php"}';
		$notify 	= new notify();
		//$notify->show_message($json_var);
	}*/
	
	if($member->warning)
	{
		$json_var 	= '{"title":"Error", "text":"'.$member->message.'","type":"error","width":"100%"}';
		$notify 	= new notify();
		$notify->show_message($json_var);
	}
		
}
else if (!isset($_POST["save"]))
{
	$member	= new member($member_id);
}
if(isset($_SESSION['message_object']))
{
	$notify = unserialize($_SESSION['message_object']);
	$notify->show_message_redirect();	
	unset($_SESSION['message_object']);
}
?>


<link rel="stylesheet" href="<?php echo URI_LIBRARY; ?>colorbox/colorbox.css" />

<script src="<?php echo URI_LIBRARY; ?>colorbox/jquery.colorbox.js"></script>

<script>

$(document).ready(function()

{
	$('#popupBoxClose').click( function() {			
			unloadPopupBox();
	});
	
	$('.rightBlock, .main, .content').click(function(){
		$("#popup_box").fadeOut("fast");
		$(".main, .rightBlock, .content").css({ // this is just for style
			"opacity": "1" 
		});
	});
});

function unloadPopupBox() {	// TO Unload the Popupbox
	$('#popup_box').fadeOut("fast");
	$(".main, .rightBlock, .content").css({ // this is just for style		
		"opacity": "1"  
	}); 
}


function popup_crop(image_name, member_id)
{
	var thumb_width		= '<?php echo MEMBER_THUMB_WIDTH ?>';
	var thumb_height	= '<?php echo MEMBER_THUMB_HEIGHT ?>';

    $.ajax(
    {
        type: "POST",
        cache: false,
        url: "popup_crop_image.php?folder=member&from=other&id="+member_id+"&thumb_width="+thumb_width+"&thumb_height="+thumb_height,
        success: function (data)
	    {
			$("#inline_content").html(data);
			$.colorbox({href:'#inline_content', inline:true});
        }
    });
}
</script>



<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
	<tr>
		<td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
		<td class="topRepeat">&nbsp;</td>
		<td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
	<tr>
		<td rowspan="2" class="leftRepeat">&nbsp;</td>
		<td bgcolor="#FFFFFF">
			<div class="contentHeader">
				<div class="pageTitle">
					<?php 
					if($member->member_id > 0)
					{
						$page_title = 'Edit Member';
						}
					echo functions::deformat_string($page_title);
					?>
				</div>
			 <div class="contentSublinks txtBold">
            <img src="images/manage-member.png" alt="<?php echo functions::deformat_string($default_page_title); ?>" title="<?php echo functions::deformat_string($default_page_title); ?>" width="24" height="24" class="imgBlock" />
            <a href="<?php echo functions::deformat_string($default_page_uri); ?>"><?php echo functions::deformat_string($default_page_title); ?></a>
        </div>

			
			<div class="spacer"></div></td>
		<td rowspan="2" class="rightRepeat">&nbsp;</td>
	</tr>
	<tr>
		<td bgcolor="#FFFFFF"><form name="register_member" id="register_member" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data" >
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="form">
					
					<tr>
						<td>First Name<span class="txtRed">*</span></td>
                        		<td><input type="text" id="first_name" name="first_name" value="<?php echo functions::format_text_field($member->first_name); ?>" class="textbox" maxlength="200" tabindex="1" />
							<?php if(!empty($member->error["first_name"])) { ?>
							<span id="errmesg" class="error"> <?php echo $member->error["first_name"]; ?></span>
							<?php } ?>
						<div class="spacer"></div></td>
					</tr>
                    
                    <tr>
						<td>Surname<span class="txtRed">*</span></td>
                        		<td><input type="text" id="surname" name="surname" value="<?php echo functions::format_text_field($member->surname); ?>" class="textbox" maxlength="200" tabindex="2" />
							<?php if(!empty($member->error["surname"])) { ?>
							<span id="errmesg" class="error"> <?php echo $member->error["surname"]; ?></span>
							<?php } ?>
						<div class="spacer"></div></td>
					</tr>
                    
                  <tr>
						<td valign="top">Address<span class="txtRed">*</span></td>
						<td>
						 <label>
						 <textarea name="address" id="address" cols="100" rows="15" onKeyDown="limitText(this.form.meta_address,this.form.countdown1,<?php echo $content_length; ?>);" onKeyUp="limitText(this.form.address,this.form.countdown1,<?php echo $address_length; ?>);" class="textarea" tabindex="3"><?php echo functions::format_text_field($member->address); ?></textarea>
						 <?php if(!empty($member->error["address"])) { ?>
						<span id="errmesg" class="error"> <?php echo $member->error["address"]; ?></span>
						<?php } ?>       
						</label>
                          <br>
						Maximum characters: <?php echo $address_length; ?> You have
						<input name="countdown1" id="countdown1" type="text" class="admincontent" <?php if($member->address!=""){?>value="<?php echo  $address_length - strlen($member->address);?>"<?php }else{?> value="<?php echo $address_length; ?>"<?php }?> size="5" readonly>
						characters left.<br />
						<div class="spacer"></div>
						
						<div class="spacer"></div></td>
					  </tr>
                     <tr>
						<td>Contact Number<span class="txtRed">*</span></td>
						<td><input type="text" id="contact_number" name="contact_number" value="<?php echo functions::format_text_field($member->contact_number); ?>" class="textbox" maxlength="250" tabindex="4" />
							<?php if(!empty($member->error["contact_number"])) { ?>
							<span id="errmesg" class="error"> <?php echo $member->error["contact_number"]; ?></span>
							<?php } ?>
						<div class="spacer"></div></td>
					</tr>
                    <tr>
						<td>Email<span class="txtRed">*</span></td>
						<td><input type="text" id="email" name="email" value="<?php echo functions::format_text_field($member->email); ?>" class="textbox" maxlength="250" tabindex="5" />
							<?php if(!empty($member->error["email"])) { ?>
							<span id="errmesg" class="error"> <?php echo $member->error["email"]; ?></span>
							<?php } ?>
						<div class="spacer"></div></td>
					</tr>
                   
                    <!--<tr><input type="hidden" id="current_image_name" name="current_image_name" value="<?php echo $member->image_name; ?>" />
						<td width="22%">Username<span class="txtRed">*</span></td>
						<td width="88%">
							<input type="text" id="username" name="username" autocomplete="off"  value="<?php echo functions::format_text_field($member->username); ?>" class="textbox" maxlength="50" tabindex="6" <?php echo $member->member_id > 0 ? ' readonly="readonly" ' : ''; ?> />
							<?php if(!empty($member->error["username"])) { ?>
							<span id="errmesg" class="error"> <?php echo $member->error["username"]; ?></span>
							<?php } ?>
							<div class="spacer"></div>
						</td>
					</tr>-->
                    
					<?php if($member->member_id == 0)
					{	print "<input type='hidden' value='add' id='add_edit'>";
						?>
                        
					 <tr>
				<td width="22%"> Password<span class="txtRed">*</span></td>
				<td width="88%"><input type="password"  autocomplete="off" id="password" name="password" value="<?php echo functions::format_text_field($password); ?>" class="textbox"  tabindex="7" maxlength="15" />
				<?php if(!empty($member->error["password"])) { ?><span id="errmesg" class="error"> <?php echo $member->error["password"]; ?></span><?php } ?>
				<div class="spacer"></div>
				</td>
			  </tr>
			  <tr>
				<td>Confirm Password<span class="txtRed">*</span></td>
				<td ><input type="password" id="confirm_password"  autocomplete="off"  name="confirm_password" value="<?php echo functions::format_text_field($confirm_password); ?>" class="textbox" tabindex="8" maxlength="15" />
				<?php if(!empty($member->error["confirm_password"])) { ?><span id="errmesg" class="error"> <?php echo $member->error["confirm_password"]; ?></span><?php } ?>
				<div class="spacer"></div>
				</td>
			  </tr>
                    <?php
					}
					else
					{
						print "<input type='hidden' value='edit' id='add_edit'>";
					}?>
                    	
					  <tr>
                   
                   <tr>
			<td width="12%">Profile Image
			</td>
			<td width="88%"><table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tbody>
					<tr>
						<td width="100">
							<input name="image_name" id="image_name" tabindex="9" type="file">
							<?php if(isset($member->error["image_name"])) { ?>
							<span id="errmesg" class="error"> <?php echo $member->error["image_name"]; ?> </span>
							<?php 
							}
					
					if($member_id > 0 && file_exists(DIR_MEMBER . 'thumb_' . $member->image_name))
					{ ?>
					   <img src="<?php echo URI_MEMBER . 'thumb_' . $member->image_name;?>" border="0" id="thumb_id1" />
					   <!-- <img src="image_resize.php?image=<?php echo $member->image_name; ?>&dir=book&width=100&height=100" border="0"/ id="thumb_id1">--> &nbsp;&nbsp;
				  	<?php	
					} ?> 
           

		            <?php 
					if(file_exists(DIR_MEMBER . $member->image_name) && $member->image_name != '') { 
					
							if(!file_exists(DIR_MEMBER . 'thumb_' . $member->image_name))
							{
							   $size_1	= getimagesize(DIR_MEMBER.$member->image_name);
							  $imageLib = new imageLib(DIR_MEMBER.$member->image_name);
							  //$imageLib->resizeImage(BOOK_THUMB_WIDTH, BOOK_THUMB_HEIGHT, 0);
							  if($size_1[0] > $size_1[1])
							  {
								  $imageLib->resizeImage(MEMBER_THUMB_WIDTH, MEMBER_THUMB_HEIGHT, 2);
							  }
							  else if($size_1[0] < $size_1[1])
							  {
								  $imageLib->resizeImage(MEMBER_THUMB_WIDTH, MEMBER_THUMB_HEIGHT, 1);
							  }
							  else
							  {
								  $imageLib->resizeImage(MEMBER_THUMB_WIDTH, MEMBER_THUMB_HEIGHT, 3);	
							  }
							  $imageLib->saveImage(DIR_MEMBER.'thumb1_'.$member->image_name, 90);
							  unset($imageLib);
							  echo '<img src="'.URI_MEMBER . 'thumb1_'.$member->image_name.'" border="0" id="thumb_id1" />';
							}
					
					?>
                    		
			              &nbsp;&nbsp;<a style="cursor:pointer;"><img src="images/edit-crop-image.png" alt="Create Thumb Image" title="Create Thumb Image" width="15" height="16" onclick="javascript: popup_crop('<?php echo $member->image_name; ?>','<?php echo $member->member_id ?>')" /></a>
					<?php 
					} ?>
							
					</td>
					</tr>
					<tr>
						<td style="padding-left: 20px;" width="155" align="left"></td>
					</tr>
				</tbody>
			</table>
			<span class="info"> (Allowed image type: <?php echo $allowed_extensions; ?> <br>
			Maximum File size: <?php echo $max_upload_limit/1024; ?> MB <br>	
			Min. Image size: <?php echo MEMBER_MIN_WIDTH; ?> X <?php echo MEMBER_MIN_HEIGHT; ?> pixels)</span>
			<div class="spacer"></div>
			</td>
		</tr>
                   
				
						<td>Member Status<span class="txtRed">*</span></td>
						<td>
							<input type="radio" id="status1" name="status" value="Y" <?php echo functions::format_text_field($member->status) == 'Y' || functions::format_text_field($member->status) == '' ? ' checked="checked" ' : ''; ?>  class="checkbox" tabindex="9" />
							Active&nbsp;&nbsp;
							<input type="radio" id="status2" name="status" value="N" <?php echo functions::format_text_field($member->status) == 'N' ? ' checked="checked" ' : ''; ?>  class="checkbox" tabindex="10" />
							Inactive
							<?php if(!empty($member->error["status"])) { ?><span id="errmesg" class="error"> <?php echo $member->error["status"]; ?></span><?php } ?>
							<div class="spacer"></div>
						</td>
					  </tr>
					<tr>
						<td></td>
						<td ><input type="submit" id="button" name="save" value="Save" class="submit" title="Save" tabindex="11" onclick="javascript:return validate_form();" />
							<input type="submit" id="cancel" name="cancel" value="Cancel" class="submit" title="Cancel" tabindex="12" />
							<input type="hidden" id="current_image_name" name="current_image_name" value="<?php echo $member->image_name; ?>" />
							<div class="spacer"></div></td>
					</tr>
					<tr>
						<td colspan="2" class="txtTheme required"><span class="txtRed">*</span> Required fields</td>
					</tr>
				</table>
<input type="hidden" id="member_id" name="member_id" value="<?php echo $member->member_id; ?>" />
			</form></td>
	</tr>
	<tr>
		<td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
		<td class="bottomRepeat">&nbsp;</td>
		<td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
</table>
<script language="javascript" type="text/javascript">
limitText(document.forms['register_member'].address,document.forms['register_member'].countdown1, '<?php echo $address_length; ?>');
function limitText(limitField, limitCount, limitNum)
{	
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		limitCount.value = limitNum - limitField.value.length;
	}
}
</script>






<?php 
	$template->footer();
?>


<div id="popup_box" class="popup" style=" border: 4px solid gray; padding: 10px; overflow:none">	 <!-- overflow:scroll; -->



	<div id="resultcontent"></div>



	<div id="messagecontent"></div>

	<a id="popupBoxClose"><strong>CLOSE</strong></a>	



</div>



<div style="display:none" >

			<div id='inline_content' style="background:#fff;  padding:-10px; position:relative; width:1024px !important; overflow:hidden;">

				

			</div>

		</div>