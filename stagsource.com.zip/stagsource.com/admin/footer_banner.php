<?php
	/*********************************************************************************************
	Author 	: V V VIJESH
	Date	: 04-Nov-2010
	Purpose	: Footer Banner Page
	*********************************************************************************************/
	ob_start();
	session_start();
	include_once("../includes/config.php");
	?>
<div id="footer">
   	  <div class="footerTop txtTheme txtSmall">
        	<span class="txtRed">WARNING !</span> Access and use of this section by anyone without permission of the owner of <a href="<?php echo SITE_URL; ?>" target="_blank"><?php echo functions::deformat_string(SITE_NAME); ?></a> is strictly prohibited.<br />

An unauthorized user, including employees are subject to criminal and civil penalties, as well as Company initiated disciplinary action.      <br />
  Best viewed with  screen resolution  1280 * 960 or higher.</div>
    <div class="footerBottom">
   	  <div class="copyright txtSmall">&copy; <?php echo date('Y') . ' ' . functions::deformat_string(SITE_NAME); ?>. All rights reserved. </div>
        <!-- <div class="compInfo txtSmall">Developed By: <a href="" target="_blank"></a></div> -->
		<div class="compInfo txtSmall">
		<?php
		$this->footer_branding();
		?>
		</div>
    </div>
    </div>