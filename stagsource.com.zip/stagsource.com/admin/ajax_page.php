<?php
/*********************************************************************************************
Author 	: V. V. VIJESH
Date	: 15-Apr-2011
Purpose	: Signup quote
*********************************************************************************************/
ob_start("ob_gzhandler");
session_start();
include_once("includes/config.php");

$quote 				= new quote();
$quote->status		= isset($_REQUEST['status']) && $_REQUEST['status'] != '' ? $_REQUEST['status'] : '';
$quote->quote_id	= isset($_REQUEST['quote_id']) && $_REQUEST['quote_id'] != '' ? $_REQUEST['quote_id'] : '';
$status=  $quote->update_status($quote->quote_id,$quote->status);

?>