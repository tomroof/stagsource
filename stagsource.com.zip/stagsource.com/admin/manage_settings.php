<?php
	/*********************************************************************************************
			Author 	: V V VIJESH
			Date	: 04-Nov-2010
			Purpose	: Edit website settings
	*********************************************************************************************/
	ob_start();
	session_start();
	include_once("../includes/config.php");
	
	// Check the admin user is loged in or not
	if (!isset($_SESSION[ADMIN_ID]))
	{
		functions::redirect("login.php");
		exit;
	}
	
	$page_title				= 'Manage Settings';
	
	// Cancel button action starts here
	if(isset($_POST['cancel']))	
	{
		functions::redirect('index.php');
	}
	
	// Set template details
	$template 				= new template();
	$template->type			= 'ADMIN';
	$template->left_menu	= true;
	$template->admin_id		= $_SESSION[ADMIN_ID];
	//$template->title		= $page_title;
	$template->js			= '
	<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>
	<script type="text/javascript" language="javascript">
	function limitText(limitField, limitCount, limitNum) {
	   
		if (limitField.value.length > limitNum) {
			limitField.value = limitField.value.substring(0, limitNum);
		} else {
			limitCount.value = limitNum - limitField.value.length;
		}
	}
	</script>
	';
	$template->heading();
	
	$admin_id	= (isset($_REQUEST['admin_id']) &&  $_REQUEST['admin_id']) > 0 ? $_REQUEST['admin_id'] : 0;
	
	// Save button action starts here
	if(isset($_POST['save']))
	{
		$database	= new database();
		$sql		= "SELECT * FROM settings where display = 'Y'";
		$result		= $database->query($sql);
		while($data	= $result->fetch_object())
		{
			$settings			= new settings();
			$settings->keys		= $data->keys;
			$settings->values	= functions::deformat_string($_POST[$data->keys]);
			$caption			= functions::deformat_string($data->caption);
			
			$validation	= new validation();
			$validation->check_blank($settings->values, $caption, $settings->keys);
			
			if (!$validation->checkErrors())
			{
				$settings->save();
			}
			else
			{
				$settings->error	= $validation->getallerrors();
			}
		}
		
		if($settings->warning)
		{
			$json_var 	= '{"title":"Error", "text":"'.$settings->message.'","type":"error","width":"100%"}';
			$notify 	= new notify();
			$notify->show_message($json_var);
		}else{
			$json_var 	= '{"title":"Success", "text":"'.$settings->message.'","type":"success","width":"100%","url":"manage_settings.php"}';			
			$notify 	= new notify();
			$notify->show_message($json_var);		
		}
	}
	
	if(isset($_SESSION['message_object']))
	{
		$notify = unserialize($_SESSION['message_object']);
		$notify->show_message_redirect();	
		unset($_SESSION['message_object']);
	}
	
	?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
  <tr>
    <td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
    <td class="topRepeat">&nbsp;</td>
    <td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
  </tr>
  <tr>
    <td rowspan="2" class="leftRepeat">&nbsp;</td>
    <td bgcolor="#FFFFFF">
        <div class="contentHeader">
        	<div class="pageTitle"><?php echo functions::deformat_string($page_title); ?></div>
        </div>
        <?php if(!empty($settings->message)) { ?>
            <span class="<?php echo $settings->warning ? 'warningMesg' : 'infoMesg'; ?> formPageWidth">
            <?php echo $settings->message; ?>
            </span>
        <?php } ?>
        <div class="spacer"></div>
      </td>
    <td rowspan="2" class="rightRepeat">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">
    	<form name="compose_form" id="compose_form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
        <table width="100%" border="0" cellspacing="0" cellpadding="0" class="form">
        <?php
		$count = 1;
		$database	= new database();
		$sql		= "SELECT * FROM settings  where display = 'Y'";
		$result		= $database->query($sql);
		while($data	= $result->fetch_object())
		{
			$keys		= functions::format_text_field($data->keys);
			$values		= functions::format_text_field($data->values);
			$caption	= functions::deformat_string($data->caption);
						
			if($keys=="META_KEYWORDS")
			{
				$meta_keywords_max_length="3000";
			?>
            <tr>
            <td width="20%"><?php echo $caption; ?><span class="txtRed">*</span></td>
            <td width="80%">
            	<textarea id="<?php echo $keys; ?>" name="<?php echo $keys; ?>" cols="45" rows="4" class="textarea" tabindex="<?php echo $count++; ?>" onkeydown="limitText(this.form.META_KEYWORDS,this.form.countdown1,<?php echo $meta_keywords_max_length; ?>);" 
onkeyup="limitText(this.form.META_KEYWORDS,this.form.countdown1,<?php echo $meta_keywords_max_length; ?>);"><?php echo $values; ?></textarea> <br />Maximum characters: <?php echo $meta_keywords_max_length; ?> You have
<input type="text" name="countdown1" id="countdown1" <?php if(!empty($admin->error[$keys])){?>value="<?php echo $_REQUEST['countdown1']; ?>"<?php }else{?> value="<?php echo $meta_keywords_max_length; ?>"<?php }?> size="2" readonly="readonly" />
characters left.   
                <?php if(!empty($admin->error[$keys])) { ?><span id="errmesg" class="error"><?php echo $admin->error[$keys]; ?> </span><?php } ?>
                
                </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td class="txtTheme noLineHeight note"><span class="txtRed">*SEO Hint:</span> Don't repeat a keyword more than 4 times. <div class="spacer"></div></td>
            </tr>  
            <?php
			}
			else if($keys=="META_DESCRIPTION")
			{
				$meta_description_max_length="3000";
			?>
            <tr>
            <td width="20%"><?php echo $caption; ?><span class="txtRed">*</span></td>
            <td width="80%">
              <textarea id="<?php echo $keys; ?>" name="<?php echo $keys; ?>" cols="45" rows="5" class="textarea" tabindex="<?php echo $count++; ?>" onkeydown="limitText(this.form.META_DESCRIPTION,this.form.countdown2,<?php echo $meta_description_max_length; ?>);" 
onkeyup="limitText(this.form.META_DESCRIPTION,this.form.countdown2,<?php echo $meta_description_max_length; ?>);"><?php echo $values; ?></textarea> <br />Maximum characters: <?php echo $meta_description_max_length; ?> You have
<input type="text" name="countdown2" id="countdown2" <?php if(!empty($admin->error[$keys])){?>value="<?php echo $_REQUEST['countdown2']; ?>"<?php }else{?> value="<?php echo $meta_description_max_length; ?>"<?php }?> size="2" readonly="readonly" />
characters left.            
                <?php if(!empty($admin->error[$keys])) { ?><span id="errmesg" class="error"><?php echo $admin->error[$keys]; ?> </span><?php } ?>
               
                </td>
          </tr>
          <tr>
        <td>&nbsp;</td>
        <td class="txtTheme noLineHeight note"><span class="txtRed">*SEO Hint:</span> Commonly used as Search result description. <div class="spacer"></div></td>
      </tr>
            <?php 
			}
			else if($keys=="CONTACT_ADDRESS" or $keys=="WA_OFFICE_ADDRESS")
			{
			?>
            <tr>
            <td width="20%"><?php echo $caption; ?><span class="txtRed">*</span></td>
            <td width="80%">
              <textarea id="<?php echo $keys; ?>" name="<?php echo $keys; ?>" cols="45" rows="5" class="textarea" tabindex="<?php echo $count++; ?>"><?php echo $values; ?></textarea>
                <?php if(!empty($admin->error[$keys])) { ?><span id="errmesg" class="error"><?php echo $admin->error[$keys]; ?> </span><?php } ?>
				<div class="spacer"></div>
                </td>
         	</tr>
			<?php 
			}
			else if($keys=="FOOTER_EMAIL_ID")
			{
			//echo 'here';
			?>
            <tr>
            <td width="20%"><?php echo $caption; ?><span class="txtRed">*</span></td>
            <td width="80%">
              <textarea id="<?php echo $keys; ?>" name="<?php echo $keys; ?>" cols="45" rows="5" class="textarea" tabindex="<?php echo $count++; ?>"><?php echo $values; ?></textarea>
			    <br />Press enter key to add email id.
                <?php if(!empty($admin->error[$keys])) { ?><span id="errmesg" class="error"><?php echo $admin->error[$keys]; ?> </span><?php } ?>
				<div class="spacer"></div>
				
                </td>
         	</tr>
            <?php 
			} 			
			else{
			?>
          <tr>
            <td width="20%"><?php echo $caption; ?><span class="txtRed">*</span></td>
            <td width="80%">
            	<input type="text" id="<?php echo $keys; ?>" name="<?php echo $keys; ?>" value="<?php echo $values; ?>" class="textbox" tabindex="<?php echo $count++; ?>" />
                <?php if(!empty($admin->error[$keys])) { ?><span id="errmesg" class="error"><?php echo $admin->error[$keys]; ?> </span><?php } ?>
                <div class="spacer"></div>
                </td>
          </tr>
          <?php
		} 
		?>
         <?php
		}
		?>
		<tr>
            <td colspan="2" class="txtTheme required">&nbsp;</td>
          </tr>
          <tr>
            <td></td>
            <td>
				<input type="submit" id="save" name="save" value="Save" class="submit" title="Save" tabindex="<?php echo $count++; ?>" />
                <input type="submit" id="cancel" name="cancel" value="Cancel" class="submit" title="Cancel" tabindex="<?php echo $count++; ?>" />
				<div class="spacer"></div></td>
          </tr>
          <tr>
            <td colspan="2" class="txtTheme required"><span class="txtRed">*</span> Required fields</td>
          </tr>
        </table>
      	</form>
      </td>
  </tr>
  <tr>
    <td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
    <td class="bottomRepeat">&nbsp;</td>
    <td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
  </tr>
</table>
<script language="javascript" type="text/javascript">
<!--	
limitText(document.compose_form.META_KEYWORDS,document.compose_form.countdown1, '<?php echo $meta_keywords_max_length; ?>');
limitText(document.compose_form.META_DESCRIPTION,document.compose_form.countdown2, '<?php echo $meta_description_max_length; ?>');
-->
</script>
<?php 
	$template->footer();
?>
