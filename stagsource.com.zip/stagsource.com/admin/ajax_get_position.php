<?php

/*********************************************************************************************

Author 	: V. V. VIJESH

Date	: 15-Apr-2011

Purpose	: Signup member

*********************************************************************************************/

ob_start("ob_gzhandler");

session_start();

include_once("../includes/config.php");

$postcode = functions::clean_string($_REQUEST['postcode']);
$database	= new database();

$sql 		= "select * from postcode where postcode='".$postcode."'";
$result 	= $database->query($sql) or die(mysql_error());
if ($result->num_rows > 0)
{
	while($data=$result->fetch_object())
	{
		echo "0<>".$data->latitude.'<>'.$data->longitude;
	}
}
else
{
	echo "1<>Invalid Postcode";
}

?>