<?php

/*********************************************************************************************

Author 	: SUMITH

Date	: 28-August-2013

Purpose	: Upload single image

*********************************************************************************************/

ob_start("ob_gzhandler");

session_start();

include_once("../includes/config.php");


$id					= (isset($_REQUEST['id']) &&  $_REQUEST['id']) > 0 ? $_REQUEST['id'] : 0;

$news_temp_id		= (isset($_REQUEST['news_temp_id']) &&  $_REQUEST['news_temp_id']) > 0 ? $_REQUEST['news_temp_id'] : 0;

$folder				=  $_REQUEST['folder'];

$type				=  $_REQUEST['type'];

$edit				= (isset($_REQUEST['edit'])) ? $_REQUEST['edit'] : 0;



$_SESSION['upload_id']		= $id;

$_SESSION['upload_type']	= $type; 

$_SESSION['upload_edit']	= $edit;







if($edit ==0)

{

	  $_SESSION['temp_timestamp'];

	  

	  if($news_temp_id !='0' && $news_temp_id !='' && !isset($_SESSION['temp_timestamp']) && $id == 0)

	  {

		  $image_class	= new $folder();

		  $_SESSION['temp_timestamp']	= $image_class->get_timestamp_temp($news_temp_id, $type);

	  }

	  else if($id == 0 && !isset($_SESSION['temp_timestamp']))

	  {

		  $timestamp		= time();

		  $rnum 			= microtime();

		  $rnum			= str_replace("0.", "", $rnum);

		  $rnum			= str_replace(" ", "", $rnum);

		  $unique_number	= $timestamp. $rnum. rand(0,99999);

		  $unique_number	= substr($unique_number,0,15); 

		  

		  $_SESSION['temp_timestamp'] = $unique_number;

	  }

}



/*if($edit == 1)

{

	if($id > 0)

	{

		$image_class	= new $folder($id);

		if($image_class->image_name == '')

		{

			$edit = 0;	

		}

	}

	else if($news_temp_id > 0)

	{

		$image_class	= new $folder();

		if($image_class->get_timestamp_temp($news_temp_id, $type) == '')

		{

			$edit = 0;	

		}

	}

} */

echo '<link rel="stylesheet" type="text/css" href="' . URI_LIBRARY . 'image-upload/css/common.css" media="screen" />';

?>



<!--<link rel="stylesheet" href="<?php echo URI_LIBRARY ?>image-upload/css/bootstrap.min.css">

<link rel="stylesheet" href="<?php echo URI_LIBRARY ?>image-upload/css/blueimp-gallery.min.css">

<link rel="stylesheet" href="<?php echo URI_LIBRARY ?>image-upload/css/jquery.fileupload-ui.css">-->



<link rel="stylesheet" href="<?php echo URI_LIBRARY ?>image-upload/css/bootstrap.min.css">

<link rel="stylesheet" href="<?php echo URI_LIBRARY ?>image-upload/css/blueimp-gallery.min.css">

<link rel="stylesheet" href="<?php echo URI_LIBRARY ?>image-upload/css/jquery.fileupload-ui.css">



 

 <h4>Upload Image</h4>



 <br /> 

	

	<?php

	 	  //Initialize the upload form and listings

	 	  $uploadForm		= new UploadForm(); 		

	      $uploadForm->createSingleForm(false, true, false, false, false, $edit);  //Single form upload(can upload multiple/single files)

	 ?>

	 

<script>





$(function () {

    'use strict';

	

	if(navigator.userAgent.match(/MSIE 8/) || navigator.userAgent.match(/MSIE 9/) || navigator.userAgent.match(/MSIE 7/)){

		$('.progress').hide();	

	}

	

	var folder  = '<?php echo $folder ?>';

	var edit 	= '<?php echo $edit ?>';

	

    // Initialize the jQuery File Upload widget:

    $('#fileupload').fileupload({

        // Uncomment the following to send cross-domain cookies:

        //xhrFields: {withCredentials: true},

        //url: 'server/php/',

		url: 'upload_image.php?folder='+folder,		

		//maxNumberOfFiles:1,

		//singleFileUploads: true,
		acceptFileTypes: /(\.|\/)(jpe?g|png)$/i,
		

		disableImageResize: /Android(?!.*Chrome)|Opera/

        .test(window.navigator && navigator.userAgent),

    	/*imageMaxWidth: 800,

    	imageMaxHeight: 600,

		maxHeight: 800,

		maxWidth: 600,

    	imageCrop: false,*/

		previewMaxWidth:80,

		previewMaxHeight:80,

		imageMaxWidth: 5920,

            // The maximum height of resized images:

        imageMaxHeight: 4080,

		autoUpload: true,

		//disabled:'disabled's

		//limitMultiFileUploads:1

		//disableValidation:true

    });

	



	

	$('#up_file').click(function () {

		var edit 	= '<?php echo $edit ?>';

		var id 		= '<?php echo $id ?>';

		var folder 	= '<?php echo $folder ?>';

		//alert("here");

		/*$.ajax( {

	

			type: "POST",

	

			cache: false,

	

			url: "delete_upload_single.php?folder="+folder+"&id="+id,

				

			success: function (data)

	

			{

				alert(data);	

				

			}

		});*/

	});

	

	$('#fileupload').bind('fileuploadadd', function (e, data) {

		var edit 	= '<?php echo $edit ?>';

		var id 		= '<?php echo $id ?>';

		var folder 	= '<?php echo $folder ?>';

		

		if(edit == 1)

			{

				//$('.template-download').show();

				

				$('.table-striped tr:last').remove();



			}

		

		/*var files =data.result.files;

			var file = files[0];

			alert(file.name);

			

			$('.table').each(function() {

				alert("here");

			}); */

		

		//alert("here");

		

		/*$.ajax( {

	

			type: "POST",

	

			cache: false,

	

			url: "delete_upload_single.php?folder="+folder+"&id="+id,

				

			success: function (data)

	

			{

				alert(data);	

				

			}

		});*/

		/*var maxFiles = 1;

		 var fileCount = data.files.length;

		 alert(fileCount);

        if (fileCount > maxFiles) {

            alert("The max number of files is "+maxFiles);

            return false; 

        }

		else

		{ 	alert("The max number of files is "+maxFiles);

			return true;	

		}*/

		

		if(navigator.userAgent.match(/MSIE 8/) || navigator.userAgent.match(/MSIE 9/) || navigator.userAgent.match(/MSIE 7/)){

			$('.progress').hide();	

		}

	});

		

	$('#fileupload').bind('fileuploadsubmit', function (e, data) {												

		var input = $('#category_id');

    	var inputs = data.context.find(':input');

		

		//if (inputs.filter('[required][value=""]').first().focus().length) {

		if($.trim(inputs.filter('.required').first().val()).length == 0) {

			//return false;

		}

		

		data.formData = inputs.serializeArray();

		data.formData.push({name:'category_id', value:input.val()});

		

		if(navigator.userAgent.match(/MSIE 8/) || navigator.userAgent.match(/MSIE 9/) || navigator.userAgent.match(/MSIE 7/)){

			$('.progress').hide();	

		}

	});


	$('#fileupload').bind('fileuploaddone', function (e, data) {
		
			var edit 	= '<?php echo $edit ?>';

			if(edit == 1)

			{

				//$('.template-download').show();
				//$('.table-striped tr:last').remove();

			}

		

			var files =data.result.files;

			var file = files[0];
			//var err1  = file.error;

			
			if(file.error == '' || typeof file.error == 'undefined' )
			{
				//$('#up_file').attr('disabled','disabled');
	
				$('#image_name').val(file.name);
	
				$('#crop1').show();
	
				
	
				$('#thumb_id1').hide();
	
				
	
				if(navigator.userAgent.match(/MSIE 8/) || navigator.userAgent.match(/MSIE 9/) || navigator.userAgent.match(/MSIE 7/)){
	
					$('.progress').hide();	
	
				}

				show_message({

									title:'Success',

									text:"Image successfully uploaded",

									type:'success',

									width:'100%'

								});

			

				//$.colorbox.close();
			}
			else
			{
				if(navigator.userAgent.match(/MSIE 8/) || navigator.userAgent.match(/MSIE 9/) || navigator.userAgent.match(/MSIE 7/)){
	
					$('.progress').hide();	
	
				}

				show_message({

									title:'Error',

									text:file.error,

									type:'error',

									width:'100%'

								});	
			}

	});

		

	$('#fileupload').bind('fileuploaddestroy', function (e, data) {

		//$('#up_file').removeAttr('disabled');

		$('#image_name').val('');

		$('#crop1').hide();

		$('#thumb_id1').hide();

		

	});

			

	// Load existing files/uploaded files

	singleFormUpload();

	//multipleFormUpload();



});







</script>



