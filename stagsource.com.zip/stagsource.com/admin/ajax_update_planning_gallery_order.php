<?php

/*********************************************************************************************

Date	: 03-July-2012

Purpose	: Update image order

*********************************************************************************************/

ob_start();

session_start();

include_once("../includes/config.php");



$action 		= $_REQUEST['action']; 

//$list_array 	= $_REQUEST['dd-list'];

$list_array_values 	= $_REQUEST['dd-list'];



//print_r($list_array_values);



if(count($list_array_values)>0)	

{

   foreach($list_array_values as $list_array_row)

   {

	   if(strstr($list_array_row,"planning_gallery_"))   $list_array[]= end(explode("planning_gallery_",$list_array_row));

	   else $list_array[]= $list_array_row;

   }

   

   krsort($list_array);     // only if the display order by DESC

  // print_r($list_array);

}

$page		 	= $_REQUEST['page'];

if ($action == "update_order")

{

	planning_gallery::update_list_order($list_array, $page);

}



?>