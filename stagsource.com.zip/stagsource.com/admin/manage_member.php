<?php
	/*********************************************************************************************
			Author 	: V V VIJESH
			Date	: 04-Nov-2010
			Purpose	: Provide general index
	*********************************************************************************************/
	ob_start();
	session_start();
	include_once("../includes/config.php");
	
	// Check the member user is loged in or not
	if (!isset($_SESSION[ADMIN_ID]))
	{
		functions::redirect("login.php");
		exit;
	}
	
	$member_id			= (isset($_REQUEST['member_id']) &&  $_REQUEST['member_id']) > 0 ? $_REQUEST['member_id'] : 0;
	
	$page_title				= 'Manage Member';
	$template 				= new template();
	$template->type			= 'ADMIN';
	$template->left_menu	= true;
	$template->admin_id		= $_SESSION[ADMIN_ID];
	$template->js			= '
	<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>
	<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'member.js"></script>
	<script type="text/javascript" src="' . URI_LIBRARY . 'fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script>
	<script type="text/javascript" src="' . URI_LIBRARY . 'fancybox/source/jquery.fancybox.js?v=2.1.5"></script>
	<link rel="stylesheet" type="text/css" href="' . URI_LIBRARY . 'fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />
	<script type="text/javascript" language="javascript">

	
		function validate_form()
		{	var forms = document.search_form;
			if (!check_blank(forms.search_word ,"Search word is required!"))
			{	return false;	}
			return true;
		}
		
		function reset_password(member_id)
		{
			$.ajax(
			{
				type: "POST",
				cache: false,
				url: "reset-member-password.php?member_id="+member_id,
				success: function (data)
				{
					$.fancybox(data);
				}
			});
		}
	
	</script>
	';
	$template->heading();
	$member = new member();
	
	//print_r($_REQUEST);
	if(isset($_REQUEST['search'])){
		$member->search = true;	
	}
	if(isset($_REQUEST['search_word'])){
		$member->search_word = $_REQUEST['search_word'];	
	}
	if(isset($_REQUEST['member_type'])){
		$member->member_type = $_REQUEST['member_type'];	
	}
	
	if($_REQUEST['odr'] == "ASC"){
		$odr = "DESC";
	}	
	else if($_REQUEST['odr'] == "DESC"){
		$odr = "ASC";
	}	
	else{
		$odr = "ASC";
	}	
	
	//$member->odr = $odr;
	$member->sorting_param = $_REQUEST['sorting_param'];
	//echo "<br />Order is : ".$member->odr;
	if(isset($_REQUEST['search']) && !isset($_REQUEST['view_all'])) 
	{
		$member->search_word		= functions::clean_string($_REQUEST['search_word']);
		$member->member_type	= $_REQUEST['member_type'];
		$validation					= new validation();
		if($_REQUEST['search'] == 'Go'){
		$validation->check_blank($search_word, 'Search word', 'search_word');	
			
		}	
		if ($validation->checkErrors())
		{
			$member->error	= $validation->getallerrors();
		}
	}
	
	if(isset($_REQUEST['view_all'])) 
	{
		functions::redirect('manage_member.php');
	}
	
if(isset($_POST['action_type']) && $_POST['action_type']=="delete")
{
	$selected_id	= array();
	if( count($_POST['checkbox']) > 0)
	{   
		foreach($_POST['checkbox'] as $id => $val)
		{
			$selected_id[] = $id;
		}
		$member->remove_selected($selected_id);
	}
	else
	{
		//$member->warning = "Select atleast one member to delete";
		$member->warning = true;
	}
	
	if(!$member->warning)
	{					
		$json_var 	= '{"title":"Success", "text":"'.$member->message.'","type":"success","width":"100%","url":"manage_member.php"}';
		$notify 	= new notify();
		$notify->show_message($json_var);
	}
}
if($member->warning)
		{
			$json_var 	= '{"title":"Error", "text":"'.$member->message.'","type":"error","width":"100%"}';
			$notify 	= new notify();
			$notify->show_message($json_var);
		}
		else
		{
			$validation		= new validation();
			$member->error	= $validation->getallerrors();
		}
if(isset($_SESSION['message_object']))
{	//echo "dfdsfds";
	$notify = unserialize($_SESSION['message_object']);
	$notify->show_message_redirect();	
	unset($_SESSION['message_object']);
}
?>

<link rel="stylesheet" type="text/css" href="<?php echo URI_LIBRARY ?>image-upload/css/common.css" media="screen" />
<link rel="stylesheet" href="<?php echo URI_LIBRARY ?>colorbox/colorbox.css" />
	<script src="<?php echo URI_LIBRARY ?>colorbox/jquery.colorbox.js"></script>
	<script type="text/javascript" language="javascript">
	function popup_crop_image(member_id)
	{	
		$.ajax(
    	{
			 type: "POST",
	
			cache: false,
	
			url: "popup_crop_image.php?folder=member&from=other&id="+member_id+"&thumb_width=<?php echo MEMBER_THUMB_WIDTH ?>&thumb_height=<?php echo MEMBER_THUMB_HEIGHT ?>",
	
			success: function (data)
	
			{
				$("#inline_content").html(data);
				$.colorbox({href:"#inline_content", inline:true});
	
			}

   	  });
	
	}
	
	</script>
    
    
<!--    <script type="text/javascript" language="javascript" src="<?php echo URI_LIBRARY; ?>jquery/jquery-min.js"></script>-->
    <script type="text/javascript">
	$(document).ready(function()
	{
				
		$('#member_type').keydown(function(e){  
			 if (e.keyCode == 13) {
				 $('#search_form').submit();
			  } 
		});
		
	});
</script>

<?php

if($member_id > 0)
{	
	echo '
	 
	<script type="text/javascript" language="javascript">
		popup_crop_image("'.$member_id.'");
	</script>';
			   
	unset($book_id);
}	

?>


    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
        <tr>
          <td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
          <td colspan="2" class="topRepeat">&nbsp;</td>
          <td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
        </tr>
        <tr>
          <td rowspan="3" class="leftRepeat">&nbsp;</td>
          <td colspan="2" bgcolor="#FFFFFF">
             <div class="pageSearchContainer">
              <div class="pageTitle"><?php echo functions::deformat_string($page_title); ?></div>
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="pageSearch">
                      <tr>
                        <td class="pageSearchLeft">&nbsp;</td>
                        <td class="pageSearchBg">
                        <form name="search_form" id="search_form" method="post" action="manage_member.php" > <div class="searchLabel txtBold txtMedium">Search</div>
                              <div class="searchBox"><input name="search_word" type="text" class="textbox" value="<?php echo functions::format_text_field($member->search_word); ?>" tabindex="1" /></div>
							  <!--<div class="searchBox">
							  <select id="member_type" name="member_type" class="dropdown" tabindex="2">
								<option value="0" 
								
							</select>
							  </div>-->
							  <div class="submitBtnArea">
                               <input type="submit" id="search" name="search"  class="go" value="Go" title="Search" tabindex="3"  onclick="javascript:return validate_form();"/>
                        </div><div class="submitBtnArea noMarginRight"><input type="submit" id="view_all" name="view_all" class="submit" value="View All" title="View All" tabindex="4" />
                        </div>
						<input type="hidden" id="page" name="page" value="1" />
                        </form>
                        </td>
                        <td class="pageSearchRight">&nbsp;</td>
                      </tr>
                    </table>
               </div>
               <div class="contentSublinks txtBold">
				<?php
				$page_name	= 'register_member.php';
				$page_title	= 'Add Member';
				?>
               <img src="images/add-member.png" alt="<?php echo $page_title; ?>" title="<?php echo $page_title; ?>" width="30" height="24" class="imgBlock" /> <a href="<?php echo $page_name; ?>"><?php echo $page_title; ?></a>
               </div>
               <div class="clearFloat"></div>
				<?php if(!empty($member->message)) { ?>
				<span class="<?php echo $member->warning ? 'warningMesg' : 'infoMesg'; ?>  formPageWidth">
				<?php echo $member->message; ?> <div class="spacer"></div>
				</span>
				<?php } ?>
            </td>
          <td rowspan="3" class="rightRepeat">&nbsp;</td>
        </tr>
        <tr>
          <td colspan="2" bgcolor="#FFFFFF">
          	<form name="list_form" method="post">
          	<table border="0" cellspacing="0" cellpadding="0" class="listing">
              <tr class="header">
              	<td class="pageNumberCol alignCenter">No.</td>
                <td class="widthAuto">Name</td>
                <!--<td class="usernameCol">Username</td>-->
              	<td class="emailCol">Email</td>
				 <td class="alignCenter joiningDateCol">Joining Date</td>
                <td class="alignCenter resetPassCol">Reset Password</td>
                <td class="alignCenter statusCol">Status</td>
                <td class="alignCenter editCol">Edit</td>
                <td class="alignCenter deleteCol">Delete</td>
              </tr>
              <tr class="lightColorRow">
                <td  class="noBorder" colspan="7">&nbsp;</td>
                <td  class="noBorder alignCenter"><input type="checkbox" name="t_select_all" id="t_select_all" onclick="javascript:return toggle_select_all('t_select_all','list_form');" /></td>
              </tr>
				<?php
				$member->display_list();
				?>
				<tr class="footer">
                <?php
				if(	$member->num_rows>0)
				{
					?>
				<td colspan="7" class="noBorder alignRight"><span>
                
				<input name="Submit" type="button" value="Check All" class="checkUncheckBtn" onclick="javascript:return select_all('list_form');" />        
				/ <input name="Submit" type="button" value="Uncheck All" class="checkUncheckBtn" onclick="javascript:return unselect_all('list_form');" />
	</span>
				</td>
				<td  class="noBorder alignCenter"><a style="cursor:pointer;" onclick="return delete_all('list_form', 't_select_all', 'member');"><img src="images/icon-delete.png" alt="Delete" title="Delete" width="19" height="19" /></a></td>
				<?php
				} ?></tr>
            </table>
            <input name="action_type" type="hidden" value="">
            <input type="hidden" name="sorting_param" id="sorting_param" value="<?php echo($member->pager_param);?>" />
            <input type="hidden" name="search" id="search" value="<?php echo($member->search);?>" />
            <input type="hidden" name="search_word" id="search_word" value="<?php echo($member->search_word);?>" />
            <input type="hidden" name="odr" id="odr" value="<?php echo($odr);?>" />
            </form>
          </td>
        </tr>
        <tr>
          <td colspan="2" bgcolor="#FFFFFF" >
          	<div class="pagination alignCenter">
			<?php
			$totAllRows=$member->num_rows;
			functions::paginate($totAllRows,1,$member->pager_param); 
            ?>
            <div class="clear"></div>			
			</div>
          </td>
        </tr>
        <tr>
          <td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
          <td colspan="2" class="bottomRepeat">&nbsp;</td>
          <td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
        </tr>
      </table>
<?php 
	$template->footer();
?>

<div id="popup_box" class="popup" style=" border: 4px solid gray; padding: 10px; overflow:none">	 <!-- overflow:scroll; -->

	<div id="resultcontent"></div>

	<div id="messagecontent"></div>
	<a id="popupBoxClose"><strong>CLOSE</strong></a>	

</div>

<div style="display:none" >
			<div id='inline_content' style="background:#fff;  padding:-10px; position:relative; width:1024px !important; overflow:hidden;">
				
			</div>
		</div>