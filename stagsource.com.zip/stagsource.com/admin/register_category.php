<?php
/*********************************************************************************************
Author 	: V V VIJESH
Date	: 14-April-2011
Purpose	: Register image category
*********************************************************************************************/
ob_start();
session_start();
include_once("../includes/config.php");

// Check the admin user is loged in or not
if (!isset($_SESSION[ADMIN_ID]))
{
	functions::redirect("login.php");
	exit;
}

$category_id	= (isset($_REQUEST['category_id']) &&  $_REQUEST['category_id']) > 0 ? $_REQUEST['category_id'] : 0;

if($category_id > 0)
{
	$page_title = 'Edit  Category';
}
else
{
	$page_title = 'Add  Category';
}
$default_page_title		= 'Manage  Category';
$default_page_uri		= 'manage_category.php';
// Cancel button action starts here
if(isset($_POST['cancel']))	
{
	functions::redirect($default_page_uri);
}

// Set template details
$template 				= new template();
$template->type			= 'ADMIN';
$template->left_menu	= true;
$template->admin_id		= $_SESSION[ADMIN_ID];
//$template->title		= $page_title;
$template->js			= '
<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>
<script type="text/javascript" language="javascript">
function validate_form()
{
	var forms = document.register_category;
	if (!check_blank(forms.name, " Category Name is required!"))
		{	return false;	}
	/*if (!check_blank(forms.description, "Description is required!"))
		{	return false;	}*/	
	return true;
}
</script>';
$template->heading();

// Save button action starts here
if(isset($_POST['save']))
{
	$category						= new category();
	$category->category_id			= $category_id;
	$category->name					= functions::clean_string($_POST['name']);
	$category->status				= functions::clean_string($_POST['status']);
		
	$validation		= new validation();
	$validation->check_blank($category->name, " Category Name", "name");
	
	
	if (!$validation->checkErrors())
	{
		$category->seo_url		.= '.' . CATEGORY_EXTENSION;
		if($category->save())
		{
			if($category_id == 0)
			{
				$category->category_id		= 0;
				$category->name				= '';
				$category->status			= 'N';
			}
		}
		
		if(!$category->warning)
		{
			//$message	= "Success message";
			$json_var 	= '{"title":"Success", "text":"'.$category->message.'","type":"success","width":"100%","url":"manage_category.php"}';
			
			$notify 	= new notify();
			$notify->show_message($json_var);
		}
	}	
	
		if($category->warning)
		{
			$json_var 	= '{"title":"Error", "text":"'.$category->message.'","type":"error","width":"100%"}';
			$notify 	= new notify();
			$notify->show_message($json_var);
		}
		else
		{
			$category->error	= $validation->getallerrors();
		}
}
else if (!isset($_POST["save"]))
{
	$category	= new category($category_id);
}
if(isset($_SESSION['message_object']))
{
	$notify = unserialize($_SESSION['message_object']);
	$notify->show_message_redirect();	
	unset($_SESSION['message_object']);
}
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
	<tr>
		<td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
		<td class="topRepeat">&nbsp;</td>
		<td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
	<tr>
		<td rowspan="2" class="leftRepeat">&nbsp;</td>
		<td bgcolor="#FFFFFF"><div class="contentHeader">
				<div class="pageTitle">
				<?php
					echo functions::deformat_string($page_title);
				?>
				</div>
				<div class="contentSublinks txtBold"> <img src="images/manage-content.png" alt="<?php echo functions::deformat_string($default_page_title); ?>" title="<?php echo functions::deformat_string($default_page_title); ?>" width="24" height="24" class="imgBlock" /> <a href="<?php echo functions::deformat_string($default_page_uri); ?>"><?php echo functions::deformat_string($default_page_title); ?></a> </div>
			</div>
			<?php //if(!empty($category->message)) { ?>
			<span class="<?php //echo $category->warning ? 'warningMesg' : 'infoMesg'; ?>  formPageWidth"> <?php //echo $category->message; ?> </span>
			<?php //} ?>
			<div class="spacer"></div></td>
		<td rowspan="2" class="rightRepeat">&nbsp;</td>
	</tr>
	<tr>
		<td bgcolor="#FFFFFF"><form name="register_category" id="register_category" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="form">
					
					<tr>
						<td width="12%"> Category  Name<span class="txtRed">*</span></td>
						<td width="88%"><input type="text" id="name" name="name" value="<?php echo functions::format_text_field($category->name); ?>" class="textbox" maxlength="50" tabindex="2" />
							<?php if(!empty($category->error["name"])) { ?>
							<span id="errmesg" class="error"> <?php echo $category->error["name"]; ?></span>
							<?php } ?>
							<div class="spacer"></div>
						</td>
					</tr>
					<?php /*?><tr>
						<td>SEO URL<span class="txtRed">*</span></td>
						<td><input type="text" id="seo_url" name="seo_url" onkeyup="javascript: filter_string();" value="<?php 
							$seo_url = '';
							if($category->seo_url != '')
							{
								$seo_url = str_replace('.' . CATEGORY_EXTENSION, '', $category->seo_url);
							}
							echo functions::format_text_field($seo_url); ?>" class="textbox" maxlength="100" tabindex="2" <?php echo $category->seo_url_edit == 'N' ? ' readonly="readonly" ' : '' ?>   /><?php echo '.' . CATEGORY_EXTENSION; ?>
							<div class="txtTheme noLineHeight note"><span class="txtRed">*Note : </span>Maximum 100 characters allowed.</div>
							<?php if(!empty($category->error["seo_url"])) { ?>
							<span id="errmesg" class="error"> <?php echo $category->error["seo_url"]; ?></span>
							<?php } ?>
							<div class="spacer"></div></td>
					</tr>
					<tr>
						<td width="19%">Description</td>
						<td>
							<textarea name="description" id="description" cols="45" rows="5" tabindex="3" class="textarea"><?php echo functions::deformat_string($category->description); ?></textarea>										
							<?php if(!empty($category->error["description"])) { ?>
								<span id="errmesg" class="error"> <?php echo $category->error["description"]; ?></span>
							<?php } ?>
							<div class="spacer"></div>
						</td>
					</tr><?php */?>
					<tr>
						<td width="12%">Status</td>
						<td width="88%"><input type="radio" id="enable" name="status" value="Y" <?php echo $category->status == 'Y' || $category->status == ''? ' checked="checked" ' : ''; ?> class="checkbox" tabindex="3" />
							Active&nbsp;&nbsp;
							<input type="radio" id="disable" name="status" value="N" <?php echo $category->status == 'N'  ? ' checked="checked" ' : ''; ?>  class="checkbox" tabindex="4" />
							
							Inactive
							<?php if(!empty($category->error["status"])) { ?>
							<span id="errmesg" class="error"> <?php echo $category->error["status"]; ?></span>
							<?php } ?>
							<div class="spacer"></div></td>
					</tr>
					
					
					<tr>
						<td></td>
						<td ><input type="submit" id="button" name="save" value="Save" class="submit" title="Save" tabindex="5" onclick="javascript:return validate_form();" />
							<input type="submit" id="cancel" name="cancel" value="Cancel" class="submit" title="Cancel" tabindex="6" />
							<div class="spacer"></div></td>
					</tr>
					<tr>
						<td colspan="2" class="txtTheme required"><span class="txtRed">*</span> Required fields</td>
					</tr>
				</table>
				<input type="hidden" id="category_id" name="category_id" value="<?php echo $category_id; ?>" />
			</form></td>
	</tr>
	<tr>
		<td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
		<td class="bottomRepeat">&nbsp;</td>
		<td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
</table>
<?php 
	$template->footer();
?>
