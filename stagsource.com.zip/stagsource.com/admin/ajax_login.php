<?php
/*********************************************************************************************
Author 	: V. V. VIJESH
Date	: 15-Apr-2011
Purpose	: Signup member
*********************************************************************************************/
ob_start("ob_gzhandler");
session_start();
include_once("../../fashionaires/includes/config.php");

$member 				= new member();
$member->username		= isset($_REQUEST['username']) && $_REQUEST['username'] != '' ? $_REQUEST['username'] : '';
$member->password		= isset($_REQUEST['password']) && $_REQUEST['password'] != '' ? $_REQUEST['password'] : '';
$forgot_password		= isset($_REQUEST['forgot_password']) && $_REQUEST['forgot_password'] == 1 ? 1 : '0';

if($member->validate_login())
{
	$_SESSION[MEMBER_ID]		= $member->member_id;
	$_SESSION['member_type']	= $member->member_type_id;
	echo '1|';
	?>
	<ul>
		<li>Welcome <?php echo functions::deformat_string($member->name); ?></li>
		<li><a href="../../fashionaires/profile.php">My Profile</a></li>
		<li><a href="../../fashionaires/logout.php">Log out</a></li>
	</ul>
	<?php
}
else
{
	echo '0|' . $member->message;
	if($forgot_password == 1)
	{
		echo '<br />Forgot Password? <a href="forgot_password.php?id=' . $member_type .'" > Click here </a>';
	}
}
?>