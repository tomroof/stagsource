<?php 
ob_start();
session_start();
include_once("../includes/config.php");

$show	= (	isset($_REQUEST['show']) &&  ($_REQUEST['show'] > 0) ) ? trim($_REQUEST['show']) : 0;

$trip_id=$_GET['trip_id'];
if($show==1)
{
	$trip 			= new trip($trip_id);
	$location   	= new location($trip->location_id);
	$member 		= new member($trip->created_by);
?>
<div class="expandSubContent">
<table cellpadding="0" cellspacing="0" width="100%" class="expandDataTable">

	<tr class="">
    	<td width="16%">Trip Name</td><td><?php echo functions::format_text_field($trip->trip_name);?></td></tr>
   		<td>Start Date</td><td><?php echo ($trip->start_date != '0000-00-00') ? date('d-M-Y', strtotime($trip->start_date)): 'No dates decided yet.';?></td></tr>
        <td>End Date</td><td><?php echo ($trip->end_date != '0000-00-00') ? date('d-M-Y', strtotime($trip->end_date)): 'No dates decided yet.';?></td></tr>
		<td>Location</td><td><?php echo ($location->name != '') ? utf8_encode(functions::format_text_field($trip->vendor_name)): 'No location decided yet.';?></td></tr>
          
        <tr><td>Created By</td><td><?php echo  functions::deformat_string($member->first_name); ?></td></tr>
         <tr><td>Organizers</td><td><?php echo  functions::deformat_string($member->first_name); ?></td></tr>
        <tr><td>Welcome Message</td><td><?php echo  nl2br(functions::deformat_string($trip->welcome_message)); ?></td></tr>
		<tr><td>Status</td><td><?php echo functions::deformat_string($trip->status_array[$trip->status]);?></td></tr>
	
      
		<tr><td>Added Date</td><td><?php echo date('d-m-Y', strtotime($trip->added_date)) ;?></td></tr>
	</tr>
</table>
</div>
<?php 
}
?>
