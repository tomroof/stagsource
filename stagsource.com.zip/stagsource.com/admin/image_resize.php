<?php
/*********************************************************************************************
Author 	: VIJESH V V
Date	: 25-Apr-2013
Purpose	: Content page
*********************************************************************************************/
ob_start("ob_gzhandler");
session_start();
include_once("../includes/config.php");

$width			= $_REQUEST['width'];
$height			= $_REQUEST['height'];
$upload_dir		= DIR_ROOT . 'userfiles/' . $_REQUEST['dir'] . '/';
$path			= $upload_dir . $_REQUEST['image'];
$thumb			= new thumbnail($path);
$thumb->resize($width,$height);
$thumb->show(100);
?>