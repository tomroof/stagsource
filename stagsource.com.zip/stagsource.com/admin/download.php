<?php
/*********************************************************************************************
		Author 	: SUMITH
		Date	: 10-02-2014
		Purpose	: Dowload Media Items
*********************************************************************************************/

ob_start();
session_start();
include_once("../includes/config.php");

$download_id	= (isset($_REQUEST['download_id']) &&  $_REQUEST['download_id']) > 0 ? $_REQUEST['download_id'] : 0;

$download = new download($download_id);
$file= DIR_DOWNLOADS.$download->item_name;
$filename = substr($download->item_name,33);

header('Content-Description: File Transfer');
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=".$filename);
header('Content-Transfer-Encoding: binary');
header("Pragma: no-cache");
header("Expires: 0");
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($file));
ob_clean();
flush();
readFile($file);  
exit;
   
?>