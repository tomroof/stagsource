<?php
/*********************************************************************************************
Date	: 14-April-2011
Purpose	: Register property category
*********************************************************************************************/
ob_start();
session_start();
include_once("../includes/config.php");

// Check the admin user is loged in or not
if (!isset($_SESSION[ADMIN_ID]) && !isset($_SESSION[AGENT_ID]))
{
	functions::redirect("login.php");
	exit;
}

$property_category_id	= (isset($_REQUEST['property_category_id']) &&  $_REQUEST['property_category_id']) > 0 ? $_REQUEST['property_category_id'] : 0;

if($property_category_id > 0)
{
	$page_title = 'Edit Property Category';
}
else
{
	$page_title = 'Add Property Category';
}
$default_page_title		= 'Manage Property Category';
$default_page_uri		= 'manage_category.php';
// Cancel button action starts here
if(isset($_POST['cancel']))	
{
	functions::redirect($default_page_uri);
}

// Set template details
$template 				= new template();
$template->type			= 'ADMIN';
$template->left_menu	= true;
$template->admin_id		= $_SESSION[ADMIN_ID];
//$template->title		= $page_title;
$template->js			= '
<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>
<script type="text/javascript" language="javascript">
function validate_form()
{
	var forms = document.register_property_category;
	if (!check_selected(forms.category_name, "Title is required!"))
	{	return false;	}
	return true;
}
</script>';
$template->heading();

// Save button action starts here
if(isset($_POST['save']))
{
	$property_category						= new property_category();
	$property_category->property_category_id	= $property_category_id;
	$property_category->category_name		= functions::clean_string($_POST['category_name']);
	$property_category->status				= functions::clean_string($_POST['status']);
	
	$validation		= new validation();
	$validation->check_blank($property_category->category_name, "Title", "category_name"); 
	if (!$validation->checkErrors())
	{
		if($property_category->save())
		{
			if($property_category_id == 0)
			{
				$property_category->property_category_id	= 0;
				$property_category->category_name		= '';
				$property_category->status				= '';
			}
		}
	}
	else
	{
		$property_category->error	= $validation->getallerrors();
	}
}
else if (!isset($_POST["save"]))
{
	$property_category	= new property_category($property_category_id);
}
?>

<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
	<tr>
		<td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
		<td class="topRepeat">&nbsp;</td>
		<td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
	<tr>
		<td rowspan="2" class="leftRepeat">&nbsp;</td>
		<td bgcolor="#FFFFFF"><div class="contentHeader">
				<div class="pageTitle">
					<?php
					echo functions::deformat_string($page_title);
				?>
				</div>
				<div class="contentSublinks txtBold"> <img src="images/manage-property.png" alt="<?php echo functions::deformat_string($default_page_title); ?>" title="<?php echo functions::deformat_string($default_page_title); ?>" width="24" height="24" class="imgBlock" /> <a href="<?php echo functions::deformat_string($default_page_uri); ?>"><?php echo functions::deformat_string($default_page_title); ?></a> </div>
			</div>
			<?php if(!empty($property_category->message)) { ?>
			<span class="<?php echo $property_category->warning ? 'warningMesg' : 'infoMesg'; ?>  formPageWidth"> <?php echo $property_category->message; ?> </span>
			<?php } ?>
			<div class="spacer"></div></td>
		<td rowspan="2" class="rightRepeat">&nbsp;</td>
	</tr>
	<tr>
		<td bgcolor="#FFFFFF"><form name="register_property_category" id="register_property_category" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="form">
					<tr>
						<td width="22%">Title<span class="txtRed">*</span></td>
						<td width="88%"><input type="text" id="category_name" name="category_name" value="<?php echo functions::format_text_field($property_category->category_name); ?>" class="textbox" maxlength="50" tabindex="2" />
							<div class="txtTheme noLineHeight note"><span class="txtRed">*Note: </span>Maximum 50 characters allowed.</div>
							<?php if(!empty($property_category->error["category_name"])) { ?>
							<span id="errmesg" class="error"> <?php echo $property_category->error["category_name"]; ?></span>
							<?php } ?>
							<div class="spacer"></div></td>
					</tr>
					
					
					<tr>
						<td>Status<span class="txtRed">*</span></td>
						<td><input type="radio" id="status1" name="status" value="Y" <?php echo functions::format_text_field($property_category->status) == 'Y' || functions::format_text_field($property_category->status) == '' ? ' checked="checked" ' : ''; ?>  class="checkbox" tabindex="2" />
							Active&nbsp;&nbsp;
							<input type="radio" id="status2" name="status" value="N" <?php echo functions::format_text_field($property_category->status) == 'N' ? ' checked="checked" ' : ''; ?>  class="checkbox" tabindex="2" />
							Inactive
							<?php if(!empty($property_category->error["status"])) { ?>
							<span id="errmesg" class="error"> <?php echo $property_category->error["status"]; ?></span>
							<?php } ?>
							<div class="spacer"></div>
						</td>
					</tr>
					
					
					<tr>
						<td></td>
						<td ><input type="submit" id="button" name="save" value="Save" class="submit" title="Save" tabindex="3" onclick="javascript:return validate_form();" />
							<input type="submit" id="cancel" name="cancel" value="Cancel" class="submit" title="Cancel" tabindex="4" />
							<div class="spacer"></div></td>
					</tr>
					<tr>
						<td colspan="2" class="txtTheme required"><span class="txtRed">*</span> Required fields</td>
					</tr>
				</table>
				<input type="hidden" id="property_category_id" name="property_category_id" value="<?php echo $property_category_id; ?>" />
			</form></td>
	</tr>
	<tr>
		<td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
		<td class="bottomRepeat">&nbsp;</td>
		<td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
</table>
<?php 
	$template->footer();
?>
