<?php
/*********************************************************************************************
Date	: 14-April-2011
Purpose	: Manage gallery
*********************************************************************************************/
ob_start();
session_start();
include_once("../includes/config.php");

// Check the admin user is loged in or not
if (!isset($_SESSION[ADMIN_ID]) && !isset($_SESSION[AGENT_ID]))
{
	functions::redirect("login.php");
	exit;
}

$planning_id		= (isset($_REQUEST['planning_id']) &&  $_REQUEST['planning_id']) > 0 ? $_REQUEST['planning_id'] : 0;

$planning 			= new planning($planning_id);

if($planning->planning_id == 0)
{
	functions::redirect("manage_planning.php");
	exit;
}

$planning_gallery_id			= (isset($_REQUEST['planning_gallery_id']) &&  $_REQUEST['planning_gallery_id']) > 0 ? $_REQUEST['planning_gallery_id'] : 0;


$page_title					= 'Manage Images';	
$template 					= new template();
$template->type				= 'ADMIN';
$template->left_menu		= true;
$template->admin_id			= $_SESSION[ADMIN_ID];
$template->js				= '


	
<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>


<script type="text/javascript" language="javascript" src="' . URI_LIBRARY . 'jquery/jquery.tablednd.js"></script>

	<script type="text/javascript" language="javascript">
	<!--
		function validate_form()
		{
			var forms = document.search_form;
	
			if (!check_blank(forms.search_word, "Search word is required "))
			{	return false;	}
			return true;
		}
		
		$(document).ready(function()
		{
			$("#dd-list").tableDnD(
			{
				onDrop: function(table, row)
				{
					var page = document.getElementById("page").value;
					var order = $.tableDnD.serialize() + "&action=update_order"  + "&page=" + page;
					//alert(order);
					$.post("ajax_update_planning_gallery_order.php", order, function(theResponse){ //alert(theResponse);
					 }); 
				}
			});
			//$("a.grouped_elements").fancybox();
		});
		//-->
	</script>
	
	
';

$template->heading();

$planning_gallery 		= new planning_gallery();
$planning_gallery->planning_id = $planning_id;

if(isset($_REQUEST['search']))
{
	$planning_gallery->search = true;	
}

if(isset($_REQUEST['search_word']))
{
	$planning_gallery->search_word = $_REQUEST['search_word'];	
}

if(isset($_REQUEST['search_word'])) 
{
	$search_word	= functions::clean_string($_REQUEST['search_word']);
	$validation		= new validation();
	
	if($_REQUEST['search'] == 'Go')
	{
		$validation->check_blank($search_word, 'Title', 'search_word');
	}
	
	if ($validation->checkErrors())
	{
		$planning_gallery->error	= $validation->getallerrors();
	}
}	

if(isset($_POST['action_type']) && $_POST['action_type']=="delete")
{
	$selected_id	= array();
	if( count($_POST['checkbox']) > 0)
	{   
		foreach($_POST['checkbox'] as $id => $val)
		{
			$selected_id[] = $id;
		}
		$planning_gallery->remove_selected($selected_id);
	}
	else
	{
		$planning_gallery->warning = "Select atleast one category to delete";
		$planning_gallery->warning = true;
	}
	if(!$planning_gallery->warning)
		{
			//$message	= "Success message";
			$json_var 	= '{"title":"Success", "text":"'.$planning_gallery->message.'","type":"success","width":"100%","url":"manage_planning_gallery.php?planning_id='.$planning_id	.'"}';
			$notify 	= new notify();
			$notify->show_message($json_var);
		}
}
if(isset($_SESSION['message_object']))
{
	$notify = unserialize($_SESSION['message_object']);
	$notify->show_message_redirect();	
	unset($_SESSION['message_object']);
}


planning_gallery::resize_all_images($planning_id);

 ?>
 <link rel="stylesheet" type="text/css" href="<?php echo URI_LIBRARY ?>image-upload/css/common.css" media="screen" />
 <link rel="stylesheet" href="<?php echo URI_LIBRARY; ?>colorbox/colorbox.css" />
<script src="<?php echo URI_LIBRARY; ?>colorbox/jquery.colorbox.js"></script>

	<script type="text/javascript" language="javascript">
	function popup_crop_image(planning_gallery_id)
	{	
		$.ajax(

    	{

			 type: "POST",
	
			cache: false,
	
			url: "popup_crop_image.php?folder=planning_gallery&from=other&id="+planning_gallery_id+"&thumb_width=<?php echo PLANNING_GALLERY_THUMB_WIDTH ?>&thumb_height=<?php echo PLANNING_GALLERY_THUMB_HEIGHT ?>",
	
			success: function (data)
	
			{
				$("#inline_content").html(data);
				$.colorbox({href:"#inline_content", inline:true});
	
			}

   	  });
	
	}
	
	
	function change_status(planning_gallery_id, index)
	{
		$.ajax(
    	{
			 type: "POST",
			cache: false,
			url: "change_planning_gallery_status.php?planning_gallery_id="+planning_gallery_id,
			success: function (data)
			{
				if(data == 0)
				{
					status				= 'Inactive'
					status_image		= 'images/icon-inactive.png';
					member_status_text	= 'Inactive';
				}
				else
				{
					status				= 'Active'
					status_image		= 'images/icon-active.png';
					member_status_text	= 'Active';
				}
				
				$('#status_image_'+index).attr('title',status);
				$('#status_image_'+index).attr('alt',status);
				$('#status_image_'+index).attr('src',status_image);
			}

   	   });	
	}
	
	</script>
    

<?php

if($planning_gallery_id > 0)
{	
	echo '
	 
	<script type="text/javascript" language="javascript">
		popup_crop_image("'.$planning_gallery_id.'");
	</script>';
			   
	unset($planning_gallery_id);
}	


?>


<!-- <link rel="stylesheet" href="<?php echo URI_LIBRARY; ?>imageareaselect/css/imageareaselect-default.css">
<link rel="stylesheet" href="<?php echo URI_LIBRARY; ?>imageareaselect/css/imageareaselect-animated.css">


<script src="<?php echo URI_LIBRARY ?>imageareaselect/scripts/jquery.imgareaselect.js"></script>
<script src="<?php echo URI_LIBRARY ?>imageareaselect/scripts/jquery.imgareaselect.min.js"></script>
<script src="<?php echo URI_LIBRARY ?>imageareaselect/scripts/jquery.imgareaselect.pack.js"></script>-->

<script type="text/javascript">

$(document).ready(function() {


$('#popupBoxClose').click( function() {			

			unloadPopupBox();

		});

		

			function unloadPopupBox() {	// TO Unload the Popupbox

			$('#popup_box').fadeOut("fast");

			$(".main, .rightBlock, .content").css({ // this is just for style		

				"opacity": "1"  

			}); 

		}
		
});

$('.rightBlock, .main, .content').click(function(){
	$("#popup_box").fadeOut("fast");
	$(".main, .rightBlock, .content").css({ // this is just for style
		"opacity": "1" 
	});
});

function show_fancy1()
{
		$.ajax(
		{
			type: "POST",
			cache: false,
			url: 'popup_login1.php',
			success: function (data)
			{
				$.fancybox(data);
			}
		});
}


function show_crop(planning_gallery_id)
{
    var thumb_width		= '<?php echo PLANNING_GALLERY_THUMB_WIDTH ?>';
	var thumb_height		= '<?php echo PLANNING_GALLERY_THUMB_HEIGHT ?>';
	
    $.ajax(

    {

        type: "POST",

        cache: false,

        url: "popup_crop_image.php?folder=planning_gallery&id="+planning_gallery_id+"&thumb_width="+thumb_width+"&thumb_height="+thumb_height,

        success: function (data)

	    {
		    
			//alert(data);
            //$.fancybox(data);
		   /*$('#popup_box').fadeIn("fast");
			$(".main, .rightBlock, .content").css({ // this is just for style
				"opacity": "0.4"  
			});*/
			//$("#resultcontent").html(data);
			$("#inline_content").html(data);
			$.colorbox({href:'#inline_content', inline:true});

        }

    });

}


function show_edit(image_gallery_id)

{
    $.ajax(

    {

        type: "POST",

        cache: false,

        url: "popup_resize_image.php?gid="+image_gallery_id,

        success: function (data)

	    {

           //$.fancybox(data);
		   $('#popup_box').fadeIn("fast");
			$(".main, .rightBox, .content").css({ // this is just for style
				"opacity": "0.4"  
			});
			$("#resultcontent").html(data);

        }

    });

}

</script>



<?php // planning_gallery::resize_all_images($planning_id); ?>


<link rel="stylesheet" href="<?php echo URI_LIBRARY ?>blueimp_gallery/css/blueimp-gallery.min.css">


<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
	<tr>
		<td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
		<td colspan="2" class="topRepeat">&nbsp;</td>
		<td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
	<tr>
		<td rowspan="3" class="leftRepeat">&nbsp;</td>
		<td colspan="2" bgcolor="#FFFFFF"><div class="pageSearchContainer">
				<div class="pageTitle"><?php echo functions::deformat_string($page_title); ?></div>
                
                <table width="100%" border="0" cellspacing="0" cellpadding="0" class="pageSearch">
				  <tr>
					<td class="pageSearchLeft">&nbsp;</td>
					<td class="pageSearchBg">
					<form name="search_form" method="post" action="manage_planning_gallery.php"> <div class="searchLabel txtBold txtMedium">Search </div>
						  <div class="searchBox"><input name="search_word" type="text" class="textbox" value="<?php echo functions::format_text_field($planning_gallery->search_word); ?>" tabindex="1" /><?php if(!empty($planning_gallery->error["search_word"])) { ?><span id="errmesg" class="error"><?php echo $planning_gallery->error["search_word"]; ?> </span><?php } ?></div>
						   <div class="submitBtnArea">
						   <input type="submit" id="search" name="search"  class="go" value="Go" title="Search" tabindex="2"  onclick="javascript:return validate_form();"/>
					</div><div class="submitBtnArea noMarginRight"><input type="button" id="view_all" name="view_all" class="submit" value="View All" title="View All" tabindex="3" onClick="javascript:location.href='manage_planning_gallery.php?planning_id=<?php echo $planning_id ?>';"  />
					</div>
					<input type="hidden" id="page" name="page" value="1" />
                    <input type="hidden" id="planning_id" name="planning_id" value="<?php echo $planning_id ?>" />
					</form>
					</td>
					<td class="pageSearchRight">&nbsp;</td>
				  </tr>
				</table>
                
			</div>
			<div class="contentSublinks txtBold">
				<?php
			$page_name	= 'register_planning_gallery.php';
			$page_title	= 'Add Images';
			?>
				<img src="images/manage-image.png" alt="<?php echo $page_title; ?>" title="<?php echo $page_title; ?>" width="24" height="24" class="imgBlock" /> <a href="<?php echo $page_name . "?planning_id=" . $planning_id; ?>"><?php echo $page_title; ?></a> </div>
			<div class="clearFloat"></div>
			<div class="spacer"></div>
			
			<div class="breadcrumbs txtBold">
			
			<?php
			   $planning				= new planning($planning_id);
		
				echo '<a href="manage_planning.php">Manage Wedding Planning</a> >> '. utf8_encode(functions::deformat_string($planning->vendor_name)). ' >> Manage Images';
			  ?>
			
			<!--<div class="breadcrumbs txtBold"> <a href='manage_property.php'>Manage Property</a> >> Manage Images
			 <div style="position:relative; float:right; margin-right:45px;"><input type="button" name="update_order" id="update_order" class="submit" value="Update" title="Update Order" onclick="javascript:location.reload(true);" /></div> -->
			 </div>
			
			</td>
		<td rowspan="3" class="rightRepeat">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="2" bgcolor="#FFFFFF"><form id="list_form" name="list_form" method="post">
				<table border="0" cellspacing="0" cellpadding="0" class="listing" id="dd-list">
					<tr class="header nodrop nodrag">
						<td class="pageNumberCol alignCenter">No.</td>
						<td class="widthAuto">Title</td>
						<td class="alignCenter editCol">View</td>
						<td class="alignCenter statusCol">Thumbnail</td>
                        <td class="alignCenter statusCol">Status</td>
                        <td class="alignCenter editCol">Edit</td>
						<td class="alignCenter editCol">Delete</td>
					</tr>
					<tr class="lightColorRow nodrop nodrag">
						<td  class="noBorder">&nbsp;</td>
						<td  class="noBorder">&nbsp;</td>
                        <td  class="noBorder">&nbsp;</td>
						<td  class="noBorder">&nbsp;</td>
                        <td  class="noBorder">&nbsp;</td>
						<td  class="noBorder">&nbsp;</td>
						<td class="noBorder alignCenter"><input type="checkbox" name="t_select_all" id="t_select_all" onclick="javascript:return toggle_select_all('t_select_all','list_form');" /></td>
					</tr>
					<?php
			$planning_gallery->display_list();
			?>
				</table>
				<?php
			if($planning_gallery->num_rows > 0)
			{
			?>
				<table border="0" cellspacing="0" cellpadding="0" class="listing noBorderTop">
					<tr class="footer">
						<td class="noBorder alignRight"><?php
							if(isset($_REQUEST['search']) && !isset($_REQUEST['view_all'])) 
							{
								echo '<div class="note  floatLeft"><span class="txtRed">Note : </span><font color="black">Ordering is not available with search functionality.</font></div>';
							}
							else
							{
								echo '<div class="note  floatLeft"><span class="txtRed">Note : </span><font color="black">Please click and drag an entry to re-order. Once refreshed the numbering will update.</font></div>';						
							} 
							?>
							<span>
							<input name="Submit" type="button" value="Check All" class="checkUncheckBtn" onclick="javascript:return select_all('list_form');" />
							/
							<input name="Submit" type="button" value="Uncheck All" class="checkUncheckBtn" onclick="javascript:return unselect_all('list_form');" />
							</span></td>
						<td  class="noBorder alignCenter deleteCol"><a style="cursor:pointer;" onclick="return delete_all('list_form', 't_select_all', 'image');"><img src="images/icon-delete.png" alt="Delete" title="Delete" width="19" height="19" /></a></td>
					</tr>
				</table>
				<?php
			}
			?>
				<input type="hidden" name="action_type" value="">
				<input type="hidden" name="search" id="search" value="<?php echo($planning_gallery->search);?>" />
				<input type="hidden" name="search_word" id="search_word" value="<?php echo($planning_gallery->search_word);?>" />
			</form></td>
	</tr>
	<tr>
		<td colspan="2" bgcolor="#FFFFFF" ><div class="pagination alignCenter">
				<?php 
			$limit1	= functions::$limits;
			$page	=  $_GET['page'];
			functions::paginate($planning_gallery->num_rows, 1, $planning_gallery->pager_param);
			?>
				<div class="clear"></div>
			</div></td>
	</tr>
	<tr>
		<td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
		<td colspan="2" class="bottomRepeat">&nbsp;</td>
		<td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
</table>
<!-- This contains the hidden content for inline calls -->

 <!-- The blueimp Gallery widget -->
<div id="blueimp-gallery" class="blueimp-gallery blueimp-gallery-controls" data-filter=":even">
    <div class="slides"></div>
    <h3 class="title"></h3>
    <!--<a class="prev">‹</a>-->
	<a class="prev">&lsaquo;</a>
   <!-- <a class="next">›</a>-->
    <a class="next">&rsaquo;</a>
    <!--<a class="close">×</a>-->
	<a class="close">&times</a>
    <a class="play-pause"></a>
    <ol class="indicator"></ol>
</div>


<script src="<?php echo URI_LIBRARY ?>blueimp_gallery/js/blueimp-gallery.min.js"></script>


<script type="text/javascript">
$('.example1').click (function (event) {
   event = event || window.event;
   
    var target = event.target || event.srcElement,
        link = target.src ? target.parentNode : target,
        options = {index: link, event: event,carousel: true}, //carousel: true
        links = $("a[class*='example1']"); //this.getElementsByTagName('a');
		
   		blueimp.Gallery(links, options);
});
</script>

<?php 
	$template->footer();
?>

<div id="popup_box" class="popup" style=" border: 4px solid gray; padding: 10px; overflow:none">	 <!-- overflow:scroll; -->

	<div id="resultcontent"></div>

	<div id="messagecontent"></div>
	<a id="popupBoxClose"><strong>CLOSE</strong></a>	

</div>

<div style="display:none" >
			<div id='inline_content' style="background:#fff;  padding:-10px; position:relative; width:1024px !important; overflow:hidden;">
				
			</div>
		</div>
