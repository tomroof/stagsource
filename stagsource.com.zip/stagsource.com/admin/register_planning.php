<?php

/*********************************************************************************************

Date	: 14-April-2011

Purpose	: Register planning

*********************************************************************************************/

ob_start();

session_start();

include_once("../includes/config.php");

//include_once("../library/fckeditor/fckeditor.php");

// Check the admin user is loged in or not

if (!isset($_SESSION[ADMIN_ID]) && !isset($_SESSION[AGENT_ID]))
{
	functions::redirect("login.php");
	exit;
}


$planning					       = new planning();

$planning_id	= (isset($_REQUEST['planning_id']) &&  $_REQUEST['planning_id']) > 0 ? $_REQUEST['planning_id'] : 0;



if($planning_id > 0)
{
	$page_title = 'Edit Wedding Planning';
}
else
{
	$page_title = 'Add Wedding Planning';
}

$default_page_title				= 'Manage Wedding Planning';
$default_page_uri				= 'manage_planning.php';

$your_picks_description_length 	= 1000;
$features_length 				= 1000;
$location_description_length	= 1000;
$guest_favourites_length	 	= 1000;
$whywe_like_length				= 1000;
$overview_length				= 1000;

$yelp_length					= 500;
$other_resources_length			= 500;
$comments_length				= 500;
$address_length					= 500;

// Cancel button action starts here

if(isset($_POST['cancel']))	

{
	functions::redirect($default_page_uri);

}


// Set template details



$template 				= new template();

$template->type			= 'ADMIN';

$template->left_menu	= true;

$template->admin_id		= $_SESSION[ADMIN_ID];

//$template->title		= $page_title;

$template->js			= '

	<link rel="stylesheet" type="text/css" href="'.URI_LIBRARY.'autocomplete/styles/autoSuggest.css">

	<script src="'.URI_LIBRARY.'autocomplete/js/jquery.autoSuggestPostCode.js"></script>

	<script src="'.ADMIN_JS_PATH.'autosuggest_postcode.js"></script>

	<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>

	<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'planning.js"></script>';

$template->css ='';	

$template->heading();

// Save button action starts here

if(isset($_POST['save']))
{
	$planning->planning_id				= $planning_id;
	$planning->party_type_id 	 	  	= functions::clean_string($_POST['party_type_id']);
	$planning->property_type_id 	   	= functions::clean_string($_POST['property_type_id']);
	$planning->vendor_type_id 			= functions::clean_string($_POST['vendor_type_id']);
	$planning->vendor_name				= functions::clean_string($_POST['vendor_name']);
	$planning->phone				    = functions::clean_string($_POST['phone']);
	$planning->address				    = functions::clean_string($_POST['address']);
	$planning->location_id	            = functions::clean_string($_POST['location_id']);
	$planning->country_id		        = functions::clean_string($_POST['country_id']);
	$planning->postcode		            = functions::clean_string($_POST['postcode']);
	$planning->MouseLat		       		= $_POST['MouseLat'] !=""	?	functions::clean_string($_POST['MouseLat'])	:	functions::clean_string($_POST['postcode_lat']);
	$planning->MouseLng		            = $_POST['MouseLng'] !=""	?	functions::clean_string($_POST['MouseLng'])	:	functions::clean_string($_POST['postcode_lng']);
	$planning->website		            = functions::clean_string($_POST['website']);
	$planning->email		            = functions::clean_string($_POST['email']);
	$planning->budget_range		        = functions::clean_string($_POST['budget_range']);
	$planning->cost_range		        = functions::clean_string($_POST['cost_range']);
	
	$planning->price		            = ($planning->vendor_type_id== 1) ? functions::clean_string($_POST['price']): 0;
	$planning->price_type	            = ($planning->vendor_type_id== 1) ? functions::clean_string($_POST['price_type']): 0;
	$planning->hotel_fee	            = ($planning->vendor_type_id== 1) ? functions::clean_string($_POST['hotel_fee']): 'N';
	$planning->your_picks	            = ($planning->vendor_type_id== 1) ? $_POST['your_picks']: array();
	$planning->your_picks_description	= ($planning->vendor_type_id== 1) ? functions::clean_string($_POST['your_picks_description']) : '';
	$planning->amenities	            = ($planning->vendor_type_id== 1) ? $_POST['amenities'] : array();
	$planning->features	                = ($planning->vendor_type_id== 1) ? functions::clean_string($_POST['features']): '';
	$planning->location_description		= ($planning->vendor_type_id== 1) ? functions::clean_string($_POST['location_description']): '';
	$planning->guest_favourites	    	= ($planning->vendor_type_id== 1) ? functions::clean_string($_POST['guest_favourites']): '';
	
	$planning->overview					= functions::clean_string($_POST['overview']);
	$planning->whywe_like	    		= ($planning->vendor_type_id != 1) ? functions::clean_string($_POST['whywe_like']): '';
	
	$planning->yelp						= functions::clean_string($_POST['yelp']);
	$planning->overview					= functions::clean_string($_POST['overview']);
	$planning->overview					= functions::clean_string($_POST['overview']);
	
	$planning->status				    = functions::clean_string($_POST['status']);

	$validation				            = new validation();
	$validation->check_selection($planning->party_type_id, "Party type", "party_type_id");
	$validation->check_selection($planning->vendor_type_id, "Vendor type", "vendor_type_id");
	$validation->check_blank($planning->vendor_name, "Vendor name", "vendor_name");
	//$validation->check_blank($planning->phone, "Phone", "phone");
	//$validation->check_blank($planning->address, "Address", "address");
	$validation->check_selection($planning->location_id, "City/Location", "location_id");
	$validation->check_selection($planning->country_id, "Country", "country_id");
	$validation->check_blank($planning->postcode, "Postcode", "postcode");
	if($planning->email != '')
	{
		$validation->check_email($planning->email, "Email", "email");
	}
	//$validation->check_blank($planning->website, "Website", "website");
	//$validation->check_blank($planning->email, "Email", "email");
	//$validation->check_email($planning->email, "Email", "email");
	//$validation->check_selection($planning->budget_range, "Budget range", "budget_range");
	//$validation->check_selection($planning->cost_range, "Cost range", "cost_range");
	$validation->check_blank($planning->status, "Status", "status");
	$validation->check_blank($planning->overview, "Overview", "overview");
	
	$flag = 0;
	if($planning->vendor_type_id== 1)
	{
		$validation->check_selection($planning->property_type_id, "Property type", "property_type_id");
		$validation->check_blank($planning->price, "Price", "price");
		
		if($planning->price < 0 || !is_numeric($planning->price))
		{
			$flag  = 1;	
		}
	}
	else
	{
		//validations for others	
	}
	
	if (!$validation->checkErrors() && $flag == 0 )
	{
		if($planning->save())
		{
			if($planning_id == 0)
			{
				$planning->MouseLat		       = $_POST['MouseLat'] !=""	?	functions::clean_string($_POST['MouseLat'])	:	functions::clean_string($_POST['postcode_lat']);
				$planning->MouseLng		       = $_POST['MouseLng'] !=""	?	functions::clean_string($_POST['MouseLng'])	:	functions::clean_string($_POST['postcode_lng']);
				$_SESSION['MouseLat']	= $planning->MouseLat;
				$_SESSION['MouseLng']	= $planning->MouseLng;
				$_SESSION['planning_id']	= $planning->planning_id;
			}
		}

	    if(!$planning->warning)
		{
			$json_var 	= '{"title":"Success", "text":"'.$planning->message.'","type":"success","width":"100%","url":"manage_planning.php"}';
			$notify 	= new notify();
			$notify->show_message($json_var);
		}
	}
	else
	{
		$planning->error	= $validation->getallerrors();
	}
	if($planning->warning)
	{
		$json_var 	= '{"title":"Error", "text":"'.$planning->message.'","type":"error","width":"100%"}';
		$notify 	= new notify();
		$notify->show_message($json_var);
	}
}

else if (!isset($_POST["save"]))
{
	$planning	= new planning($planning_id);
	//print_r($planning->MouseLat);
	//$planning->MouseLat= ($planning->MouseLat !="" &&$planning->MouseLat !=0)	?	$planning->MouseLat	:	BING_MAP_DEFAULT_LATITUDE;
	//$planning->MouseLng= ($planning->MouseLng !="" && $planning->MouseLng !=0)	?	$planning->MouseLng	:	BING_MAP_DEFAULT_LONGITUDE;
}

?>


<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />

<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>

<script type="text/javascript" src="<?php echo URI_LIBRARY; ?>fckeditor/fckeditor.js"></script>

<script language="javascript" type="text/javascript">


window.onload = function(){
	/*var oFCKeditor			= new FCKeditor( 'further_details' );

	oFCKeditor.BasePath		= "<?php echo URI_LIBRARY.'fckeditor/'; ?>";

	oFCKeditor.Height		= "300" ;

	oFCKeditor.Width		= "710" ;

	oFCKeditor.Config['SkinPath'] = 'skins/silver/' ;

	oFCKeditor.ToolbarSet	= "Cms"; //Cms

	oFCKeditor.ReplaceTextarea() ;
	
	
	validate_mandatory();*/

}
	//editorInstance	= FCKeditorAPI.GetInstance("planning_details");
	function FCKeditor_OnComplete(editorInstance) {
		  //fckeditor_word_count(editorInstance);
		  editorInstance.Events.AttachEvent('OnSelectionChange', validate_mandatory );
		  editorInstance.Events.AttachEvent('OnBlur', validate_mandatory );
		  editorInstance.Events.AttachEvent('OnChange', validate_mandatory );
   
	}

$(document).ready(function () {

	//GetMap();	
	//validate_mandatory();
});

		



//rentsheildrow,rentmonthsrow,othersrow,show_rent_changes

function validate_form()
{
	var forms = document.register_planning;
	
	if (!check_selected(forms.party_type_id, "Party type is required!"))
	{	return false;	}
	
	if (!check_selected(forms.vendor_type_id, "Vendor type is required!"))
	{	return false;	}
	
	if(forms.vendor_type_id.value== 1)
	{
		if (!check_selected(forms.property_type_id, "Property type is required!")){	return false;	}
	}
	
	if (!check_blank(forms.vendor_name, "Vendor name is required!")){	return false; }
	//if (!check_blank(forms.phone, "Phone is required!"))	{ return false;	}
	if (!check_selected(forms.location_id, "City/Location is required!")) {	return false;	}
	if (!check_selected(forms.country_id, "Country is required!"))	{ return false;	}
	if (!check_blank(forms.postcode, "Postcode is required!"))	{ return false;	}
	else
	{
		var post_error = 0;
		 $.ajax(
		 {	
				type: "POST",
				cache: false,
				async: false,
				url: "ajax_get_position.php?postcode="+forms.postcode.value,
				success: function (data)
				{
					var row = data.split('<>');
					if(row[0] == 0)
					{				
						if($('#postcode_current').val() != forms.postcode.value || $('#postcode_current').val() =="")
						{
							$('#postcode_lat').val(row[1]);
							$('#postcode_lng').val(row[2]);
							$('#MouseLat').val(row[1]);
							$('#MouseLng').val(row[2]);	
						}
					}
					else
					{
						post_error = 1;
						alert(row[1]);	
						$('#postcode_lat').val('');
						$('#postcode_lng').val('');
						$('#MouseLat').val('');
						$('#MouseLng').val('');	
					}
				}
		  });
		  
		 // return false;
	}
	
	if(post_error) {
		return false;
	}
	
	if(forms.website.value != '')
	{
		if (!check_blank(forms.website, "Website url is required!"))	{ return false;	}
		if (!isValidUrl(forms.website, "Website url is invalid!")){	return false;	}
	}
	
	if(forms.email.value != '')
	{
		if (!check_blank(forms.email, "Email is required!"))	{ return false;	}
		if (!check_email(forms.email, "Email is invalid!")){ return false; }
	}
	
	//if (!check_selected(forms.budget_range, "Budget range is required!"))	{ return false;	}
	//if (!check_selected(forms.cost_range, "Cost range is required!")) { return false;	}
	
	if(forms.vendor_type_id.value== 1)
	{
		if (!check_blank(forms.price, "Price is required!")) {	return false;	}
		else {
			if(forms.price.value==0)
			{
			  alert("Price cannot be zero");
			  forms.price.focus();
			  return false;
			}

			if(forms.price.value<0)
			{
			  alert("Price should be greater than zero");
			  forms.price.focus();
			  return false;
			}
	
			if(!check_numeric(forms.price,"Price accept only numbers"))	{ return false;}
		}
		
		if (!check_blank(forms.overview, "Overview is required!"))	{ return false;	}
	}
	else
	{
		if (!check_blank(forms.overview, "Overview is required!"))	{ return false;	}
	}

	return true;
}


function ajax_check_postcode(postcode)
{
	$.ajax(
	 {	
			type: "POST",
			cache: false,
			async: false,
			url: "ajax_get_position.php?postcode="+postcode,
			success: function (data)
			{
				var row = data.split('<>');
				if(row[0] == 0)
				{
					if($('#postcode_current').val() != postcode || $('#postcode_current').val() =="")
					{
						$('#postcode_lat').val(row[1]);
						$('#postcode_lng').val(row[2]);
						$('#MouseLat').val('');
						$('#MouseLng').val('');	
						$('#postcode_current').val(postcode);
					}
				}
				else
				{					
					$('#postcode_lat').val('');
					$('#postcode_lng').val('');
					$('#MouseLat').val('');
					$('#MouseLng').val('');	
				}
			}
	  });	
}
</script>



<script type="text/javascript" src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>

<script type="text/javascript">

      var map = null;

      function GetMap(lat, lng)
      {	
        map = new Microsoft.Maps.Map(document.getElementById('myMap'), {credentials: '<?php echo BING_MAP_API_KEY;?>'

		,mapTypeId: Microsoft.Maps.MapTypeId.road,

		center: new Microsoft.Maps.Location(lat,lng),

							zoom: 10});

		

		//var pushpinOptions = new Microsoft.Maps.Pushpin(center, {icon: 'BluePushpin.png', width: 50, height: 50, draggable: true}); 

		//var pushpinOptions = new Microsoft.Maps.Pushpin(center, { text: '1', draggable: true });

		var pushpinOptions = {draggable:true}; 

		var pushpin= new Microsoft.Maps.Pushpin(map.getCenter(), pushpinOptions); 

		Microsoft.Maps.Events.addHandler(pushpin, 'dragstart', StartDragHandler);

		var pushpindrag= Microsoft.Maps.Events.addHandler(pushpin, 'drag', onDragDetails); 

		Microsoft.Maps.Events.addHandler(pushpin, 'dragend', EndDragHandler); 

		map.entities.push(pushpin); 
  }


  /*
function GetMap()

      {	

        map = new Microsoft.Maps.Map(document.getElementById('myMap'), {credentials: '<?php echo BING_MAP_API_KEY;?>'

		,mapTypeId: Microsoft.Maps.MapTypeId.road,

		center: new Microsoft.Maps.Location('<?php echo $planning->MouseLat;?>', '<?php echo $planning->MouseLng;?>'),

							zoom: 7});

		

		//var pushpinOptions = new Microsoft.Maps.Pushpin(center, {icon: 'BluePushpin.png', width: 50, height: 50, draggable: true}); 

		//var pushpinOptions = new Microsoft.Maps.Pushpin(center, { text: '1', draggable: true });

		var pushpinOptions = {draggable:true}; 

		var pushpin= new Microsoft.Maps.Pushpin(map.getCenter(), pushpinOptions); 

		Microsoft.Maps.Events.addHandler(pushpin, 'dragstart', StartDragHandler);

		var pushpindrag= Microsoft.Maps.Events.addHandler(pushpin, 'drag', onDragDetails); 

		Microsoft.Maps.Events.addHandler(pushpin, 'dragend', EndDragHandler); 

		map.entities.push(pushpin); 

  }  
*/  

	   function StartDragHandler(e) {

			//document.getElementById("mode").innerHTML = "Dragging started (dragstart event)."

		}

	  function EndDragHandler(e) {

			//document.getElementById("mode").innerHTML = "Dragging stopped (dragend event)."

		}

      function attachPushpinDragEvent()

      {

        

        alert('drag newly added pushpin to raise event');

      }

      

      onDragDetails = function (e) 

      {
       // alert("Event Info - start drag \n" + "Start Latitude/Longitude: " + e.entity.getLocation() ); 
	   var loc = e.entity.getLocation();

	    document.getElementById("MouseLat").value = loc.latitude.toFixed(4);
		document.getElementById("MouseLng").value = loc.longitude.toFixed(4);
      }


function change_fields(vendor_type)
{
	$('.hideme').hide();
	if(vendor_type== 1)
	{
		$('.hide_hotel').show();
		$('.hide_others').hide();	
	}
	else
	{
		$('.hide_others').show();
		$('.hide_hotel').hide();
	}
}
 
$(document).ready(function() {
	var plan_id = '<?php echo $planning_id ?>';
	var vendor_id = '<?php echo $planning->vendor_type_id ?>';
	if(plan_id > 0 && vendor_id > 0)
	{
		change_fields(vendor_id);	
	}
});

</script>


<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">

	<tr>

		<td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>

		<td class="topRepeat">&nbsp;</td>

		<td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>

	</tr>

	<tr>

		<td rowspan="2" class="leftRepeat">&nbsp;</td>

		<td bgcolor="#FFFFFF"><div class="contentHeader">

				<div class="pageTitle">

					<?php



					echo functions::deformat_string($page_title);



				?>

				</div>

				<div class="contentSublinks txtBold"> <img src="images/manage-property.png" alt="<?php echo functions::deformat_string($default_page_title); ?>" title="<?php echo functions::deformat_string($default_page_title); ?>" width="24" height="24" class="imgBlock" /> <a href="<?php echo functions::deformat_string($default_page_uri); ?>"><?php echo functions::deformat_string($default_page_title); ?></a> </div>

			</div>

			<?php if(!empty($planning->message)) { ?>

			

			<!--<span class="<?php echo $planning->warning ? 'warningMesg' : 'infoMesg'; ?>  formPageWidth"> <?php echo $planning->message; ?> </span>-->

			

			<?php } ?>

			<div class="spacer"></div></td>

		<td rowspan="2" class="rightRepeat">&nbsp;</td>

	</tr>
	
	<tr>

		<td bgcolor="#FFFFFF"><form name="register_planning" id="register_planning" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>"  enctype="multipart/form-data">

				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="form">

					
                    <tr>

                    <td width="16%">Party Type<span class="txtRed">*</span></td>

                    <td><select  id="party_type_id" name="party_type_id" tabindex="1" size="1" class="dropdown">
                        <option value="0" >-- Select Party Type --</option>

                        <?php

                        $vendor_type_array = party_type::get_party_type_options();

                        for($i = 0; $i < count($vendor_type_array); $i++)
                        {
                            $select = ' ';

                            if($vendor_type_array[$i]->party_type_id == $planning->party_type_id)
                            {
                                $select = ' selected ';
                            }                         

                            echo '<option  value="' . $vendor_type_array[$i]->party_type_id  . '" ' . $select . '>' . functions::deformat_string($vendor_type_array[$i]->name ) . '</option>';

                        }

                        ?>

                      </select>

                      <?php if(!empty($planning->error["party_type_id"])) { ?> <span id="errmesg" class="error"> <?php echo $planning->error["party_type_id"]; ?></span>

                      <?php } ?>

                      <div class="spacer"></div></td>

                  </tr>
                  
                  
                	<tr>

                    <td>Vendor Type<span class="txtRed">*</span></td>

                    <td><select  id="vendor_type_id" name="vendor_type_id" tabindex="2" size="1" class="dropdown" onchange="change_fields(this.value)">
                        <option value="0" >-- Select Vendor Type --</option>

                        <?php

                        $vendor_type_array = vendor_type::get_vendor_type_options();

                        for($i = 0; $i < count($vendor_type_array); $i++)
                        {
                            $select = ' ';

                            if($vendor_type_array[$i]->vendor_type_id == $planning->vendor_type_id)
                            {
                                $select = ' selected ';
                            }                         

                            echo '<option  value="' . $vendor_type_array[$i]->vendor_type_id  . '" ' . $select . '>' . functions::deformat_string($vendor_type_array[$i]->name ) . '</option>';

                        }

                        ?>

                      </select>

                      <?php if(!empty($planning->error["vendor_type_id"])) { ?> <span id="errmesg" class="error"> <?php echo $planning->error["vendor_type_id"]; ?></span>

                      <?php } ?>

                      <div class="spacer"></div></td>

                  </tr>
                  

                	<tr class="hideme hide_hotel">

                    <td>Property Type<span class="txtRed">*</span></td>

                    <td><select  id="property_type_id" name="property_type_id" tabindex="3" size="1" class="dropdown">
                        <option value="0" >-- Select Property Type --</option>

                        <?php

                        $property_type_array = property_type::get_property_type_options();

                        for($i = 0; $i < count($property_type_array); $i++)
                        {
                            $select = ' ';

                            if($property_type_array[$i]->property_type_id == $planning->property_type_id)
                            {
                                $select = ' selected ';
                            }                         

                            echo '<option  value="' . $property_type_array[$i]->property_type_id  . '" ' . $select . '>' . functions::deformat_string($property_type_array[$i]->name ) . '</option>';

                        }

                        ?>

                      </select>

                      <?php if(!empty($planning->error["property_type_id"])) { ?> <span id="errmesg" class="error"> <?php echo $planning->error["property_type_id"]; ?></span>

                      <?php } ?>

                      <div class="spacer"></div></td>

                  </tr>

                  
					<tr>

						<td width="22%">Vendor Name<span class="txtRed">*</span></td>

						<td width="88%"><input type="text" id="vendor_name" name="vendor_name" value="<?php echo utf8_encode(functions::format_text_field($planning->vendor_name)); ?>" class="textbox" tabindex="4" maxlength="100" />

							<div class="txtTheme noLineHeight note"><span class="txtRed">*Note: </span>Maximum 100 characters allowed.</div>

							<?php if(!empty($planning->error["vendor_name"])) { ?>

							<span id="errmesg" class="error"> <?php echo $planning->error["vendor_name"]; ?></span>

							<?php } ?>

							<div class="spacer"></div></td>

					</tr>
                    
                    
                    <tr>

						<td width="22%">Phone</td>

						<td width="88%"><input type="text" id="phone" name="phone" value="<?php echo functions::format_text_field($planning->phone); ?>" class="textbox" tabindex="5" maxlength="20" />
							<?php if(!empty($planning->error["phone"])) { ?>

							<span id="errmesg" class="error"> <?php echo $planning->error["phone"]; ?></span>

							<?php } ?>

							<div class="spacer"></div></td>

					</tr>
                    		
                    
                    <tr > 

						<td>Address</td>
						<td><textarea name="address" id="address" class="textarea" tabindex="6" onKeyDown="limitText(this.form.address,this.form.countdown10,<?php echo $address_length; ?>);"  onkeyup="limitText(this.form.address,this.form.countdown10,<?php echo $address_length; ?>);" ><?php echo htmlentities(functions::format_text_field($planning->address)); ?></textarea>

							<?php



						if(!empty($planning->error['address'])) { ?>

							<span id="errmesg" class="error"><?php echo $planning->error['address']; ?></span>

							<?php } ?>

							<br>

							Maximum characters: <?php echo $address_length; ?> You have

							<input name="countdown10" id="countdown10" type="text" class="admincontent" <?php if($planning->address!=""){?>value="<?php echo  $address_length - strlen($planning->address);?>"<?php }else{?> value="<?php echo $address_length; ?>"<?php }?> size="5" readonly>

							characters left.<br />

							<div class="spacer"></div>
                            </td>

					</tr>
                    
                    <tr>

                    <td>City/Location<span class="txtRed">*</span></td>

                    <td><select  id="location_id" name="location_id" tabindex="7" size="1" class="dropdown">
                        <option value="0" >--Select City/Location--</option>

                        <?php

                        $location_array = location::get_location_options();

                        for($i = 0; $i < count($location_array); $i++)
                        {
                            $select = ' ';

                            if($location_array[$i]->location_id == $planning->location_id)
                            {
                                $select = ' selected ';
                            }                         

                            echo '<option  value="' . $location_array[$i]->location_id  . '" ' . $select . '>' . functions::deformat_string($location_array[$i]->name ) . '</option>';
                        }

                        ?>

                      </select>

                      <?php if(!empty($planning->error["location_id"])) { ?> <span id="errmesg" class="error"> <?php echo $planning->error["location_id"]; ?></span>

                      <?php } ?>

                      <div class="spacer"></div></td>

                  </tr>
                    
                    
                    <tr>

                    <td>Country<span class="txtRed">*</span></td>

                    <td><select  id="country_id" name="country_id" tabindex="8" size="1" class="dropdown" >
                        <option value="0" >--Select Country--</option>

                        <?php

                        $country_array = country::get_country_options();

                        for($i = 0; $i < count($country_array); $i++)
                        {
                            $select = ' ';

                            if($country_array[$i]->country_id == $planning->country_id)
                            {
                                $select = ' selected ';
                            }                         

                            echo '<option  value="' . $country_array[$i]->country_id  . '" ' . $select . '>' . functions::deformat_string($country_array[$i]->country_name ) . '</option>';
                        }

                        ?>

                      </select>

                      <?php if(!empty($planning->error["country_id"])) { ?> <span id="errmesg" class="error"> <?php echo $planning->error["country_id"]; ?></span>

                      <?php } ?>

                      <div class="spacer"></div></td>

                  </tr>
                    
                    

					<tr>

						<td >Postcode<span class="txtRed">*</span></td>

						<td><label>

								<input type="text" name="postcode" id="postcode" tabindex="9" class="textbox" maxlength="30" value="<?php echo functions::format_text_field($planning->postcode); ?>" autocomplete="off" onblur="ajax_check_postcode(this.value)"/>

							</label>

							<?php if(!empty($planning->error["postcode"])) { ?>

							<span id="errmesg" class="error"> <?php echo $planning->error["postcode"]; ?> </span>

							<?php } ?>

							<div class="spacer"></div>
							<input type="hidden" name="postcode_lat" id="postcode_lat" value="<?php  echo functions::format_text_field($planning->MouseLat);?>" />

							<input type="hidden" name="postcode_lng" id="postcode_lng" value="<?php  echo functions::format_text_field($planning->MouseLng);?>" />
                            
                            <input type="hidden" name="postcode_current" id="postcode_current" value="<?php  echo functions::format_text_field($planning->postcode);?>" />
							</td>

					</tr>

                    

                    <tr>

                    <td>Map Location</td>

                    <td>

                    <label>

                    <input type="button" name="" id="btn_map" value="Check the location of your planning" onclick="get_map();" />

                    </label>

                    <div id="mode"></div> 

                    <input type="hidden" name="MouseLat" id="MouseLat" value="<?php  echo functions::format_text_field($planning->MouseLat);?>" />

      				<input type="hidden" name="MouseLng" id="MouseLng" value="<?php  echo functions::format_text_field($planning->MouseLng);?>" />

                    <?php if(!empty($planning->error["MouseLat"]) || !empty($planning->error["MouseLng"])) { ?>

                    <span id="errmesg" class="error"> <?php echo $planning->error["MouseLat"]; ?> </span>

                    <span id="errmesg" class="error"> <?php echo $planning->error["MouseLng"]; ?> </span>

                    <?php } ?>

                    <div class="spacer"></div>

                    </td>

                    </tr>
                    
                     
                    
                    <tr>

						<td >Website URL</td>

						<td><label>

								<input type="text" name="website" id="website" tabindex="10" class="textbox" maxlength="30" value="<?php echo functions::format_text_field($planning->website); ?>" />

							</label>

							<?php if(!empty($planning->error["website"])) { ?>

							<span id="errmesg" class="error"> <?php echo $planning->error["website"]; ?> </span>

							<?php } ?>

							<div class="spacer"></div></td>

					</tr>
                    
                    
                    <tr>

						<td >Email</td>

						<td><label>

								<input type="text" name="email" id="email" tabindex="11" class="textbox" maxlength="30" value="<?php echo functions::format_text_field($planning->email); ?>" />

							</label>

							<?php if(!empty($planning->error["email"])) { ?>

							<span id="errmesg" class="error"> <?php echo $planning->error["email"]; ?> </span>

							<?php } ?>

							<div class="spacer"></div></td>

					</tr>
                    
                  
                   <tr>

                    <td>Budget Range</td>

                    <td><select  id="budget_range" name="budget_range" tabindex="12" size="1" class="dropdown" >
                        <option value="0" >--Select Budget Range--</option>

                        <?php

                        for($i = 1; $i <= count($planning->budget_range_array); $i++)
                        {
                            $select = ' ';

                            if($i == $planning->budget_range)
                            {
                                $select = ' selected ';
                            }                         

                            echo '<option  value="' . $i  . '" ' . $select . '>' . functions::deformat_string($planning->budget_range_array[$i]) . '</option>';
                        }

                        ?>

                      </select>

                      <?php if(!empty($planning->error["budget_range"])) { ?> <span id="errmesg" class="error"> <?php echo $planning->error["budget_range"]; ?></span>

                      <?php } ?>

                      <div class="spacer"></div></td>

                  </tr>
                  
                  <tr>

                    <td>Cost Range</td>

                    <td><select  id="cost_range" name="cost_range" tabindex="13" size="1" class="dropdown" >
                        <option value="0" >--Select Cost Range--</option>

                        <?php

                        for($i = 1; $i <= count($planning->cost_range_array); $i++)
                        {
                            $select = ' ';

                            if($i == $planning->cost_range)
                            {
                                $select = ' selected ';
                            }                         

                            echo '<option  value="' . $i  . '" ' . $select . '>' . functions::deformat_string($planning->cost_range_array[$i]) . '</option>';
                        }

                        ?>

                      </select>

                      <?php if(!empty($planning->error["cost_range"])) { ?> <span id="errmesg" class="error"> <?php echo $planning->error["cost_range"]; ?></span>

                      <?php } ?>

                      <div class="spacer"></div></td>

                  </tr>
                    
                   
                    
                    <tr class="hideme hide_hotel">
						<td >Price<span class="txtRed">*</span></td>
						<td><label>
								<input type="text" name="price" id="price" tabindex="14" class="textbox" maxlength="30" value="<?php echo functions::format_text_field($planning->price); ?>" /></label>
                        / <select  id="price_type" name="price_type" tabindex="15" size="1" class="dropdown" style="width:100px;">
                       

                        <?php
                        for($i = 1; $i <= count($planning->price_type_array); $i++)
                        {
                            $select = ' ';

                            if($planning->price_type_array[$i]== $planning->price_type || $i == 1)
                            {
                                $select = ' selected ';
                            }                         

                            echo '<option  value="' . $i  . '" ' . $select . '>' . functions::deformat_string($planning->price_type_array[$i]) . '</option>';
                        }

                        ?>

                      </select>       
                                
							<?php if(!empty($planning->error["price"])) { ?>
							<span id="errmesg" class="error"> <?php echo $planning->error["price"]; ?> </span>
							<?php } ?>
							<div class="spacer"></div></td>
					</tr>
                    
                    <tr class="hideme hide_hotel">

						<td>Hotel Fee Included<span class="txtRed">*</span></td>

						<td><input type="radio" id="hotel_fee1" name="hotel_fee" value="Y" <?php echo functions::format_text_field($planning->hotel_fee) == 'Y'  ? ' checked="checked" ' : ''; ?>  class="checkbox" tabindex="16" />

							Yes&nbsp;&nbsp;

							<input type="radio" id="hotel_fee2" name="hotel_fee" value="N" <?php echo functions::format_text_field($planning->hotel_fee) == 'N' ||  functions::format_text_field($planning->hotel_fee) == '' ? ' checked="checked" ' : ''; ?>  class="checkbox" tabindex="17"  />

							No

							<?php if(!empty($planning->error["hotel_fee"])) { ?>

							<span id="errmesg" class="error"> <?php echo $planning->error["hotel_fee"]; ?></span>

							<?php } ?>

							<div class="spacer"></div></td>

					</tr>
                    
                    
                                        <tr > <!--class="hideme hide_others"-->

						<td>Overview/Write-Up<span class="txtRed">*</span></td>
						<td><textarea name="overview" id="overview" class="textarea" tabindex="18" onKeyDown="limitText(this.form.overview,this.form.countdown5,<?php echo $overview_length; ?>);"  onkeyup="limitText(this.form.overview,this.form.countdown5,<?php echo $overview_length; ?>);" ><?php echo htmlentities(functions::format_text_field($planning->overview)); ?></textarea>

							<?php



						if(!empty($planning->error['overview'])) { ?>

							<span id="errmesg" class="error"><?php echo $planning->error['overview']; ?></span>

							<?php } ?>

							<br>

							Maximum characters: <?php echo $overview_length; ?> You have

							<input name="countdown5" id="countdown5" type="text" class="admincontent" <?php if($planning->overview!=""){?>value="<?php echo  $overview_length - strlen($planning->overview);?>"<?php }else{?> value="<?php echo $overview_length; ?>"<?php }?> size="5" readonly>

							characters left.<br />

							<div class="spacer"></div>
                            </td>

					</tr>
                    
                    <tr class="hideme hide_others">

						<td>Why We Like It</td>
						<td><textarea name="whywe_like" id="whywe_like" class="textarea" tabindex="19" onKeyDown="limitText(this.form.whywe_like,this.form.countdown6,<?php echo $whywe_like_length; ?>);"  onkeyup="limitText(this.form.whywe_like,this.form.countdown6,<?php echo $whywe_like_length; ?>);" ><?php echo htmlentities(functions::format_text_field($planning->whywe_like)); ?></textarea>

							<?php



						if(!empty($planning->error['whywe_like'])) { ?>

							<span id="errmesg" class="error"><?php echo $planning->error['whywe_like']; ?></span>

							<?php } ?>

							<br>

							Maximum characters: <?php echo $whywe_like_length; ?> You have

							<input name="countdown6" id="countdown6" type="text" class="admincontent" <?php if($planning->whywe_like!=""){?>value="<?php echo  $whywe_like_length - strlen($planning->whywe_like);?>"<?php }else{?> value="<?php echo $whywe_like_length; ?>"<?php }?> size="5" readonly>

							characters left.<br />

							<div class="spacer"></div>
                            </td>

					</tr>
                    
                    
                    
                    <tr class="hideme hide_hotel">

                    <td>What you will love</td>

                    <td><select  id="your_picks" name="your_picks[]" tabindex="20" multiple="multiple" size="6" class="dropdown">
                        

                        <?php

                        $facility_array = facility::get_facility_options();
						
						$your_picks 	= explode(',', $planning->your_picks);
						

                        for($i = 0; $i < count($facility_array); $i++)
                        {
                            $select = ' ';
							
							for($j =0; $j< count($your_picks); $j++)
							{
                            	if($facility_array[$i]->facility_id == $your_picks[$j])
                            	{
                                	$select = ' selected ';
									break;
                            	}
							}

                            echo '<option  value="' . $facility_array[$i]->facility_id  . '" ' . $select . '>' . functions::deformat_string($facility_array[$i]->name ) . '</option>';
                        }

                        ?>

                      </select>

                      <?php if(!empty($planning->error["your_picks"])) { ?> <span id="errmesg" class="error"> <?php echo $planning->error["your_picks"]; ?></span>

                      <?php } ?>

                      <div class="spacer"></div></td>

                  </tr>
                    
                  
                   <tr class="hideme hide_hotel">

						<td>What you will love - Description</td>
						<td><textarea name="your_picks_description" id="your_picks_description" class="textarea" tabindex="21" onKeyDown="limitText(this.form.your_picks_description,this.form.countdown1,<?php echo $your_picks_description_length; ?>);"  onkeyup="limitText(this.form.your_picks_description,this.form.countdown1,<?php echo $your_picks_description_length; ?>);" ><?php echo functions::format_text_field($planning->your_picks_description); ?></textarea>

							<?php



						if(!empty($planning->error['your_picks_description'])) { ?>

							<span id="errmesg" class="error"><?php echo $planning->error['your_picks_description']; ?></span>

							<?php } ?>

							<br>

							Maximum characters: <?php echo $your_picks_description_length; ?> You have

							<input name="countdown1" id="countdown1" type="text" class="admincontent" <?php if($planning->your_picks_description!=""){?>value="<?php echo  $your_picks_description_length - strlen($planning->your_picks_description);?>"<?php }else{?> value="<?php echo $your_picks_description_length; ?>"<?php }?> size="5" readonly>

							characters left.<br />

							<div class="spacer"></div>
                            </td>

					</tr>
                    
                    
                     <tr class="hideme hide_hotel">

                    <td>Amenities</td>

                    <td><select  id="amenities" name="amenities[]" tabindex="22" multiple="multiple" size="6" class="dropdown">
                        

                        <?php

                        $amenities_array = amenities::get_amenities_options();
						
						$amenities_ids		= explode(',', $planning->amenities);
						

                        for($i = 0; $i < count($amenities_array); $i++)
                        {
                            $select = ' ';
							
							for($j =0; $j< count($amenities_ids); $j++)
							{
                            	if($amenities_array[$i]->amenities_id == $amenities_ids[$j])
                            	{
                                	$select = ' selected ';
									break;
                            	}
							}

                            echo '<option  value="' . $amenities_array[$i]->amenities_id  . '" ' . $select . '>' . functions::deformat_string($amenities_array[$i]->name ) . '</option>';
                        }

                        ?>

                      </select>

                      <?php if(!empty($planning->error["amenities"])) { ?> <span id="errmesg" class="error"> <?php echo $planning->error["amenities"]; ?></span>

                      <?php } ?>

                      <div class="spacer"></div></td>

                  </tr>
                  
                  
                  <tr class="hideme hide_hotel">

						<td>Hotel Features</td>
						<td><textarea name="features" id="features" class="textarea" tabindex="23" onKeyDown="limitText(this.form.features,this.form.countdown2,<?php echo $features_length; ?>);"  onkeyup="limitText(this.form.features,this.form.countdown2,<?php echo $features_length; ?>);" ><?php echo functions::format_text_field($planning->features); ?></textarea>

							<?php



						if(!empty($planning->error['features'])) { ?>

							<span id="errmesg" class="error"><?php echo $planning->error['features']; ?></span>

							<?php } ?>

							<br>

							Maximum characters: <?php echo $features_length; ?> You have

							<input name="countdown2" id="countdown2" type="text" class="admincontent" <?php if($planning->features!=""){?>value="<?php echo  $features_length - strlen($planning->features);?>"<?php }else{?> value="<?php echo $features_length; ?>"<?php }?> size="5" readonly>

							characters left.<br />

							<div class="spacer"></div>
                            </td>

					</tr>
                    
                    
                    
                    
                    <tr class="hideme hide_hotel">

						<td>Hotel Location</td>
						<td><textarea name="location_description" id="location_description" class="textarea" tabindex="24" onKeyDown="limitText(this.form.location_description,this.form.countdown3,<?php echo $location_description_length; ?>);"  onkeyup="limitText(this.form.location_description,this.form.countdown3,<?php echo $location_description_length; ?>);" ><?php echo functions::format_text_field($planning->location_description); ?></textarea>

							<?php



						if(!empty($planning->error['location_description'])) { ?>

							<span id="errmesg" class="error"><?php echo $planning->error['location_description']; ?></span>

							<?php } ?>

							<br>

							Maximum characters: <?php echo $location_description_length; ?> You have

							<input name="countdown3" id="countdown3" type="text" class="admincontent" <?php if($planning->location_description!=""){?>value="<?php echo  $location_description_length - strlen($planning->location_description);?>"<?php }else{?> value="<?php echo $location_description_length; ?>"<?php }?> size="5" readonly>

							characters left.<br />

							<div class="spacer"></div>
                            </td>

					</tr>
                    
                    
                    
                    <tr class="hideme hide_hotel">

						<td>Guest Favourites</td>
						<td><textarea name="guest_favourites" id="guest_favourites" class="textarea" tabindex="25" onKeyDown="limitText(this.form.guest_favourites,this.form.countdown4,<?php echo $guest_favourites_length; ?>);"  onkeyup="limitText(this.form.guest_favourites,this.form.countdown4,<?php echo $guest_favourites_length; ?>);" ><?php echo functions::format_text_field($planning->guest_favourites); ?></textarea>

							<?php



						if(!empty($planning->error['guest_favourites'])) { ?>

							<span id="errmesg" class="error"><?php echo $planning->error['guest_favourites']; ?></span>

							<?php } ?>

							<br>

							Maximum characters: <?php echo $guest_favourites_length; ?> You have

							<input name="countdown4" id="countdown4" type="text" class="admincontent" <?php if($planning->guest_favourites!=""){?>value="<?php echo  $guest_favourites_length - strlen($planning->guest_favourites);?>"<?php }else{?> value="<?php echo $guest_favourites_length; ?>"<?php }?> size="5" readonly>

							characters left.<br />

							<div class="spacer"></div>
                            </td>

					</tr>
                    
                    <tr>
						<td>Yelp</td>
						<td><textarea name="yelp" id="yelp" class="textarea" tabindex="26" onKeyDown="limitText(this.form.yelp,this.form.countdown7,<?php echo $yelp_length; ?>);"  onkeyup="limitText(this.form.yelp,this.form.countdown7,<?php echo $yelp_length; ?>);" ><?php echo functions::format_text_field($planning->yelp); ?></textarea>

							<?php
							if(!empty($planning->error['yelp'])) { ?>
								<span id="errmesg" class="error"><?php echo $planning->error['yelp']; ?></span>
							<?php } ?>
							<br>
							Maximum characters: <?php echo $yelp_length; ?> You have

							<input name="countdown7" id="countdown7" type="text" class="admincontent" <?php if($planning->yelp!=""){?>value="<?php echo  $yelp_length - strlen($planning->yelp);?>"<?php }else{?> value="<?php echo $yelp_length; ?>"<?php }?> size="5" readonly>
							characters left.<br />
							<div class="spacer"></div>
                            </td>
					</tr>
                    
                    <tr>
						<td>Other Resources</td>
						<td><textarea name="other_resources" id="other_resources" class="textarea" tabindex="27" onKeyDown="limitText(this.form.other_resources,this.form.countdown8,<?php echo $other_resources_length; ?>);"  onkeyup="limitText(this.form.other_resources,this.form.countdown8,<?php echo $other_resources_length; ?>);" ><?php echo functions::format_text_field($planning->other_resources); ?></textarea>

							<?php
							if(!empty($planning->error['other_resources'])) { ?>
								<span id="errmesg" class="error"><?php echo $planning->error['other_resources']; ?></span>
							<?php } ?>
							<br>
							Maximum characters: <?php echo $other_resources_length; ?> You have

							<input name="countdown8" id="countdown8" type="text" class="admincontent" <?php if($planning->other_resources!=""){?>value="<?php echo  $other_resources_length - strlen($planning->other_resources);?>"<?php }else{?> value="<?php echo $other_resources_length; ?>"<?php }?> size="5" readonly>
							characters left.<br />
							<div class="spacer"></div>
                            </td>
					</tr>
                    
                    <tr>
						<td>Comments</td>
						<td><textarea name="comments" id="comments" class="textarea" tabindex="28" onKeyDown="limitText(this.form.comments,this.form.countdown9,<?php echo $comments_length; ?>);"  onkeyup="limitText(this.form.comments,this.form.countdown9,<?php echo $comments_length; ?>);" ><?php echo functions::format_text_field($planning->comments); ?></textarea>

							<?php
							if(!empty($planning->error['comments'])) { ?>
								<span id="errmesg" class="error"><?php echo $planning->error['comments']; ?></span>
							<?php } ?>
							<br>
							Maximum characters: <?php echo $comments_length; ?> You have

							<input name="countdown9" id="countdown9" type="text" class="admincontent" <?php if($planning->comments!=""){?>value="<?php echo  $comments_length - strlen($planning->comments);?>"<?php }else{?> value="<?php echo $comments_length; ?>"<?php }?> size="5" readonly>
							characters left.<br />
							<div class="spacer"></div>
                            </td>
					</tr>                   

					<tr >

						<td>Status <span class="txtRed">*</span></td>

						<td><input type="radio" id="status1" name="status" value="Y" <?php echo functions::format_text_field($planning->status) == 'Y' ||  functions::format_text_field($planning->status) == '' ? ' checked="checked" ' : ''; ?>  class="checkbox" tabindex="29"  />

							Active&nbsp;&nbsp;

							<input type="radio" id="status2" name="status" value="N" <?php echo functions::format_text_field($planning->status) == 'N' ? ' checked="checked" ' : ''; ?>  class="checkbox" tabindex="30"  />

							Inactive

							<?php if(!empty($planning->error["status"])) { ?>

							<span id="errmesg" class="error"> <?php echo $planning->error["status"]; ?></span>

							<?php } ?>

							<div class="spacer"></div></td>

					</tr>

					<tr>

						<td>&nbsp;</td>

						<td ><input type="submit" id="save" name="save" value="Save" class="submit" title="Save" tabindex="31" onclick="javascript:return validate_form();" />

							<input type="submit" id="cancel" name="cancel" value="Cancel" class="submit" title="Cancel" tabindex="32" />

							<div class="spacer"></div></td>

					</tr>

					<tr>

						<td colspan="2" class="txtTheme required"><span class="txtRed">*</span> Required fields</td>

					</tr>

				</table>

             
				<input type="hidden" id="planning_id" name="planning_id" value="<?php echo $planning->planning_id; ?>" />

			</form></td>

	</tr>

	<tr>

		<td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>

		<td class="bottomRepeat">&nbsp;</td>

		<td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>

	</tr>

</table>

<link rel="stylesheet" href="<?php echo URI_LIBRARY; ?>colorbox/colorbox.css" />

<script src="<?php echo URI_LIBRARY; ?>colorbox/jquery.colorbox.js"></script>



<div style="display:none" >

   <div id='inline_content' style="background:#fff;  padding:-10px; position:relative; width:715px; !importent height:550px; overflow:auto; ">

    <div id='myMap' style="position:relative; width:710px; height:500px;border:1px solid #999999;"></div>
You can pick up the pin and move it to the exact location of your planning. When you are happy with the location simply click the close button in the bottom right of this box. 
   </div>
	
  </div>





<script language="javascript" type="text/javascript">

function get_map(){

	
		var lat = '';
		var lng	= '';
		if($('#MouseLat').val() != '' && $('#MouseLng').val() != '')
		{
			lat = $('#MouseLat').val() ;
			lng = $('#MouseLng').val();
	}
	else if($('#postcode_lat').val() != '' && $('#postcode_lng').val() != '')
	{
		lat = $('#postcode_lat').val() ;
		lng = $('#postcode_lng').val();
	}
	
	if(lat != '' && lng != '')
	{
		GetMap(lat, lng);

		$.colorbox({href:'#inline_content', inline:true});
	}
	else
	{
		alert("Please select postcode");
	}

}

//limitText(document.forms['register_planning'].location_description,document.forms['register_planning'].countdown3, '<?php echo $location_description_length; ?>');


function limitText(limitField, limitCount, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		limitCount.value = limitNum - limitField.value.length;
	}
}


</script> 



<?php 

	$template->footer();

?>