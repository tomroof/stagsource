<?php
/*********************************************************************************************
Date	: 14-April-2011
Purpose	: Manage video
*********************************************************************************************/
ob_start();
session_start();
include_once("../includes/config.php");

// Check the admin user is loged in or not
if (!isset($_SESSION[ADMIN_ID]) && !isset($_SESSION[AGENT_ID]))
{
	functions::redirect("login.php");
	exit;
}

$trip_id		= (isset($_REQUEST['trip_id']) &&  $_REQUEST['trip_id']) > 0 ? $_REQUEST['trip_id'] : 0;
 
 $trip 		=  new trip($trip_id);
 if($trip->trip_id == 0)
 {
	functions::redirect("manage_trip.php");
	exit; 
 }




$page_title				= 'Manage Trip Poll';	
$template 				= new template();
$template->type			= 'ADMIN';
$template->left_menu	= true;
$template->admin_id		= $_SESSION[ADMIN_ID];
$template->js			= '<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>
<script type="text/javascript" language="javascript" src="' . URI_LIBRARY . 'jquery/jquery.tablednd.js"></script>

<script type="text/javascript" src="' . URI_LIBRARY . 'fancybox/lib/jquery.mousewheel-3.0.6.pack.js"></script> 
<script type="text/javascript" src="' . URI_LIBRARY . 'fancybox/source/jquery.fancybox.js?v=2.1.3"></script>
<link rel="stylesheet" type="text/css" href="' . URI_LIBRARY . 'fancybox/source/jquery.fancybox.css?v=2.1.2" media="screen" />

<script type="text/javascript" language="javascript">

<!--

	function validate_form()

	{

		var forms = document.search_form;
			
		if(forms.poll_type.value == "0")
		{
			alert("Select poll type");
			return false;	
		}

		return true;

	}

	//-->

</script>

';


$template->heading();

$poll 		= new poll();
if(isset($_REQUEST['search'])){
	$poll->search = true;	
}
if(isset($_REQUEST['search_word'])){
	$poll->search_word = $_REQUEST['search_word'];	
}


if(isset($_REQUEST['poll_type'])){
	$poll->poll_type = $_REQUEST['poll_type'];	
}


if(isset($_REQUEST['search_word'])) 
{
	
	$poll->search_word=$search_word	   = functions::clean_string($_REQUEST['search_word']);
	 
		$validation		= new validation();
		if($_REQUEST['search'] == 'Go'){
		//$validation->check_four_object($search_word, $poll->office_id, $poll->beds,$poll->poll_status_id, 'either select office, number of beds, status, or  enter poll code', 'search_word');
	   }	
	
	
	if ($validation->checkErrors())
	{
		$poll->error	= $validation->getallerrors();
	}
}	

if(isset($_POST['action_type']) && $_POST['action_type']=="delete")
{
	$selected_id	= array();
	if( count($_POST['checkbox']) > 0)
	{   
		foreach($_POST['checkbox'] as $id => $val)
		{
			$selected_id[] = $id;
		}
		$poll->remove_selected($selected_id);
	}
	else
	{
		//$poll->warning = "Select atleast one category to delete";
		$poll->warning = true;
	}
	if(!$poll->warning)
		{
					
			$json_var 	= '{"title":"Success", "text":"'.$poll->message.'","type":"success","width":"100%","url":"manage_poll.phptrip_id='.$trip_id.'"}';
			$notify 	= new notify();
			$notify->show_message($json_var);
		}
}
?>
<?php

if(isset($_SESSION['message_object']))
{
	$notify = unserialize($_SESSION['message_object']);
	$notify->show_message_redirect();	
	unset($_SESSION['message_object']);
}

?>

 
 
 
<script type="text/javascript" language="javascript">
	
			
		$(document).ready(function()
		{
			/*$("#dd-list").tableDnD(
			{
				onDrop: function(table, row)
				{
					var page = document.getElementById("page").value;
					var order = $.tableDnD.serialize() + "&action=update_order"  + "&page=" + page;
					//alert(order);
					$.post("ajax_update_poll_order.php", order, function(theResponse){ }); 
				}
			});
			$("a.grouped_elements").fancybox();*/
		});
		
		
		
	</script>

<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
	<tr>
		<td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
		<td colspan="2" class="topRepeat">&nbsp;</td>
		<td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
	<tr>
		<td rowspan="3" class="leftRepeat">&nbsp;</td>
		<td colspan="2" bgcolor="#FFFFFF"><div class="pageSearchContainer">
				<div class="pageTitle"><?php echo functions::deformat_string($page_title); ?></div>
       
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="pageSearch">
                   
					<tr>
						<td class="pageSearchLeft">&nbsp;</td>
						<td class="pageSearchBg"><form name="search_form" method="post" action="manage_poll.php">
								<div class="searchLabel txtBold txtMedium">Search &nbsp;</div>
								<!--<div class="searchBox">
									<input name="search_word"  id="search_word" type="text" class="textbox" value="<?php echo functions::format_text_field($poll->search_word); ?>" tabindex="1" />
									<?php if(!empty($poll->error["search_word"])) { ?>
									<span id="errmesg" class="error"><?php echo $poll->error["search_word"]; ?> </span>
									<?php } ?>
								</div>-->
                          
                                
								
								<div class="searchBox">
									<select  id="poll_type" name="poll_type" tabindex="1" size="1" class="dropdown">
                                        <option value="0" >--Select Poll Type--</option>
                                        <?php
																		
				
										for($i = 1; $i <= count($poll->poll_type_array); $i++)
										{
											$select = ' ';
				
											if($i == $poll->poll_type)
											{
												$select = ' selected ';
											}                         
				
											echo '<option  value="' . $i . '" ' . $select . '>' . functions::deformat_string($poll->poll_type_array[$i] ) . '</option>';
										}
				
										?>
                                      </select>
								</div>
								
							
								<div class="submitBtnArea">
									<input type="submit" id="search" name="search"  class="go" value="Go" title="Search" tabindex="5" onclick="javascript:return validate_form();"/>
                                    <input type="hidden" id="trip_id" name="trip_id"  value="<?php echo $trip_id ?>"  />
								</div>
								<div class="submitBtnArea noMarginRight">
									<input type="button" id="view_all" name="view_all" class="submit" value="View All" title="View All" tabindex="6" onClick="javascript:location.href='manage_poll.php?trip_id=<?php echo $trip_id ?>';"  />
								</div>
								<input type="hidden" id="page" name="page" value="1" />
							</form></td>
						<td class="pageSearchRight">&nbsp;</td>
					</tr>
				</table>
			</div>
			
			<!--<div class="contentSublinks txtBold">
				<?php
			$page_name	= 'register_poll.php';
			$page_title	= 'Add Wedding poll';
			?><div class="spacer"></div>
				<img src="images/icon-property.png" alt="<?php echo $page_title; ?>" title="<?php echo $page_title; ?>" width="24" height="24" class="imgBlock" /> <a href="<?php echo $page_name; ?>"><?php echo $page_title; ?></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				
				 </div>-->
			<div class="clearFloat"></div>
			<div class="spacer"></div>
            
            <div class="breadcrumbs txtBold">
            
            <?php
			   $trip				= new trip($trip_id);
			 
			echo '<a href="manage_trip.php"> Manage Trips</a> >> <a href="manage_trip.php">'. utf8_encode(functions::deformat_string($trip->trip_name)). '</a> >> Manage Trip Poll';
			  ?>
            
            
          </div>
          
            </td>
		<td rowspan="3" class="rightRepeat">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="2" bgcolor="#FFFFFF"><form id="list_form" name="list_form" method="post">
				<table border="0" cellspacing="0" cellpadding="0" class="listing" id="dd-list">
					<tr class="header nodrop nodrag">
						<td class="pageNumberCol alignCenter">No.</td>
						<td class="usernameCol">Poll Type</td>
						<td class="alignCenter joiningDateCol">Start Date</td>
                        <td class="alignCenter joiningDateCol">End Date</td>
						<td class="widthAuto">Location</td>
                        <td class="alignCenter statusCol">Votes</td>
                        <td class="statusCol">Selected</td>
                       
						
					</tr>
					<tr class="lightColorRow nodrop nodrag">
						<td  class="noBorder" colspan="11">&nbsp;</td>
                       
						<!--<td class="noBorder alignCenter"><input type="checkbox" name="t_select_all" id="t_select_all" onclick="javascript:return toggle_select_all('t_select_all','list_form');" /></td>-->
					</tr>
					<?php
						$poll->display_list();
			?>
				</table>
				<?php
			if($poll->num_rows > 0)
			{
			?>
				<table border="0" cellspacing="0" cellpadding="0" class="listing noBorderTop">
					<tr class="footer">
						<td class="noBorder alignRight"><?php
							/*if(isset($_REQUEST['search']) && !isset($_REQUEST['view_all'])) 
							{
								echo '<div class="note txtTheme floatLeft"><span class="txtRed">Note : </span>Ordering is not available with search functionality.</div>';
							}
							else
							{
								echo '<div class="note txtTheme floatLeft"><span class="txtRed">Note : </span>Click and drag the particular row to change the menu item order. Numbering will get updated once the page gets refreshed.</div>';						
							}*/
							?>
							<!--<span>
							<input name="Submit" type="button" value="Check All" class="checkUncheckBtn" onclick="javascript:return select_all('list_form');" />
							/
							<input name="Submit" type="button" value="Uncheck All" class="checkUncheckBtn" onclick="javascript:return unselect_all('list_form');" />
							</span>--></td>
						<td  class="noBorder alignCenter deleteCol">&nbsp;<!--<a style="cursor:pointer;" onclick="return delete_all('list_form', 't_select_all', 'wedding poll');"><img src="images/icon-delete.png" alt="Delete" title="Delete" width="19" height="19" /></a>--></td>
					</tr>
				</table>
				<?php
			}
			?>
				<input type="hidden" name="action_type" value="">
				<input type="hidden" name="search" id="search" value="<?php echo($poll->search);?>" />
				<input type="hidden" name="search_word" id="search_word" value="<?php echo($poll->search_word);?>" />
			</form></td>
	</tr>
	<tr>
		<td colspan="2" bgcolor="#FFFFFF" ><div class="pagination alignCenter">
				<?php 
			$limit1			= functions::$limits;
			$page =  $_GET['page'];
			functions::paginate($poll->num_rows, 1, $poll->pager_param);
			?>
				<div class="clear"></div>
			</div></td>
	</tr>
	<tr>
		<td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
		<td colspan="2" class="bottomRepeat">&nbsp;</td>
		<td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
</table>
<!-- This contains the hidden content for inline calls -->
<?php 
	$template->footer();
?>
