<?php
/*********************************************************************************************
Author 	: V V VIJESH
Date	: 14-April-2011
Purpose	: Register content
*********************************************************************************************/

ob_start();
session_start();
include_once("../includes/config.php");
//include_once("../library/fckeditor/fckeditor.php");

// Check the admin user is loged in or not
if (!isset($_SESSION[ADMIN_ID]))
{
	functions::redirect("login.php");
	exit;
}
$content_id	= (isset($_REQUEST['content_id']) &&  $_REQUEST['content_id']) > 0 ? $_REQUEST['content_id'] : 0;

if($content_id > 0)
{
	$page_title = 'Edit Content';
}
else
{
	$page_title = 'Add Content';
}

$default_page_title		= 'Manage Content';
$default_page_uri		= 'manage_content.php';
// Cancel button action starts here
if(isset($_POST['cancel']))	
{
	functions::redirect($default_page_uri);
}

$content_length 			= 1000;
// Set template details
$template 				= new template();
$template->type			= 'ADMIN';
$template->left_menu	= true;
$template->admin_id		= $_SESSION[ADMIN_ID];
//$template->title		= $page_title;
$template->js			= '
<script type="text/javascript" language="javascript" src="' . URI_LIBRARY . 'jquery/jquery-min.js"></script>
<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>
<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'content.js"></script>
<script type="text/javascript" language="javascript">
	function validate_form()
	{
		var forms = document.register_content;
		
		if(forms.content_id.value == 0 || forms.content_id.value > 4)
		{
			if (!check_blank(forms.category_id, "Category is required!"))
			{	return false;	}
		}
		if (!check_blank(forms.name, "Page name is required!"))
		{	return false;	}
		if (!check_blank(forms.seo_url, "SEO URL is required!"))
		{	return false;	}
		if (!check_blank(forms.title, "Title is required!"))
		{	return false;	}
		if (!check_editor_content("content","Content is required"))
		{	return false;	}
		return true;
	}
</script>';
$template->css ='<link type="text/css" rel="stylesheet" href="' . URI_LIBRARY . 'calendar/calendar.css" title=\'calendar\' />';	

$template->heading();

// Save button action starts here
if(isset($_POST['save']))
{
	$content					= new content();
	$content->content_id		= $content_id;
	$content->name				= functions::clean_string($_POST['name']);
	$content->category_id				= functions::clean_string($_POST['category_id']);
	$content->seo_url			= functions::clean_string($_POST['seo_url']);
	$content->title				= functions::clean_string($_POST['title']);
	$content->author			= functions::clean_string($_POST['author']);
	$content->meta_description	= functions::clean_string($_POST['meta_description']);
	$content->meta_keywords		= functions::clean_string($_POST['meta_keywords']);
	$content->content			= functions::clean_string($_POST['content']);
	
	$validation		= new validation();
	
	if($content->content_id == 0 || $content->content_id > 4)
	{
		$validation->check_blank($content->category_id, "Category", "category_id");
	}
	$validation->check_blank($content->name, "Name", "name");
	$validation->check_blank($content->seo_url, "SEO URL", "seo_url");
	$validation->check_blank($content->title, "Page Title", "title");
	$validation->check_editor_content($content->content, "Content", "content");
	
	if (!$validation->checkErrors())
	{
		$content->seo_url		.= '.' . CONTENT_EXTENSION;
		if($content->save())
		{
			if($content_id == 0)
			{
				$content->content_id		= 0;
				$content->name				= '';
				$content->category_id		= 0;
				$content->seo_url		= '';
				$content->title				= '';
				$content->author			= '';
				$content->meta_description	= '';
				$content->meta_keywords		= '';
				$content->content			= '';
			}
		}
	}
	else
	{
		$content->error	= $validation->getallerrors();
	}
		if(!$content->warning)
		{
		  	$json_var 	= '{"title":"Success", "text":"'.$content->message.'","type":"success","width":"100%","url":"manage_content.php"}';
		  	$notify 	= new notify();
		  	$notify->show_message($json_var);
		}
		if($content->warning)
		{
		  	$json_var 	= '{"title":"Error", "text":"'.$content->message.'","type":"error","width":"100%"}';
		  	$notify 	= new notify();
		  	$notify->show_message($json_var);
		}
}
else if (!isset($_POST["save"]))
{
	$content	= new content($content_id);
}

?>
<script type="text/javascript" src="<?php echo URI_LIBRARY; ?>fckeditor/fckeditor.js"></script>
<script language="javascript" type="text/javascript">
window.onload = function()
{
	var oFCKeditor			= new FCKeditor( 'content' );
	oFCKeditor.BasePath		= "<?php echo URI_LIBRARY.'fckeditor/'; ?>";
	oFCKeditor.Height		= "500" ;
	oFCKeditor.Width		= "710" ;
	oFCKeditor.Config['SkinPath'] = 'skins/silver/' ;
	oFCKeditor.ToolbarSet	= "Cms"; //Cms 
	oFCKeditor.ReplaceTextarea();
}

function auto_fill()
{
	var name	= $('#name').val();
		
	if($('#seo_url_edit').val() != 'N')
	{
		var seo_url = get_url_string(name);
		$('#seo_url').val(seo_url);
	}
	
	var title 	= name;
	$('#title').val(title);
}

function filter_string()
{
	var seo_url	= $('#seo_url').val();
	seo_url = get_url_string(seo_url);
	$('#seo_url').val(seo_url);
}

function get_url_string(string)
{
	string 		= string.toLowerCase();
	var seo_url = string.replace(/[^a-zA-Z 0-9]+/g,'-');
	seo_url 	= seo_url.replace(/ /g,'-');
	return seo_url;
}

</script>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
	<tr>
		<td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
		<td class="topRepeat">&nbsp;</td>
		<td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
	<tr>
		<td rowspan="2" class="leftRepeat">&nbsp;</td>
		<td bgcolor="#FFFFFF">
			<div class="contentHeader">
				<div class="pageTitle">
					<?php 
					if($content->content_id > 0)
					{
						$page_title = 'Edit Content';
					}
					echo functions::deformat_string($page_title);
					?>
				</div>
				<div class="contentSublinks txtBold"> <img src="images/manage-content.png" alt="<?php echo functions::deformat_string($default_page_title); ?>" title="<?php echo functions::deformat_string($default_page_title); ?>" width="24" height="24" class="imgBlock" /> <a href="<?php echo $default_page_uri; ?>"><?php echo functions::deformat_string($default_page_title); ?></a> </div>
			</div>
			<?php if(!empty($content->message)) { ?>
			<span class="<?php echo $content->warning ? 'warningMesg' : 'infoMesg'; ?>  formPageWidth"> <?php echo $content->message; ?> </span>
			<?php } ?>
			<div class="spacer"></div></td>
		<td rowspan="2" class="rightRepeat">&nbsp;</td>
	</tr>
	<tr>
		<td bgcolor="#FFFFFF"><form name="register_content" id="register_content" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data" >
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="form">
                
                <?php if($content->content_id > 4 || $content->content_id == 0) { ?>
                <tr>
						<td>Category<span class="txtRed">*</span></td>
						<td>
                       					
							<select id="category_id" name="category_id"  size="1" class="dropdown"  tabindex="1" >
                       <option value="" selected>Select category</option>';
                            <?php
														
							$category =category::get_category();
							foreach ($category as $data)
							{
									if($content->category_id== $data['category_id'])
									{
										$sel = 'selected';
									}
											
								echo '<option value="'.$data['category_id'].'"' .$sel.' >'. $data['name'].'</option>';
								
							}
							
							?>
							</select>	
                            
                            
                            					
							<?php if(!empty($content->error["category_id"])) { ?>
								<span id="errmesg" class="error"> <?php echo $content->error["category_id"]; ?></span>
							<?php } ?>
							<div class="spacer"></div>
						</td>
					</tr>
                    <?php } ?>
                    
					<tr>
						<td width="12%" >Page name<span class="txtRed">*</span></td>
						<td  width="88%"><input type="text" id="name" name="name" value="<?php echo functions::format_text_field($content->name); ?>" class="textbox" maxlength="100" tabindex="2" onkeyup="javascript: auto_fill();" />
							<div class="txtTheme noLineHeight note"><span class="txtRed">*Note : </span>Maximum 100 characters allowed.</div>
							<?php if(!empty($content->error["name"])) { ?>
							<span id="errmesg" class="error"> <?php echo $content->error["name"]; ?></span>
							<?php } ?>
							<div class="spacer"></div></td>
					</tr>
                    
					<tr>
						<td>SEO URL<span class="txtRed">*</span></td>
						<td><input type="text" id="seo_url" name="seo_url" onkeyup="javascript: filter_string();" value="<?php 
							$seo_url = '';
							if($content->seo_url != '')
							{
								$seo_url = str_replace('.' . CONTENT_EXTENSION, '', $content->seo_url);
							}
							echo functions::format_text_field($seo_url); ?>" class="textbox" maxlength="100" tabindex="3" <?php echo $content->seo_url_edit == 'N' ? ' readonly="readonly" ' : '' ?>   /><?php echo '.' . CONTENT_EXTENSION; ?>
							<div class="txtTheme noLineHeight note"><span class="txtRed">*Note : </span>Maximum 100 characters allowed.</div>
							<?php if(!empty($content->error["seo_url"])) { ?>
							<span id="errmesg" class="error"> <?php echo $content->error["seo_url"]; ?></span>
							<?php } ?>
							<div class="spacer"></div></td>
					</tr>
                    
                    <tr>
						<td>Title<span class="txtRed">*</span></td>
						<td><input type="text" id="title" name="title" value="<?php echo functions::format_text_field($content->title); ?>" class="textbox" maxlength="100" tabindex="4" />
						<div class="txtTheme noLineHeight note"><span class="txtRed">*Note : </span>Maximum 100 characters allowed.</div>
							<?php if(!empty($content->error["title"])) { ?>
							<span id="errmesg" class="error"> <?php echo $content->error["title"]; ?></span>
							<?php } ?>
							<div class="spacer"></div></td>
					</tr>
                    
					<tr>
						<td>Author</td>
						<td><input type="text" id="author" name="author" value="<?php echo functions::format_text_field($content->author); ?>" class="textbox" maxlength="50" tabindex="5" />
							<?php if(!empty($content->error["author"])) { ?>
							<span id="errmesg" class="error"> <?php echo $content->error["author"]; ?></span>
							<?php } ?>
							<div class="spacer"></div></td>
					</tr>
					<tr>
						<td>Meta description</td>
						<td><label>
						
						 <textarea name="meta_description" id="meta_description" cols="45" rows="5" class="textarea" tabindex="6" onKeyDown="limitText(this.form.meta_description,this.form.countdown1,<?php echo $content_length; ?>);" onKeyUp="limitText(this.form.meta_description,this.form.countdown1,<?php echo $content_length; ?>);"><?php echo functions::format_text_field($content->meta_description); ?></textarea>
						 <?php if(!empty($content->error["meta_description"])) { ?>
						<span id="errmesg" class="error"> <?php echo $content->error["meta_description"]; ?></span>
						<?php } ?>       
						</label>
						  <br>
						Maximum characters: <?php echo $content_length; ?> You have
						<input name="countdown1" id="countdown1" type="text" class="admincontent"   <?php if($content->meta_description!=""){?>value="<?php echo  $content_length - strlen($content->meta_description);?>"<?php }else{?> value="<?php echo $content_length; ?>"<?php }?> size="5" readonly>
						characters left.<br />
						<div class="spacer"></div></td>
					  </tr>
					  <tr>
						<td>Meta Keywords</td>
						<td><label>
						
						 <textarea name="meta_keywords" id="meta_keywords" cols="45" rows="5" class="textarea" tabindex="7" onKeyDown="limitText(this.form.meta_keywords,this.form.countdown2,<?php echo $content_length; ?>);" onKeyUp="limitText(this.form.meta_keywords,this.form.countdown2,<?php echo $content_length; ?>);"><?php echo functions::format_text_field($content->meta_keywords); ?></textarea>
						 <?php if(!empty($content->error["meta_keywords"])) { ?>
						<span id="errmesg" class="error"> <?php echo $content->error["meta_keywords"]; ?></span>
						<?php } ?>       
						</label>
						  <br>
						Maximum characters: <?php echo $content_length; ?> You have
						<input name="countdown2" id="countdown2" type="text" class="admincontent" <?php if($content->meta_keywords!=""){?>value="<?php echo  $content_length - strlen($content->meta_keywords);?>"<?php }else{?> value="<?php echo $content_length; ?>"<?php }?> size="5" readonly>
						characters left.<br />
						<div class="spacer"></div></td>
					  </tr>
                      	
					  <tr>
						<td>Content<span class="txtRed">*</span></td>
						<td>
						<?php
						/*
						$oFCKeditor = new FCKeditor('content');							
						$oFCKeditor->BasePath = URI_ROOT.'/library/fckeditor/';								
						$oFCKeditor->Value = stripslashes($content->content);
						
						$oFCKeditor->Height = "500" ;
						$oFCKeditor->Width = "710" ;
						$oFCKeditor->ToolbarSet = "Cms";
						$oFCKeditor->Create();
						*/
						?>
						<textarea name="content" id="content" cols="85" rows="30" tabindex="8" ><?php echo functions::format_text_field($content->content); ?></textarea>
						<?php
						if(!empty($content->error['content'])) { ?><span id="errmesg" class="error"><?php echo $content->error['content']; ?></span><?php } ?>  		      
						<div class="spacer"></div>
						</td>
					  </tr> 
					<tr>
						<td></td>
						<td ><input type="submit" id="button" name="save" value="Save" class="submit" title="Save" tabindex="9" onclick="javascript:return validate_form();" />
							<input type="submit" id="cancel" name="cancel" value="Cancel" class="submit" title="Cancel" tabindex="10" />
							
							<div class="spacer"></div></td>
					</tr>
					<tr>
						<td colspan="2" class="txtTheme required"><span class="txtRed">*</span> Required fields</td>
					</tr>
				</table>
				<input type="hidden" id="content_id" name="content_id" value="<?php echo $content->content_id; ?>" />
				<input type="hidden" id="seo_url_edit" name="seo_url_edit" value="<?php echo $content->seo_url_edit; ?>" />
			</form></td>
	</tr>
	<tr>
		<td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
		<td class="bottomRepeat">&nbsp;</td>
		<td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
</table>
<script language="javascript" type="text/javascript">
limitText(document.forms['register_content'].meta_description,document.forms['register_content'].countdown1, '<?php echo $content_length; ?>');
limitText(document.forms['register_content'].meta_keywords,document.forms['register_content'].countdown2, '<?php echo $content_length; ?>');
function limitText(limitField, limitCount, limitNum)
{
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		limitCount.value = limitNum - limitField.value.length;
	}
}
</script>
<?php 
	$template->footer();
?>
