<?php
/*********************************************************************************************
Author 	: V. V. VIJESH
Date	: 15-Apr-2011
Purpose	: Signup member
*********************************************************************************************/
ob_start("ob_gzhandler");
session_start();
include_once("../includes/config.php");

extract($_POST);
if	   ($match == "starts")		$like = " like '".$data."%' ";
elseif ($match == "ends")		$like = " like '%".$data."' ";
elseif ($match == "contains")   $like = " like '%".$data."%' ";

$database	= new database();

$sql 		= "select * from postcode where postcode ".$like." limit ".$limit;
$result 	= $database->query($sql) or die(mysql_error());
if ($result->num_rows > 0)
{
	while($data=$result->fetch_array())
	{
		if($getId == 1)
		{
			$list .= $data['postcode_id']."~";
	}
	//$list .= strtoupper($data['postcode'])."|";
		$list .= strtoupper($data['postcode']). "~" . $data['latitude'] . "~" . $data['longitude'] ."|";
	}

	// send all collected data to the office
	$list = substr($list,0,-1);
	echo $list;
}
else
{
	$sql 		= "select * from postcode where postcode like '%".$data."%' limit ".$limit;
	$result 	= $database->query($sql) or die(mysql_error());
	if ($result->num_rows > 0)
	{
		while($data=$result->fetch_array())
		{
			if($getId == 1)
			{
				$list .= $data['postcode_id']."~";
			}
			//$list .= strtoupper($data['postcode'])."|";
			$list .= strtoupper($data['postcode']). "~" . $data['latitude'] . "~" . $data['longitude'] ."|";
		}
	
		// send all collected data to the office
		$list = substr($list,0,-1);
		echo $list;
	}
	else
	{
		echo 0;
	}
}
?>