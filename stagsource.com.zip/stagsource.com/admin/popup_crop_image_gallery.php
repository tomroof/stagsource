<?php
/*********************************************************************************************
Author 	: SUMITH
Date	: 28-August-2013
Purpose	: Thumb Image Popup
*********************************************************************************************/
ob_start("ob_gzhandler");
session_start();
include_once("../includes/config.php");


$id					= (isset($_REQUEST['id']) &&  $_REQUEST['id']) > 0 ? $_REQUEST['id'] : 0;
$thumb_width		= (isset($_REQUEST['thumb_width']) &&  $_REQUEST['thumb_width']) > 0 ? $_REQUEST['thumb_width'] : 0;
$thumb_height		= (isset($_REQUEST['thumb_height']) &&  $_REQUEST['thumb_height']) > 0 ? $_REQUEST['thumb_height'] : 0;
$folder				= $_REQUEST['folder'];
$img				= $_REQUEST['img'];



if(isset($_REQUEST['ajax']))
{
	if($_REQUEST['ajax'] == 1)
	{
	    //Get the new coordinates to crop the image.
		$x1	 		= functions::clean_string($_REQUEST["x1"]);
		$y1 		= functions::clean_string($_REQUEST["y1"]);
		$x2 		= functions::clean_string($_REQUEST["x2"]);
		$y2 		= functions::clean_string($_REQUEST["y2"]);
		$width 		= functions::clean_string($_REQUEST["w"]);
		$height		= functions::clean_string($_REQUEST["h"]);
		
		$image_class	= new $folder($id);
		
		$image_name		= $image_class->image_name;
		if($image_name  == '')
		{
			$image_name		=  $img;
		}
	
		$dir_file	=   constant(strtoupper('DIR_'.$folder));
		$uri_file	=   constant(strtoupper('URI_'.$folder));
		//echo $dir_file.$image_name;
		//exit;
		//$image_gallery	= new image_gallery($id);
		//$thumbImage		= new thumbImage(DIR_IMAGE_GALLERY.$image_gallery->image_name);
		$thumbImage		= new thumbImage($dir_file.$image_name);
		$thumbImage->thumb_width = $thumb_width; //$width;
		$thumbImage->thumb_height = $thumb_height; //$height;
		//$cropped 		= $thumbImage->cropThumbImage(DIR_IMAGE_GALLERY.'thumb_'.$image_gallery->image_name, DIR_IMAGE_GALLERY.'thumbnail/thumbresize_'.$image_gallery->image_name,$width,$height,$x1,$y1);
		
		
		$cropped 		= $thumbImage->createThumb($dir_file.'thumb_'.$image_name, $dir_file.'thumbnail/thumbresize_'.$image_name, $width, $height, $x1, $y1, $x2, $y2);
		
		//newly added by francis to create a icon for thumb created
		//functions::autoResizeImageNotCroppedThumbnail(DIR_IMAGE_GALLERY,$image_name,'thumbnail/',IMAGE_GALLERY_ICON_WIDTH,IMAGE_GALLERY_ICON_HEIGHT);						
		
		functions::autoResizeImageNotCroppedThumbnail(DIR_IMAGE_GALLERY,$image_name,'icon/',IMAGE_GALLERY_ICON_WIDTH,IMAGE_GALLERY_ICON_HEIGHT);						
													
		//$cropped1 		= $thumbImage->createThumb($dir_file.'thumbnail/'.$image_name, $dir_file.'thumb_'.$image_name, $width, $height, $x1, $y1, $x2, $y2);
						
		if($cropped !='')
		{
			echo '1<>' . $uri_file.'thumb_'.$image_name;
		}
		
	}
	
	exit;
}
else
{
    //$image_gallery	= new image_gallery($id);
	
	
	$image_class	= new $folder($id);
    
	$image_name		= $image_class->image_name;
	if($image_name  == '')
	{
			$image_name		=  $img;
	}
		
	$dir_file	=   constant(strtoupper('DIR_'.$folder));
	$uri_file	=   constant(strtoupper('URI_'.$folder));
}
echo '<link rel="stylesheet" type="text/css" href="' . URI_LIBRARY . 'image-upload/css/common.css" media="screen" />';
?>

<link rel="stylesheet" href="<?php echo URI_LIBRARY; ?>imageareaselect/css/imageareaselect-default.css">
<link rel="stylesheet" href="<?php echo URI_LIBRARY; ?>imageareaselect/css/imageareaselect-animated.css">


<script src="<?php echo URI_LIBRARY ?>imageareaselect/scripts/jquery.imgareaselect.js"></script>
<script src="<?php echo URI_LIBRARY ?>imageareaselect/scripts/jquery.imgareaselect.min.js"></script>
<script src="<?php echo URI_LIBRARY ?>imageareaselect/scripts/jquery.imgareaselect.pack.js"></script>

<!--<script src="<?php echo URI_LIBRARY ?>imageareaselect/scripts/jquery.min.js"></script> -->
<!--<script src="<?php echo URI_LIBRARY ?>imageareaselect/scripts/jquery.imgareaselect.js"></script>
<script src="<?php echo URI_LIBRARY ?>imageareaselect/scripts/jquery.imgareaselect.min.js"></script>
<script src="<?php echo URI_LIBRARY ?>imageareaselect/scripts/jquery.imgareaselect.pack.js"></script>-->

<script language="javascript" type="text/javascript">

 $(document).ready(function() {
    var thumb_width	= '<?php echo $thumb_width ?>';
   var thumb_height	= '<?php echo $thumb_height ?>';
  
   var kk	=  $('#thumb_id').attr('src');
   $('#thumb_id').attr('src','');
   $('#thumb_id').attr('src',kk+'?'+Math.random());
   
   //var aspect_ratio		= thumb_width+':'+thumb_height;
   var aspect_ratio			= '1:'+parseFloat(thumb_height/thumb_width);
   //aspect_ratio				= thumb_width+':'+thumb_height;
   //maxWidth:200, maxHeight:200, 
   //x1:8, y1: 8, x2: (parseInt(thumb_width)+8), y2: (parseInt(thumb_height)+8)
   $('#image').imgAreaSelect({x1:0, y1: 0, x2: thumb_width, y2: thumb_height, minWidth:thumb_width, minHeight:thumb_height, aspectRatio: aspect_ratio, persistent: true, fadeSpeed:200, handles: true, onSelectChange: preview, onInit: preview, parent:'#inline_content',show:true});  //fadeSpeed:200, parent:'.container'
   
//$('#image').imgAreaSelect({x1:0, y1: 0, x2: thumb_width, y2: thumb_height, minWidth:thumb_width, minHeight:thumb_height, aspectRatio: aspect_ratio, persistent: false, fadeSpeed:200, handles: true, onSelectChange: preview, onInit: preview, parent:'#inline_content',show:true});  //fadeSpeed:200, parent:'.container'
    
  // $('#image').imgAreaSelect({x1: 0, y1: 0, x2: 100, y2: 100, minWidth:100, minHeight:100, aspectRatio: '1:1', persistent: false, fadeSpeed:200, handles: true, onSelectChange: preview, onInit: preview, parent: '#resultcontent'});  //fadeSpeed:200, parent:'.container'
  
  $('.imageselect_outer').show();
  
  
  $('#saveThumb').click(function(){
            var x1 = $('#x1').val();
            var y1 = $('#y1').val();
            var x2 = $('#x2').val();
            var y2 = $('#y2').val();
            var w = $('#w').val();
            var h = $('#h').val();
            if (x1 == "" || y1 == "" || x2 == "" || y2 == "" || w == "" || h == "") {
                alert("You must make a selection first");
                return false;
            }
            else 
			{
                //return true;
					$.ajax({
						type	: "POST",
						cache	: false,
						url		: "popup_crop_image_gallery.php?ajax=1",
						data	:  $("#crop_image").serialize(),
						success: function(data) {
						    //alert(data);
							var result = data.split('<>');
							if(result[0] == 1)
							{
								//alert(str);
								$('#saved_thumb').show();
								$('#thumb_id').show();
								$('#thumb_id').attr('src','');
								$('#thumb_id').attr('src',result[1]+'?'+Math.random());
								
								$('#thumb_id1').attr('src','');
   								$('#thumb_id1').attr('src',result[1]+'?'+Math.random());
		   						$('#thumb_id1').show();
							}
							else
							{
								
							}
						}
					});
					return false; 
            }
        });
	
});

function preview1(img, selection) {
    var scaleX = 100 / (selection.width || 1);
    var scaleY = 100 / (selection.height || 1);
  
    $('#image + div > img').css({
        width: Math.round(scaleX * 1200) + 'px',
        height: Math.round(scaleY * 800) + 'px',
        marginLeft: '-' + Math.round(scaleX * selection.x1) + 'px',
        marginTop: '-' + Math.round(scaleY * selection.y1) + 'px'
    });
}

function preview(img, selection) {

    var thumb_width			= parseInt('<?php echo $thumb_width ?>');
    var thumb_height		= parseInt('<?php echo $thumb_height ?>');
	///alert(thumb_height);
    var original_height		= img.height;
	var original_width		= img.width;


    if (!selection.width || !selection.height)
        return;
    
    /*var scaleX = 150 / selection.width;
    var scaleY = 150 / selection.height;*/
	
	var scaleX = thumb_width / selection.width;
    var scaleY = thumb_height / selection.height;

    $('#preview img').css({
        width: Math.round(scaleX * original_width),
        height: Math.round(scaleY * original_height),
        marginLeft: -Math.round(scaleX * selection.x1),
        marginTop: -Math.round(scaleY * selection.y1)
    });
	
    $('#x1').val(selection.x1);
    $('#y1').val(selection.y1);
    $('#x2').val(selection.x2);
    $('#y2').val(selection.y2);
    $('#w').val(selection.width);
    $('#h').val(selection.height);     
}

</script>

   <?php
        if(!file_exists($dir_file.'thumbnail/thumbresize_'.$image_name))
		{
			$size_array	= getimagesize( $dir_file.$image_name);
			if($size_array[0] < $size_array[1])
			{
				$orientation	= 1;	
			}
			else if($size_array[0] > $size_array[1])
			{
				$orientation	=  2;
			}
			else
			{
				$orientation	= 3;	
			}
        	$imageLib = new imageLib($dir_file.$image_name);
			$imageLib->resizeImage(600, 400, $orientation);
			$imageLib->saveImage($dir_file.'thumbnail/thumbresize_'.$image_name, 100);
		}
   ?>

   <div class="container demo" style="overflow:hidden;">
  <div style="float: left; width: 50%;">
    <!--<p class="instructions">
      Click and drag on the image to select an area. 
    </p>-->
 
    <div class="frame" id="selectarea" style="margin: 0 0.3em; width: 600px; height: 450px; ">   
      <img id="image" src="<?php echo $uri_file.'thumbnail/thumbresize_'.$image_name ?>" style="border: 4px solid gray;"/>
	</div> 
  </div>

   <div style="float: left; width: 23%;">
    <p style="font-size: 100%; font-weight: bold; margin-top: 2em; margin-left:132px; width:112px;">
      Selection Preview
    </p>
  
    <div class="frame"  style="margin: 0 11em; float:left; width:100%; position:relative;">
      <div id="preview" style="width: <?php echo $thumb_width ?>px; height: <?php echo $thumb_height ?>px; overflow: hidden; position:absolute; border: 2px solid gray;">
       
		<img src="<?php echo $uri_file.'thumbnail/thumbresize_'.$image_name ?>" style="width: <?php echo $thumb_width ?>px; height: <?php echo $thumb_height ?>px;" />
		
      </div>
	  
	  <div style="margin: -32px 12em 0px 150px; position:absolute;  width:100%">
	  <form action="crop.php" id="crop_image" name="crop_image" method="post">
<table style="padding-left: 1em;" border="0">
      <!--<thead>
        <tr>
          <th colspan="2" style="font-size: 100%; font-weight: bold; text-align: left; padding-left: 0.1em;">
            Coordinates &amp; Dimensions
          </th>
        </tr>
      </thead>-->
      <tbody>
        <tr>
          <td width="100" ><!--<span class="admn-gllry-text"><b>X<sub>1</sub>:</b></span> 
          &nbsp;--><input type="hidden" class="admn-gllry-frm" name="x1" id="x1" value="0" size="8" readonly/> </td>
 		  <td width="100"><!--<span class="admn-gllry-text"><b>Y<sub>1</sub>:</b></span>
          &nbsp;--> <input type="hidden" class="admn-gllry-frm" name="y1" id="y1" value="0" size="8" readonly /></td>  
        </tr>
        
        <tr>
          <td width="100"><!--<span class="admn-gllry-text"><b>X<sub>2</sub>:</b></span> 
          &nbsp;--><input type="hidden" class="admn-gllry-frm" name="x2" id="x2" value="100" size="8" readonly /></td>
		  <td width="100"><!--<span class="admn-gllry-text"><b>Y<sub>2</sub>:</b></span>
          &nbsp; --><input type="hidden" class="admn-gllry-frm" name="y2" id="y2" value="100" size="8"  readonly /></td>
        </tr>
        
		<tr>
			<td width="100"><!--<span class="admn-gllry-wdth"><b>Width:</b></span>
            &nbsp;--> <input type="hidden" class="admn-gllry-frm" name="w" value="100" id="w" size="12" readonly /></td>
            <td width="100"><!--<span class="admn-gllry-wdth"><b>Height:</b></span>
            &nbsp; --><input type="hidden" class="admn-gllry-frm" name="h" id="h" value="100" size="12" readonly /></td>
		</tr>
		<tr>
			
		<!-- </tr>
		 
		 <tr>
		  <td></td>
          <td></td>
		 </tr>
		  <tr>
		  <td></td>
          <td></td>
		 </tr>-->
		 
		 <tr>
		  <td colspan="2">
		  <div class="link1" style="margin-top:0px;"><ul><li><a style="cursor:pointer;" id="saveThumb" tabindex="8">Save Thumbnail</a></li></ul></div></td>
		 </tr>
      </tbody>
    </table>
		
   
	<input type='hidden' name='id'  id ="id" value='<?php echo $id ?>' />
	<input type='hidden' name='img'  id ="img" value='<?php echo $img ?>' />
	<input type='hidden' name='thumb_width'  id ="thumb_width" value='<?php echo $thumb_width ?>' />
	<input type='hidden' name='thumb_height'  id ="thumb_height" value='<?php echo $thumb_height ?>' />
	<input type='hidden' name='folder'  id ="folder" value='<?php echo $folder ?>' />
  
  
    </form>
	  </div>
	  
     </div>
	
    <span id="message_error" class="warningMesg"></span>

	
	<p id="saved_thumb" <?php if(!file_exists($dir_file . 'thumb_'.$image_name)) { echo 'style="display:none;font-size: 100%; font-weight: bold; margin-top: 17em; margin-left:132px; width:112px;"';} else { echo 'style="font-size: 100%; font-weight: bold; margin-top: 17em; margin-left:132px; width:112px;"'; } ?>>
     Saved Thumbnail
    </p>
  
    <div class="frame1"  style="margin: 10 12em;  padding-left: 11em; float:left">
    
    <!--<div style="position:absolute; width:10%; ">
     
		 		<div class="link1"><ul><li><a style="cursor:pointer;" id="saveThumb" tabindex="8">Save Thumbnail</a></li></ul></div>
     		</div>-->
	 
    <div>
	    
	   <?php 
	   
	   if(!file_exists($dir_file . 'thumb_'.$image_name) && $image_name!='')
	   {  ?>
	        <img id="thumb_id" src="" style="display:none; border: 2px solid gray;" width="<?php echo $thumb_width ?>" heght="<?php echo $thumb_height ?>"/> 
	   
	   <?php
	   }
	   else
	   { ?>
	   		<img id="thumb_id" src="<?php echo $uri_file . 'thumb_'.$image_name ?>" style="border: 2px solid gray;" width="<?php echo $thumb_width ?>" heght="<?php echo $thumb_height ?>" /> 
	  <?php  } ?>
	   
        
      </div>
      
          
      
      		 
    </div>
	

     
	</div>
    
