<?php
	/*********************************************************************************************
			Author 	: V V VIJESH
			Date	: 20-Nov-2010
			Purpose	: Change content status
	*********************************************************************************************/
	ob_start();
	session_start();
	include_once("../includes/config.php");

	$planning_gallery_id	= $_REQUEST['planning_gallery_id'];
	
	$status = planning_gallery::update_planning_gallery_status($planning_gallery_id);
	echo ($status == 'Y') ? 1 : 0;
?>