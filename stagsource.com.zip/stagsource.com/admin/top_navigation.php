<?php
	/*********************************************************************************************
			Author 	: V V VIJESH
			Date	: 10-Nov-2010
			Purpose	: Admin top navigation
	*********************************************************************************************/
	ob_start();
	session_start();
	include_once("../includes/config.php");
	//$change_password_permission	= page::get_admin_permission($_SESSION[ADMIN_ID], "change_password.php");			// Get manage_admin.php page permission
	?>
    
    <script type="text/javascript" language="javascript" src="<?php echo URI_LIBRARY; ?>pnotify/jquery.pnotify.js" ></script>
	<link href="<?php echo URI_LIBRARY; ?>pnotify/includes/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css" />  
 <link href="<?php echo URI_LIBRARY; ?>pnotify/jquery.pnotify.default.css" rel="stylesheet" type="text/css" />
 <script type="text/javascript" language="javascript">
	
	function show_message(options)
	{		
		var delay			= (options.delay !='undefined' && options.delay !='') ? options.delay: ($.pnotify.defaults.delay);
		var width			= (options.width !='undefined' && options.width !='') ? options.width: ($.pnotify.defaults.width);
		var history			= (options.history !='undefined' && options.history !='') ? options.history: ($.pnotify.defaults.history);
		var min_height		= (options.min_height !='undefined' && options.height !='') ? options.min_height: ($.pnotify.defaults.min_height);
		var animation		= (options.animation !='undefined' && options.animation !='') ? options.animationt: ($.pnotify.defaults.animation);
		var animate_speed	= (options.animate_speed !='undefined' && options.animate_speed !='') ? options.animate_speed: ($.pnotify.defaults.animate_speed);
		var shadow			= (options.shadow !='undefined' && options.shadow !='') ? options.shadow: ($.pnotify.defaults.shadow);
		var closer			= (options.closer !='undefined' && options.closer !='') ? options.closer: ($.pnotify.defaults.closer);
		var sticker			= (options.sticker !='undefined' && options.sticker !='') ? options.sticker: ($.pnotify.defaults.sticker);
		var hide			= (options.hide !='undefined' && options.hide !='') ? options.hide: ($.pnotify.defaults.hide);
		var mouse_reset		= (options.mouse_reset !='undefined' && options.mouse_reset !='') ? options.mouse_reset: ($.pnotify.defaults.mouse_reset);
		var remove			= (options.remove !='undefined' && options.remove !='') ? options.remove: ($.pnotify.defaults.remove);

		$.pnotify({
			title: options.title,
			text: options.text,
			type: options.type,	 //error, notice, success
			pnotify_history: history,
			pnotify_width: width,
			pnotify_min_height: min_height,
			pnotify_animation: animation,	//none,show,fade,slide
			pnotify_animate_speed: animate_speed,	//slow,def,normal,fast, or milliseconds 
			pnotify_delay: delay,
			pnotify_shadow: shadow,
			pnotify_closer: closer,
			pnotify_hide: hide,
			pnotify_mouse_reset: mouse_reset,
			pnotify_remove: remove,	
			pnotify_sticker: sticker,
		});
	}
	</script>
 
<div class="menuBar">
  <span class="curveLeft">&nbsp;</span>
  <div class="welcome txtMedium">Welcome to <?php echo ADMIN_TITLE; ?></div>
    <span class="curveRight">&nbsp;</span>
  <div class="topNav">
        <ul>
            <li><a href="index.php">Home</a></li>
			 <?php
			if (isset($_SESSION[ADMIN_ID]))
			{
			?>
      		<li><a href="manage_settings.php">Settings</a></li>
      		<?php
			}			
			?>
            <li><a href="change_password.php">Change Password</a></li>
          <li class="noBg"><a href="logout.php">Logout</a></li>
        </ul>
  </div>      
</div>