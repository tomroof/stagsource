<?php

/*********************************************************************************************

Author 	: V V VIJESH

Date	: 14-April-2011

Purpose	: Manage testimonial

*********************************************************************************************/

ob_start();
session_start();
include_once("../includes/config.php");


// Check the admin user is loged in or not

if (!isset($_SESSION[ADMIN_ID]))

{
	functions::redirect("login.php");
	exit;
}

	$planning_id		= (isset($_REQUEST['planning_id']) &&  $_REQUEST['planning_id']) > 0 ? $_REQUEST['planning_id'] : 0;
 
 $planning 		=  new planning($planning_id);
 if($planning->planning_id == 0)
 {
	functions::redirect("manage_planning.php");
	exit; 
 }
 
// $planning_rating_id	= (isset($_REQUEST['planning_rating_id']) &&  $_REQUEST['planning_rating_id']) > 0 ? $_REQUEST['planning_rating_id'] : 0;



$page_title				= 'Manage Rating & Comments';	

$template 				= new template();

$template->type			= 'ADMIN';

$template->left_menu	= true;

$template->admin_id		= $_SESSION[ADMIN_ID];

$template->js			= '



<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH .'planning_rating.js"></script>

<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>

<script type="text/javascript" language="javascript" src="' . URI_LIBRARY . 'jquery/jquery-min.js"></script>

<script type="text/javascript" language="javascript">

<!--

	function validate_form()

	{

		var forms = document.search_form;



		if (!check_blank(forms.search_word, "Search word is required "))

		{	return false;	}

		return true;

	}

	//-->

</script>

';



$template->heading();



$planning_rating 		= new planning_rating();

$planning_rating->planning_id = $planning_id;



if(isset($_REQUEST['search'])){

	$planning_rating->search = true;	

}

if(isset($_REQUEST['search_word'])){

	$planning_rating->search_word = $_REQUEST['search_word'];	

}



if(isset($_REQUEST['search_word'])) 

{

	$search_word	= functions::clean_string($_REQUEST['search_word']);

	$validation		= new validation();

	if($_REQUEST['search'] == 'Go'){

		$validation->check_blank($search_word, 'Search word', 'search_word');

	}	

	if ($validation->checkErrors())

	{

		$planning_rating->error	= $validation->getallerrors();

	}

}	



if(isset($_POST['action_type']) && $_POST['action_type']=="delete")

{

	$selected_id	= array();

	if( count($_POST['checkbox']) > 0)

	{   

		foreach($_POST['checkbox'] as $id => $val)

		{

			$selected_id[] = $id;

		}

		$planning_rating->remove_selected($selected_id);
		
		if(!$planning_rating->warning){
			$json_var 	= '{"title":"Success", "text":"'.$planning_rating->message.'","type":"success","width":"100%","url":"manage_planning_rating.php?planning_id='.$planning_id.'"}';
			$notify 	= new notify();
			$notify->show_message($json_var);
		}

	}

	else

	{

		//$planning_rating->warning = "Select atleast one category to delete";

		$planning_rating->warning = true;

	}

}
if(isset($_SESSION['message_object']))
{
		$notify = unserialize($_SESSION['message_object']);
		$notify->show_message_redirect();	
		unset($_SESSION['message_object']);
}
?>


<script>
function change_status(planning_rating_id, index)
	{
		$.ajax(
    	{
			 type: "POST",
			cache: false,
			url: "change_planning_rating_status.php?planning_rating_id="+planning_rating_id,
			success: function (data)
			{
				if(data == 0)
				{
					status				= 'Inactive'
					status_image		= 'images/icon-inactive.png';
					member_status_text	= 'Inactive';
				}
				else
				{
					status				= 'Active'
					status_image		= 'images/icon-active.png';
					member_status_text	= 'Active';
				}
				
				$('#status_image_'+index).attr('title',status);
				$('#status_image_'+index).attr('alt',status);
				$('#status_image_'+index).attr('src',status_image);
			}

   	   });	
	}
</script>


<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
	<tr>
		<td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
		<td colspan="2" class="topRepeat">&nbsp;</td>
		<td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>

	<tr>
		<td rowspan="3" class="leftRepeat">&nbsp;</td>
		<td colspan="2" bgcolor="#FFFFFF"><div class="pageSearchContainer">
				<div class="pageTitle"><?php echo functions::deformat_string($page_title); ?></div>
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="pageSearch">
					<tr>
						<td class="pageSearchLeft">&nbsp;</td>
						<td class="pageSearchBg"><form name="search_form" method="post" action="manage_planning_rating.php?planning_id=<?php echo $planning_id; ?>">
								<div class="searchLabel txtBold txtMedium">Search by Rating/Comment</div>
								<div class="searchBox">
									<input name="search_word" type="text" class="textbox" value="<?php echo functions::format_text_field($planning_rating->search_word); ?>" tabindex="1" />
									<?php if(!empty($planning_rating->error["search_word"])) { ?>
									<span id="errmesg" class="error"><?php echo $planning_rating->error["search_word"]; ?> </span>
									<?php } ?>
								</div>
								<div class="submitBtnArea">
									<input type="submit" id="search" name="search"  class="go" value="Go" title="Search" tabindex="2"  onclick="javascript:return validate_form();"/>
								</div>
								<div class="submitBtnArea noMarginRight">
									<input type="button" id="view_all" name="view_all" class="submit" value="View All" title="View All" tabindex="3" onClick="javascript:location.href='manage_planning_rating.php?planning_id=<?php echo $planning_id; ?>';"  />
								</div>
								<input type="hidden" id="planning_id" name="planning_id" value="<?php echo $planning_id; ?>" />
								<input type="hidden" id="page" name="page" value="1" />
							</form></td>
						<td class="pageSearchRight">&nbsp;</td>
					</tr>
				</table>
			</div>
			<div class="contentSublinks txtBold">
				<?php
			$page_name	= 'register_planning_rating.php';
			$page_title	= 'Add Rating & Comment';

			?>
				<img src="images/add-campaign.png" alt="<?php echo $page_title; ?>" title="<?php echo $page_title; ?>" width="24" height="24" class="imgBlock" /> <a href="<?php echo $page_name . "?planning_id=" . $planning_id; ?>"><?php echo $page_title; ?></a> </div>
			<div class="clearFloat"></div>
			<?php if(!empty($planning_rating_image->message)) { ?>
			<span class="<?php echo $planning_rating_image->warning ? 'warningMesg' : 'infoMesg'; ?>  formPageWidth"> <?php echo $planning_rating_image->message; ?> </span>
			<div class="spacer"></div>
			<?php } ?>
			<div class="breadcrumbs txtBold">
            
            <?php
			   $planning				= new planning($planning_id);
			   //$owner_type 			= new client($planning->client_id);
			
		

			echo '<a href="manage_planning.php"> Manage Wedding Planning</a> >> <a href="manage_planning.php">'. utf8_encode(functions::deformat_string($planning->vendor_name)). '</a> >> Manage Rating & Comment';
			  ?>
            
            
          </div></td>
		<td rowspan="3" class="rightRepeat">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="2" bgcolor="#FFFFFF"><form id="list_form" name="list_form" method="post">
				<table border="0" cellspacing="0" cellpadding="0" class="listing" id="dd-list">
					<tr class="header nodrop nodrag">
						<td class="pageNumberCol alignCenter">No.</td>
						<td class="joiningDateCol">Rating</td>
                        <td class="widthAuto">Comment</td>
                         <!--<td class="widthAuto">Name</td>
                          <td class="widthAuto">Email</td>-->
                        <td class="joiningDateCol">Date</td>
                        <td class="alignCenter statusCol">Status</td>
						<td class="alignCenter editCol">Edit</td>
						<td class="alignCenter editCol">Delete</td>
					</tr>
					<tr class="lightColorRow nodrop nodrag">
						<!--<td  class="noBorder">&nbsp;</td>
                        <td  class="noBorder">&nbsp;</td>-->
						<td  class="noBorder">&nbsp;</td>
						<td  class="noBorder">&nbsp;</td>
                        <td  class="noBorder">&nbsp;</td>
                        <td  class="noBorder">&nbsp;</td>
                        <td  class="noBorder">&nbsp;</td>
                        <td  class="noBorder">&nbsp;</td>
						<td class="noBorder alignCenter"><input type="checkbox" name="t_select_all" id="t_select_all" onclick="javascript:return toggle_select_all('t_select_all','list_form');" /></td>
					</tr>
					<?php
			$planning_rating->display_list();
			?>
				</table>
				<?php
			if($planning_rating->num_rows > 0)
			{
			?>
				<table border="0" cellspacing="0" cellpadding="0" class="listing noBorderTop">
					<tr class="footer">
						<td class="noBorder alignRight"><span>
							<input name="Submit" type="button" value="Check All" class="checkUncheckBtn" onclick="javascript:return select_all('list_form');" />
							/
							<input name="Submit" type="button" value="Uncheck All" class="checkUncheckBtn" onclick="javascript:return unselect_all('list_form');" />
							</span></td>
						<td  class="noBorder alignCenter deleteCol"><a style="cursor:pointer;" onclick="return delete_all('list_form', 't_select_all', 'rating');"><img src="images/icon-delete.png" alt="Delete" title="Delete" width="19" height="19" /></a></td>
					</tr>
				</table>
				<?php
			}
			?>
				<input type="hidden" name="action_type" value="">
				<input type="hidden" name="search" id="search" value="<?php echo($planning_rating->search);?>" />
				<input type="hidden" name="search_word" id="search_word" value="<?php echo($planning_rating->search_word);?>" />
			</form></td>
	</tr>
	<tr>
		<td colspan="2" bgcolor="#FFFFFF" ><div class="pagination alignCenter">
				<?php 
			$limit1			= functions::$limits;
			$page =  $_GET['page'];
			functions::paginate($planning_rating->num_rows, 1, $planning_rating->pager_param);
			?>
				<div class="clear"></div>
			</div></td>
	</tr>
	<tr>
		<td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
		<td colspan="2" class="bottomRepeat">&nbsp;</td>
		<td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
</table>
<!-- This contains the hidden content for inline calls -->

<?php 

	$template->footer();

?>

