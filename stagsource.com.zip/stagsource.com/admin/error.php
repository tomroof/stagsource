<?php
/*********************************************************************************************
Author 	: V V VIJESH
Date	: 04-Nov-2010
Purpose	: Display permission error details
*********************************************************************************************/
ob_start();
session_start();
include_once("../includes/config.php");

// Check the admin user is loged in or not
if (!isset($_SESSION[ADMIN_ID]))
{
	functions::redirect("login.php");
	exit;
}

$eid					= isset($_REQUEST['eid']) && $_REQUEST['eid'] != '' && defined($_REQUEST['eid']) ? $_REQUEST['eid'] : 'ER_00001';

$message				= $_REQUEST['msg'];
$template 				= new template();
$template->type			= 'ADMIN';
$template->admin_id		= $_SESSION[ADMIN_ID];
$template->left_menu	= true;
$template->heading();
?>
    <!-- container for the column mid-section -->
      <table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
        <tr>
          <td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
          <td class="topRepeat">&nbsp;</td>
          <td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
        </tr>
        <tr>
          <td class="leftRepeat">&nbsp;</td>
          <td bgcolor="#FFFFFF" height="300px">
          	<div class="iconHolder">
            <center>
            <b><font color="#FF0000">
			<?php
			print constant($eid);
			?> 
			</font></b>
            </center>
            </div></td>
          <td class="rightRepeat">&nbsp;</td>
        </tr>
        <tr>
          <td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
          <td class="bottomRepeat">&nbsp;</td>
          <td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
        </tr>
      </table>
    <!-- end content -->
<?php 
	$template->footer();
?>