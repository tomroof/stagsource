<?php
	/*********************************************************************************************
			Author 	: V V VIJESH
			Date	: 08-Nov-2010
			Purpose	: Change admin password
	*********************************************************************************************/
	ob_start();
	session_start();
	include_once("../includes/config.php");
	
	// Check the admin user is loged in or not
	if (!isset($_SESSION[ADMIN_ID]))
	{
		functions::redirect("login.php");
		exit;
	}
	
	$page_title		= 'Change Password';
	$default_page	= 'index.php';
	// Cancel button action starts here
	if(isset($_POST['cancel']))	
	{
		functions::redirect($default_page);
	}
	
	// Set template details
	$template 				= new template();
	$template->type			= 'ADMIN';
	$template->left_menu	= true;
	$template->admin_id		= $_SESSION[ADMIN_ID];
	//$template->title		= $page_title;
	$template->js			= '
	<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>
	<script type="text/javascript" language="javascript">
    <!--
        function validate_form()
        {
            var forms = document.frm_change_password;
            if (!check_blank(forms.current_password, "Current password cannot be empty!"))
            {	return false;	}
			if (!check_blank(forms.password, "New password cannot be empty!"))
            {	return false;	}
			if (!check_length(forms.password, 5, 15, "Password should be between 5 to 15 characters!"))
			{	return false;	}
			if (!check_blank(forms.confirm_password, "Confirmation password cannot be empty!"))
            {	return false;	}
			if (!check_length(forms.confirm_password, 5, 15, "Confirmation password should be between 5 to 15 characters!"))
			{	return false;	}
			if (!check_compare(forms.password, forms.confirm_password, "Confirmation password is not matching!"))
            {	return false;	}
            return true;
        }
    //-->
    </script>
	';
	$template->heading();
	
	// Save button action starts here
	if(isset($_POST['save']))
	{
		$admin				= new admin($_SESSION[ADMIN_ID]);
		$current_password	= functions::clean_string($_POST['current_password']);
		$password			= functions::clean_string($_POST['password']);
		$confirm_password	= functions::clean_string($_POST['confirm_password']);
		
		$validation			= new validation();
		$validation->check_blank($current_password, "Current password", "current_password");
		$validation->check_blank($password, "New password", "password");
		$validation->check_length($password, 5, 15, "New Password", "password");
		$validation->check_blank($confirm_password, "Confirmation password", "confirm_password");
		$validation->check_length($confirm_password, 5, 15, "Confirmation password", "confirm_password");
		$validation->check_compare($password, $confirm_password, "Confirmation password", "confirm_password");
		
		if (!$validation->checkErrors())
		{
			if($admin->change_password($current_password, $password))
			{
				$current_password	= '';
				$password			= '';
				$confirm_password	= '';
			}
		}
		else
		{
			$admin->error	= $validation->getallerrors();
		}
	}
	?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
  <tr>
    <td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
    <td class="topRepeat">&nbsp;</td>
    <td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
  </tr>
 <tr>
    <td rowspan="2" class="leftRepeat">&nbsp;</td>
    <td bgcolor="#FFFFFF">
        <div class="contentHeader">
      		<div class="pageTitle"><?php echo functions::deformat_string($page_title); ?></div>
      		<!--
			<div class="contentSublinks txtBold">
            	<a href="<?php echo functions::deformat_string($default_page); ?>"><< Home</a>
            </div>
			-->
        </div>
        <?php if(!empty($admin->message)) { ?>
            <span class="<?php echo $admin->warning ? 'warningMesg' : 'infoMesg'; ?> formPageWidth">
            <?php echo $admin->message; ?>
            </span>
        <?php } ?>
        <div class="spacer"></div>
      </td>
    <td rowspan="2" class="rightRepeat">&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF">
    	<form name="frm_change_password" id="frm_change_password" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
        <table width="100%" border="0" cellspacing="0" cellpadding="0" class="form">
          <tr>
            <td width="12%">Current Password<span class="txtRed">*</span></td>
            <td width="88%">
            	<input type="password" id="current_password" name="current_password" value="<?php echo functions::format_text_field($current_password); ?>" class="textbox" tabindex="1" maxlength="15" />
                <?php if(!empty($admin->error["current_password"])) { ?><span id="errmesg" class="error"><?php echo $admin->error["current_password"]; ?> </span><?php } ?>
                <div class="spacer"></div>
                </td>
          </tr>
          <tr>
            <td>New Password<span class="txtRed">*</span></td>
            <td >
				<input type="password" id="password" name="password" value="<?php echo functions::format_text_field($password); ?>" class="textbox"  tabindex="2" maxlength="15" />
                <?php if(!empty($admin->error["password"])) { ?><span id="errmesg" class="error"><?php echo $admin->error["password"]; ?> </span><?php } ?>
                <div class="spacer"></div>
                </td>
          </tr>
          <tr>
            <td>Confirm Password<span class="txtRed">*</span></td>
            <td >
				<input type="password" id="confirm_password" name="confirm_password" value="<?php echo functions::format_text_field($confirm_password); ?>" class="textbox" tabindex="3" maxlength="15" />
                <?php if(!empty($admin->error["confirm_password"])) { ?><span id="errmesg" class="error"><?php echo $admin->error["confirm_password"]; ?> </span><?php } ?>
                <div class="spacer"></div>
                </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td >
				<input type="submit" id="button" name="save" value="Save" class="submit" title="Save" tabindex="4" onclick="javascript:return validate_form();" />
                <input type="submit" id="cancel" name="cancel" value="Cancel" class="submit" title="Cancel" tabindex="5" />
				<div class="spacer"></div>
                </td>
          </tr>
          <tr>
            <td colspan="2" class="txtTheme required"><span class="txtRed">*</span> Required fields</td>
          </tr>
        </table>
      	</form>
      </td>
  </tr>
  <tr>
    <td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
    <td class="bottomRepeat">&nbsp;</td>
    <td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
  </tr>
</table>
<?php 
	$template->footer();
?>
