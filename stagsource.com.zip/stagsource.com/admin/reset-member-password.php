<?php
	/*********************************************************************************************
	Author 	: V V VIJESH
	Date	: 20-Nov-2010
	Purpose	: Reset member password
	*********************************************************************************************/
	ob_start();
	session_start();
	include_once("../includes/config.php");
		
	$member_id	= (isset($_REQUEST['member_id']) &&  $_REQUEST['member_id']) > 0 ? $_REQUEST['member_id'] : 0;
	
	if(isset($_REQUEST['save']))
	{		
		$member				= new member($member_id);
		$password			= functions::clean_string($_POST['password']);
		$confirm_password	= functions::clean_string($_POST['confirm_password']);
		
		$validation			= new validation();
		$validation->check_blank($password, "New password", "password");
		$validation->check_length($password, 5, 15, "New Password", "password");
		$validation->check_blank($confirm_password, "Confirmation password", "confirm_password");
		$validation->check_length($confirm_password, 5, 15, "Confirmation password", "confirm_password");
		$validation->check_compare($password, $confirm_password, "Confirmation password", "confirm_password");
		
		if (!$validation->checkErrors())
		{
			if($member->update_password($password))
			{
				$password			= '';
				$confirm_password	= '';
				echo 1;
			}
			
		}
		else
		{
			$member->error	= $validation->getallerrors();
			echo 0;
		}
		
		exit;
	}
	?>
    
    <script>
	$(document).ready(function() {
		$('#button_save').click(function() {
			var forms = document.compose_form;
			if (!check_blank(forms.password, "New password cannot be empty"))
            {	return false;	}
			if (!check_length(forms.password, 5, 15, "Password should be between 5 to 15 characters"))
			{	return false;	}
			if (!check_blank(forms.confirm_password, "Confirmation password cannot be empty"))
            {	return false;	}
			if (!check_length(forms.confirm_password, 5, 15, "Confirmation password should be between 5 to 15 characters"))
			{	return false;	}
			if (!check_compare(forms.password, forms.confirm_password, "Confirmation password is not matching"))
            {return false;	}
			
			$.ajax(
			{
				type: "POST",
				cache: false,
				url: "reset-member-password.php?save=save",
				data	:  $("#compose_form").serialize(),
				success: function (data)
				{
					if(data == 1)
					{
						$.fancybox.close();	
						show_message({
							title:'Success',
							text:'Password successfully updated!',
							type:'success',
							width:'100%'
						});
					}
					else
					{
						show_message({
							title:'Error',
							text:'Password not matching!',
							type:'error',
							width:'100%'
						});	
					}
				}
			});
			
		});
	});
	</script>
    
    
	<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
	  <tr>
		<td rowspan="2">&nbsp;</td>
		<td bgcolor="#FFFFFF">
			<?php if(!empty($member->message)) { ?>
				<span class="<?php echo $member->warning ? 'warningMesg' : 'infoMesg'; ?>  formPageWidth">
				<?php echo $member->message; ?>
				</span>
			<?php } ?>
			<!--<div class="spacer"></div>-->
		  </td>
		<td rowspan="2">&nbsp;</td>
	  </tr>
	  <tr>
		<td bgcolor="#FFFFFF">
			<form name="compose_form" id="compose_form" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
			<div class="resetPassword">
                 <div style="width:200px; height:25px; text-align:center; margin:3px 0px 25px 87px; font-size:22px; font-weight:bold;">Reset Password</div>
			<table width="100%" border="0" cellspacing="0" cellpadding="0" class="form">
			  <tr>
				<td width="40%">New Password<span class="txtRed">*</span></td>
				<td width="60%"><input type="password"  autocomplete="offo" id="password" name="password" value="<?php echo functions::format_text_field($password); ?>" class="textbox"  tabindex="1" maxlength="15" />
				<?php if(!empty($member->error["password"])) { ?><span id="errmesg" class="error"> <?php echo $member->error["password"]; ?></span><?php } ?>
				<div class="spacer"></div>
				</td>
			  </tr>
			  <tr>
				<td>Confirm Password<span class="txtRed">*</span></td>
				<td ><input type="password" id="confirm_password" name="confirm_password" value="<?php echo functions::format_text_field($confirm_password); ?>" class="textbox" tabindex="2" maxlength="15" />
				<?php if(!empty($member->error["confirm_password"])) { ?><span id="errmesg" class="error"> <?php echo $member->error["confirm_password"]; ?></span><?php } ?>
				<div class="spacer"></div>
				</td>
			  </tr>
			  <tr>
				<td>&nbsp;</td>
				<td >
					<input type="button" id="button_save" name="save" value="Save" class="submit" title="Save" tabindex="3" />
                    <input type="button" id="cancel" name="cancel" value="Cancel" class="submit" title="Cancel" tabindex="4"  onclick="javascript:$.fancybox.close();" />
					<div class="spacer"></div></td>
			  </tr>
			  <tr>
				<td colspan="2" class="txtTheme required"><span class="txtRed">*</span> Required fields</td>
			  </tr>
			</table>
			<input type="hidden" id="member_id" name="member_id" value="<?php echo $member_id; ?>" />
			 </div>
			</form>
		  </td>
	  </tr>
	</table>