<?php
/*********************************************************************************************
Author 	: V V VIJESH
Date	: 14-April-2011
Purpose	: Manage image category
*********************************************************************************************/
ob_start();
session_start();
include_once("../includes/config.php");

// Check the admin user is loged in or not
if (!isset($_SESSION[ADMIN_ID]))
{
	functions::redirect("login.php");
	exit;
}

$page_title				= 'Manage  Category';
$template 				= new template();
$template->type			= 'ADMIN';
$template->left_menu	= true;
$template->admin_id		= $_SESSION[ADMIN_ID];
$template->js			= '
<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>
<script type="text/javascript" language="javascript" src="' . URI_LIBRARY . 'jquery/jquery-min.js"></script>
<script type="text/javascript" language="javascript" src="'. ADMIN_JS_PATH .'category.js"></script>
<script type="text/javascript" language="javascript">
<!--
	function validate_form()
	{
		var forms = document.search_form;

		if (!check_blank(forms.search_word, "Search word is required "))
		{	return false;	}
		return true;
	}
//-->
</script>

<!--<script type="text/javascript" language="javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" language="javascript" src="' . URI_LIBRARY . 'colorbox/jquery.colorbox.js"></script>-->
<script type="text/javascript" language="javascript" src="' . URI_LIBRARY . 'jquery/jquery.tablednd.js"></script>
<!--<link type="text/css" media="screen" rel="stylesheet" href="' . URI_LIBRARY . 'colorbox/colorbox.css" />-->
<script>
	$(document).ready(function(){
		//$("a[rel=\'example1\']").colorbox();
		
			$("#dd-list").tableDnD(
			{
				onDrop: function(table, row)
				{
					var page = document.getElementById("page").value;
					var order = $.tableDnD.serialize() + "&action=update_order"  + "&page=" + page;
					//alert(order);
					$.post("ajax_update_category_order.php", order, function(theResponse){ }); 
				} 
			});
	});
</script>';

$template->heading();

$category 		= new category();
if(isset($_REQUEST['search'])){
	$category->search = true;	
}
if(isset($_REQUEST['search_word'])){
	$category->search_word = $_REQUEST['search_word'];	
}

if(isset($_REQUEST['search_word'])) 
{
	$search_word	= functions::clean_string($_REQUEST['search_word']);
	$validation		= new validation();
	if($_REQUEST['search'] == 'Go'){
		$validation->check_blank($search_word, 'Search word', 'search_word');
	}	
	if ($validation->checkErrors())
	{
		$category->error	= $validation->getallerrors();
	}
}	

if(isset($_POST['action_type']) && $_POST['action_type']=="delete")
{
	$selected_id	= array();
	if( count($_POST['checkbox']) > 0)
	{   
		foreach($_POST['checkbox'] as $id => $val)
		{
			$selected_id[] = $id;
		}
		$category->remove_selected($selected_id);
	}
	else
	{
		//$category->warning = "Select atleast one category to delete";
		$category->warning = true;
	}
	
	if(!$category->warning)
	{					
		$json_var 	= '{"title":"Success", "text":"'.$category->message.'","type":"success","width":"100%","url":"manage_category.php"}';
		$notify 	= new notify();
		$notify->show_message($json_var);
	}
}
if($category->warning)
		{
			$json_var 	= '{"title":"Error", "text":"'.$category->message.'","type":"error","width":"100%"}';
			$notify 	= new notify();
			$notify->show_message($json_var);
		}
		else
		{
			$validation		= new validation();
			$category->error	= $validation->getallerrors();
		}
if(isset($_SESSION['message_object']))
{
	$notify = unserialize($_SESSION['message_object']);
	$notify->show_message_redirect();	
	unset($_SESSION['message_object']);
}
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
	<tr>
	  <td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
	  <td colspan="2" class="topRepeat">&nbsp;</td>
	  <td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
	<tr>
	  <td rowspan="3" class="leftRepeat">&nbsp;</td>
	  <td colspan="2" bgcolor="#FFFFFF">
		 <div class="pageSearchContainer">
		  <div class="pageTitle"><?php echo functions::deformat_string($page_title); ?></div>
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="pageSearch">
				  <tr>
					<td class="pageSearchLeft">&nbsp;</td>
					<td class="pageSearchBg">
					<form name="search_form" method="post" action="manage_category.php"> <div class="searchLabel txtBold txtMedium">Search by    category name</div>
						  <div class="searchBox"><input name="search_word" type="text" class="textbox" value="<?php echo functions::format_text_field($category->search_word); ?>" tabindex="1" /><?php if(!empty($category->error["search_word"])) { ?><span id="errmesg" class="error"><?php echo $category->error["search_word"]; ?> </span><?php } ?></div>
						   <div class="submitBtnArea">
						   <input type="submit" id="search" name="search"  class="go" value="Go" title="Search" tabindex="2"  onclick="javascript:return validate_form();"/>
					</div><div class="submitBtnArea noMarginRight"><input type="button" id="view_all" name="view_all" class="submit" value="View All" title="View All" tabindex="3" onClick="javascript:location.href='manage_category.php';"  />
					</div>
					<input type="hidden" id="page" name="page" value="1" />
					</form>
					</td>
					<td class="pageSearchRight">&nbsp;</td>
				  </tr>
				</table>
		   </div>
		   <div class="contentSublinks txtBold">
			<?php
			$page_name	= 'register_category.php';
			$page_title	= 'Add  Category';
			?>
		   <img src="images/manage-content.png" alt="<?php echo $page_title; ?>" title="<?php echo $page_title; ?>" width="24" height="24" class="imgBlock" /> <a href="<?php echo $page_name; ?>"><?php echo $page_title; ?></a>
		   </div>
		   <div class="clearFloat"></div>
			<?php //if(!empty($category->message)) { ?>
			<!--<span class="<?php echo $category->warning ? 'warningMesg' : 'infoMesg'; ?>  formPageWidth">-->
			<?php //echo $category->message; ?>
			<!--</span><div class="spacer"></div>-->
			<?php //} ?>
		</td>
	  <td rowspan="3" class="rightRepeat">&nbsp;</td>
	</tr>
	<tr>
	  <td colspan="2" bgcolor="#FFFFFF">
	  <form id="list_form" name="list_form" method="post">
		<table border="0" cellspacing="0" cellpadding="0" class="listing" id="dd-list">
			<tr class="header nodrop nodrag">
				<td class="pageNumberCol alignCenter">No.</td>
				<td class="widthAuto"> Category Name</td>
				<td class="alignCenter joiningDateCol">Status</td>
				<td class="alignCenter editCol">Edit</td>
				<td class="alignCenter editCol">Delete</td>
			</tr>
			<tr class="lightColorRow nodrop nodrag">
				<td  class="noBorder">&nbsp;</td>
				<td  class="noBorder" >&nbsp;</td>
				<td  class="noBorder">&nbsp;</td>
				<td  class="noBorder">&nbsp;</td>
				<td class="noBorder alignCenter">
					<input type="checkbox" name="t_select_all" id="t_select_all" onclick="javascript:return toggle_select_all('t_select_all','list_form');" />
				</td>
			</tr>
			<?php
			$category->display_list();
			?>
			</table>
			<?php
			if($category->num_rows > 0)
			{
				?>
				<table border="0" cellspacing="0" cellpadding="0" class="listing noBorderTop">
					<tr class="footer">
						<td class="noBorder alignRight">
						<?php
						
					/*	if(isset($_REQUEST['search']) && !isset($_REQUEST['view_all'])) 
						{
							echo '<div class="note txtTheme floatLeft"><span class="txtRed">Note : </span>Ordering is not available with search functionality.</div>';
						}
						else
						{
							echo '<div class="note txtTheme floatLeft"><span class="txtRed">Note : </span>Click and Drag the particular row to change the category order. Numbering will get updated once the page got refreshed.</div>';						
						}
						*/
						?>
						<span>
						<input name="Submit" type="button" value="Check All" class="checkUncheckBtn" onclick="javascript:return select_all('list_form');" />        
						/ <input name="Submit" type="button" value="Uncheck All" class="checkUncheckBtn" onclick="javascript:return unselect_all('list_form');" />
						</span>
						</td>
						<td  class="noBorder alignCenter deleteCol">
							<a style="cursor:pointer;" onclick="return delete_all('list_form', 't_select_all', 'category');"><img src="images/icon-delete.png" alt="Delete" title="Delete" width="19" height="19" /></a>
						</td>
					</tr>
				</table>
			<?php
			}
			?>
			<input type="hidden" name="action_type" value="">
			<input type="hidden" name="search" id="search" value="<?php echo($category->search);?>" />
			<input type="hidden" name="search_word" id="search_word" value="<?php echo($category->search_word);?>" />
		</form>
		</td>
	</tr>
	<tr>
	  <td colspan="2" bgcolor="#FFFFFF" >
		<div class="pagination alignCenter">
			<?php 
			$limit1			= functions::$limits;
			$page =  $_GET['page'];
			functions::paginate($category->num_rows, 1, $category->pager_param);
			?>
			<div class="clear"></div>			
		</div>
	  </td>
	</tr>
	<tr>
	  <td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
	  <td colspan="2" class="bottomRepeat">&nbsp;</td>
	  <td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
  </table>
<?php 
$template->footer();
?>