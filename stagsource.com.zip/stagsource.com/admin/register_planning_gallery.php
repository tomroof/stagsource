<?php
/*********************************************************************************************
Date	: 14-April-2011
Purpose	: Register image gallery
*********************************************************************************************/
ob_start();
session_start();
set_time_limit(0);

include_once("../includes/config.php");
// Check the admin user is loged in or not
if (!isset($_SESSION[ADMIN_ID]) && !isset($_SESSION[AGENT_ID]))
{
	functions::redirect("login.php");
	exit;
}

$planning_id		= (isset($_REQUEST['planning_id']) &&  $_REQUEST['planning_id']) > 0 ? $_REQUEST['planning_id'] : 0;

$planning 			= new planning($planning_id);

if($planning->planning_id == 0)
{
	functions::redirect("manage_planning.php");
	exit;
}


$_SESSION['planning_id']	= $planning_id;
$_SESSION['upload_edit']	= false;

$planning_gallery_id	= (isset($_REQUEST['planning_gallery_id']) &&  $_REQUEST['planning_gallery_id']) > 0 ? $_REQUEST['planning_gallery_id'] : 0;

if($planning_gallery_id > 0)
{
	$page_title = 'Edit Page Image';
}
else
{
	$page_title = 'Add Images';
}

$default_page_title		= 'Manage Images';
$default_page_uri		= 'manage_planning_gallery.php';
// Cancel button action starts here
if(isset($_POST['cancel']))	
{
	//functions::redirect('index.php');
	functions::redirect($default_page_uri . "?planning_id=" . $planning_id);
}

// Set template details
$template 				= new template();
$template->type			= 'ADMIN';
$template->left_menu	= true;
$template->admin_id		= $_SESSION[ADMIN_ID];
//$template->title		= $page_title;
$template->js			= '';
$template->heading();

?>
<link rel="stylesheet" type="text/css" href="<?php echo URI_LIBRARY ?>image-upload/css/common.css" media="screen" />

<link rel="stylesheet" href="<?php echo URI_LIBRARY ?>image-upload/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo URI_LIBRARY ?>image-upload/css/blueimp-gallery.min.css">
<link rel="stylesheet" href="<?php echo URI_LIBRARY ?>image-upload/css/jquery.fileupload-ui.css">
<!--<script src="<?php echo URI_LIBRARY ?>jquery/jquery-min.js"> </script>-->


<?php
// Save button action starts here
if(isset($_POST['save']))
{
	
	$planning_gallery->planning_gallery_id	  = $planning_gallery_id;
	$planning_gallery->planning_id 	  		  = $planning_id;
	$planning_gallery->title			 	  = '';
	$planning_gallery->alt				 	  = '';
	$crop_image_name=$planning_gallery->image_name =$current_image_name	= functions::clean_string($_POST['current_image_name']);
	//$uploaded_image_name	= $_FILES['image_name'];
	//$imagename		= functions::clean_string($_POST['imagename']);
	
	
	$planning_gallery->description			= '';
	$image_process						= functions::clean_string($_POST['image_process']);
	
	if($image_process == 'crop')
	{
		$crop	= true;
	}
	else
	{
		$crop	= false;
	}
	$validation		= new validation();
	//$validation->check_blank($planning_gallery->title, "Name", "title");
	if($planning_gallery_id == 0 || is_uploaded_file($uploaded_image_name['tmp_name']))
	{
		//$validation->check_image_size($uploaded_image_name, 'Image' , "image_name", $image_size);
		//$validation->is_uploaded($uploaded_image_name, 'Image' , "image_name");
	}
	if (!$validation->checkErrors())
	{
		$functions		= new functions;

		if(!$functions->warning)
		{
			if($planning_gallery->save())
			{
				if($planning_gallery_id == 0)
				{
					$planning_gallery->planning_gallery_id	= 0;
					$planning_gallery->title				= '';
					$planning_gallery->alt					= '';
					$planning_gallery->image_name			= '';
					$planning_gallery->description			= '';
				}
			}
			if(!$planning_gallery->warning)
			{
				//$message	= "Success message";
				$json_var 	= '{"title":"Success", "text":"'.$planning_gallery->message.'","type":"success","width":"100%","url":"manage_planning_gallery.php?planning_id='.$planning_id.'&crop_image_name='.$crop_image_name.'&image_process='.$image_process.'"}';
				$notify 	= new notify();
				$notify->show_message($json_var);
			}
			
		}
		else
		{
			$planning_gallery->message	= $functions->message;
			$planning_gallery->warning	= $functions->warning;
		}
	}
	else
	{
		$planning_gallery->error	= $validation->getallerrors();
	}
	if($planning_gallery->warning)
	{
		$json_var 	= '{"title":"Error", "text":"'.$planning_gallery->message.'","type":"error","width":"100%"}';
		$notify 	= new notify();
		$notify->show_message($json_var);
	}
	
}
else if (!isset($_POST["save"]))
{
	$planning_gallery	= new planning_gallery($planning_gallery_id);
}

	
?>

<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
	<tr>
		<td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
		<td class="topRepeat">&nbsp;</td>
		<td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
	<tr>
		<td rowspan="2" class="leftRepeat">&nbsp;</td>
		<td bgcolor="#FFFFFF">
			<div class="contentHeader">
				<div class="pageTitle">
					<?php 
					if($planning_gallery->planning_gallery_id > 0)
					{
						$page_title = 'Edit Property';
					}
					echo functions::deformat_string($page_title);
					?>
				</div>
				<div class="contentSublinks txtBold"> <img src="images/manage-image.png" alt="<?php echo functions::deformat_string($default_page_title); ?>" title="<?php echo functions::deformat_string($default_page_title); ?>" width="24" height="24" class="imgBlock" /> <a href="<?php echo $default_page_uri."?planning_id=" . $planning_id; ?>"><?php echo functions::deformat_string($default_page_title); ?></a> </div>
			</div>
			<div class="spacer"></div></td>
		<td rowspan="2" class="rightRepeat">&nbsp;</td>
	</tr>
	<tr>
    <td bgcolor="#FFFFFF" style="overflow:visible">
				  <div>Minimum Image Size required: <?php echo PLANNING_GALLERY_MIN_WIDTH ?> x <?php echo PLANNING_GALLERY_MIN_HEIGHT ?> pixels.</div><br />
				  <?php
						//Initialize the upload form and listings
						$uploadForm		= new UploadForm(); 		//library class
						$uploadForm->createSingleForm(true, true, true, true, true);  //Single form upload(can upload multiple/single files)
				   ?>

					
				<!--<input type="hidden" id="planning_id" name="planning_id" value="<?php echo $planning_id; ?>" />-->

	</tr> 
	<tr>
		<td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
		<td class="bottomRepeat">&nbsp;</td>
		<td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
</table>
<?php 
	$template->footer();
?>

<!-- The blueimp Gallery widget -->
<div id="blueimp-gallery" class="blueimp-gallery blueimp-gallery-controls" data-filter=":even">
    <div class="slides"></div>
    <h3 class="title"></h3>
    <!--<a class="prev">‹</a>-->
	<a class="prev">&lsaquo;</a>
   <!-- <a class="next">›</a>-->
    <a class="next">&rsaquo;</a>
    <!--<a class="close">×</a>-->
	<a class="close">&times</a>
    <a class="play-pause"></a>
    <ol class="indicator"></ol>
</div>


<!--   Required jquery-min.js, can be omitted if jQuery-min.js is already included  -->
<!--    includes required js for  upload and gallery/listing  -->

<script src="<?php echo URI_LIBRARY ?>image-upload/js/upload_image.js"> </script>

<script>


$(function () {
    'use strict';
	
	if(navigator.userAgent.match(/MSIE 8/) || navigator.userAgent.match(/MSIE 9/) || navigator.userAgent.match(/MSIE 7/)){
		$('.progress').hide();	
	}
	
	
	
	
    // Initialize the jQuery File Upload widget:
    $('#fileupload').fileupload({
        // Uncomment the following to send cross-domain cookies:
        //xhrFields: {withCredentials: true},
        //url: 'server/php/',
		url: 'upload_image.php?folder=planning_gallery',		
		maxNumberOfFiles:1000,
		acceptFileTypes: /(\.|\/)(jpe?g|png)$/i,
		//multipart: true,
		
		disableImageResize: /Android(?!.*Chrome)|Opera/
        .test(window.navigator && navigator.userAgent),
    	/*imageMaxWidth: 800,
    	imageMaxHeight: 600,
		maxHeight: 800,
		maxWidth: 600,
    	imageCrop: false,*/
		previewMaxWidth:80,
		previewMaxHeight:80,
		imageMaxWidth: 6920,
        imageMaxHeight: 5080,
		previewCrop: true,
		
		/*done: function (e, data) {
            $.each(data.result.files, function (index, file) {
                $('<p/>').text(file.name).appendTo('#files');
            });
        }, */
        /*progressall: function (e, data) {
			//alert("value="+data.total);
            var progress = parseInt(data.loaded / data.total * 100, 10);
            $('#progress .progress-bar').css(
                'width',
                progress + '%'
            );
        }*/
    });
	
	$('#fileupload').bind('fileuploadadd', function (e, data) {	
		if(navigator.userAgent.match(/MSIE 8/) || navigator.userAgent.match(/MSIE 9/) || navigator.userAgent.match(/MSIE 7/)){
			$('.progress').hide();	
		}
	});
		
	$('#fileupload').bind('fileuploadsubmit', function (e, data) {												
		var input = $('#planning_id');
    	var inputs = data.context.find(':input');
		//alert(input.val());
		//if (inputs.filter('[required][value=""]').first().focus().length) {
		if($.trim(inputs.filter('.required').first().val()).length == 0) {
			//return false;
		}
		
		data.formData = inputs.serializeArray();
		data.formData.push({name:'planning_id', value:input.val()});
		if(navigator.userAgent.match(/MSIE 8/) || navigator.userAgent.match(/MSIE 9/) || navigator.userAgent.match(/MSIE 7/)){
			$('.progress').hide();	
		}	
	});
	
	
	$('#fileupload').bind('fileuploadstopped', function (e, data) {	
		var p_id = <?php echo $planning_id ?>;
		
		var error_count = 0;
		var success_count = 0;
		
		$('.files').each(function() {
			$(this).find('.template-download').each(function() {
				if($(this).find('.label-important').text() == 'Error')
				{
					error_count++;
				}
				else
				{
					success_count++;	
				}
			});
		});
		
		var min_width   = <?php echo PLANNING_GALLERY_MIN_WIDTH; ?>;
		var min_height   = <?php echo PLANNING_GALLERY_MIN_HEIGHT; ?>;
		
		if(error_count == 0 &&  success_count > 0)
		{
			show_message({
				title:'Success',
				text:'Image(s) successfully uploaded',
				type:'success',
				width:'100%'
			});
			
			window.setTimeout( redirect, 500 );
			
			
		}
		else if(error_count > 0 &&  success_count > 0)
		{
			
			show_message({
				title:'Warning',
				text:'Some of the image(s) successfully uploaded, Required minimum width:'+min_width+'px and minimum height:' + min_height+'px',
				type:'notice',
				width:'100%'
			});
		}
		else if(error_count > 0 &&  success_count == 0)
		{
			show_message({
				title:'Error',
				text:'Image(s) not uploaded, Required minimum width:'+min_width+'px and minimum height:' + min_height+'px',
				type:'error',
				width:'100%'
			});
		}
		
	});
		
	// Load existing files/uploaded files
	singleFormUpload();
	//multipleFormUpload();
	

});

function redirect()
{
	var p_id = <?php echo $planning_id ?>;
	window.location='manage_planning_gallery.php?planning_id='+p_id;
}



</script>
