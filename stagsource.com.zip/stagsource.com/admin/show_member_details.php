<?php 
   	
ob_start();
session_start();
include_once("../includes/config.php");

$show		= (	isset($_REQUEST['show']) &&  ($_REQUEST['show'] > 0) ) ? trim($_REQUEST['show']) : 0;
$member_id	= (	isset($_REQUEST['member_id']) &&  ($_REQUEST['member_id'] > 0) ) ? trim($_REQUEST['member_id']) : 0;
$member	= new member($member_id);
if($show==1)
{
	?>
	<div class="expandSubmember">
	<table cellpadding="0" cellspacing="0" width="100%" class="expandDataTable">
		
		<tr>
			<td width="14%">First Name</td><td>
				<?php
				echo functions::deformat_string($member->first_name);
				?>
			 </td>
        </tr>
        
        <tr>
			<td>Surname</td><td>
				<?php
				echo functions::deformat_string($member->surname);
				?>
			 </td>
        </tr>
        
		  <tr>
			<td>Address</td><td>
				<?php
				echo nl2br(functions::deformat_string($member->address));
				?>
			 </td>
		</tr>
		
		<tr>
			<td>Contact Number</td><td>
				<?php
				echo functions::deformat_string($member->contact_number);
				?>
			 </td>
		</tr>
		<tr>
			<td>Email</td><td>
				<?php
				echo functions::deformat_string($member->email);
				?>
			 </td>
		</tr>
		
	
      
        <tr>
			<td>Username</td><td>
				<?php
				echo functions::deformat_string($member->username);
				?>
			 </td>
		</tr>
		
        <?php if(file_exists(DIR_MEMBER .$member->image_name) && $member->image_name!= '')
		{ ?>
        <tr>
			<td style="vertical-align:top;">Profile Image</td>
			<td> <?php
			
			if(file_exists(DIR_MEMBER . 'thumb_'.$member->image_name))
			{
				echo '<img src="'.URI_MEMBER . 'thumb_'.$member->image_name.'" border="0" />';	
			}  
			else
			{	
				  //$functions->autoResizeImageNotCropped(DIR_BANNER,$data->image_name,'thumb_',BANNER_MIN_WIDTH,BANNER_MIN_HEIGHT);	
				  $size_1	= getimagesize(DIR_MEMBER.$member->image_name);
				  $imageLib = new imageLib(DIR_MEMBER.$member->image_name);
				  //$imageLib->resizeImage(BOOK_THUMB_WIDTH, BOOK_THUMB_HEIGHT, 0);
				  if($size_1[0] > $size_1[1])
				  {
					  $imageLib->resizeImage(MEMBER_THUMB_WIDTH, MEMBER_THUMB_HEIGHT, 2);
				  }
				  else if($size_1[0] < $size_1[1])
				  {
					  $imageLib->resizeImage(MEMBER_THUMB_WIDTH, MEMBER_THUMB_HEIGHT, 1);
				  }
				  else
				  {
					  $imageLib->resizeImage(MEMBER_THUMB_WIDTH, MEMBER_THUMB_HEIGHT, 3);	
				  }
				  $imageLib->saveImage(DIR_MEMBER.'thumb1_'.$member->image_name, 90);
				  unset($imageLib);
				  echo '<img src="'.URI_MEMBER . 'thumb1_'.$member->image_name.'" border="0" />';
			 		// echo  '<img src="image_resize.php?image='.$discount->image_name.'&dir=discount&width='.$thumb_width.'&height='.$thumb_height.'"    border="0" />';
			} ?></td>

		</tr>
        
        <?php } ?>
        
        <tr>
               
			<td>Status</td>
			<td><div id='member_status_text'><?php echo $member->status == 'Y' ? 'Active' : 'Inactive'; ?></div></td>
		</tr>
		<tr>
			<td style="vertical-align:top;">Joining Date</td><td>
			<?php		
			echo functions::get_format_date($member->join_date, "d-m-Y");
			?>
			</td>
		</tr>
	
	</table>
	</div>
	<?php 
}
?>
