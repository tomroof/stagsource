<?php 
   	
ob_start();
session_start();
include_once("../includes/config.php");

$show				= (	isset($_REQUEST['show']) &&  ($_REQUEST['show'] > 0) ) ? trim($_REQUEST['show']) : 0;
$page_content_id	= (	isset($_REQUEST['page_content_id']) &&  ($_REQUEST['page_content_id'] > 0) ) ? trim($_REQUEST['page_content_id']) : 0;
$page_content		= new page_content($page_content_id);
if($show==1)
{
	?>
	<div class="expandSubContent">
	<table cellpadding="0" cellspacing="0" width="100%" class="expandDataTable">
		<tr class="">
			<td width="18%">Page Name</td><td>
				<?php
				echo functions::format_text_field($page_content->page_name);
				?>
			 </td>
		</tr>
		<tr class="">
			<td>Title</td><td>
				<?php
				echo functions::format_text_field($page_content->title);
				?>
			 </td>
		</tr>
		<tr class="">
			<td>Content</td><td>
				<?php
				echo functions::deformat_string($page_content->content);
				?>
			 </td>
		</tr>
		<tr class="">
			<td>Status</td>
			<td><div id='content_status_text'><?php echo $page_content->status == 'Y' ? 'Active' : 'Inactive'; ?></div></td>
		</tr>
		<tr>
			<td style="vertical-align:top;">Created On</td><td>
			<?php		
			echo functions::get_format_date($page_content->added_date, "d-m-Y");
			?>
			</td>
		</tr>
		<tr>
			<td style="vertical-align:top;">Modified On</td><td>
			<?php		
			echo functions::get_format_date($page_content->modified_date, "d-m-Y");
			?>
			</td>
		</tr>
	</table>
	</div>
	<?php 
}
?>
