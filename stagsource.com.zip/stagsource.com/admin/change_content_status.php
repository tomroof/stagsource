<?php
	/*********************************************************************************************
			Author 	: V V VIJESH
			Date	: 20-Nov-2010
			Purpose	: Change content status
	*********************************************************************************************/
	ob_start();
	session_start();
	include_once("../includes/config.php");

	$content_id	= $_REQUEST['content_id'];
	
	$status = content::update_status($content_id);
	echo ($status == 'Y') ? 1 : 0;
?>