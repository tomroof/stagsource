<?php 
   	
ob_start();
session_start();
include_once("../includes/config.php");

$show		= (	isset($_REQUEST['show']) &&  ($_REQUEST['show'] > 0) ) ? trim($_REQUEST['show']) : 0;
$content_id	= (	isset($_REQUEST['content_id']) &&  ($_REQUEST['content_id'] > 0) ) ? trim($_REQUEST['content_id']) : 0;
$content	= new content($content_id);
$category	=new category($content->category_id);
if($show==1)
{
	?>
	<div class="expandSubContent">
	<table cellpadding="0" cellspacing="0" width="100%" class="expandDataTable">
    
    <?php if($content->content_id  > 4) { ?> 
    <tr class="">
			<td width="18%">Category</td><td>
				<?php
				echo functions::deformat_string($category->name);
				?>
			 </td>
		</tr>
     <?php } ?>
		<tr class="">
			<td width="18%">Page name</td><td>
				<?php
				echo functions::deformat_string($content->name);
				?>
			 </td>
		</tr>
		<tr class="">
			<td>SEO URL</td><td>
				<?php
				echo functions::deformat_string($content->seo_url);
				?>
			 </td>
		</tr>
        
        <tr class="">
			<td>Title</td><td>
				<?php
				echo functions::deformat_string($content->title);
				?>
			 </td>
		</tr>
        
		<?php
			if($content->meta_description!='')
		{
			?>
		<tr class="">
			<td>Meta Description</td><td>
				<?php
				echo functions::deformat_string($content->meta_description);
				?>
			 </td>
		</tr><?php
		}
		if($content->meta_keywords!='')
		{
			?>
		<tr class="">
			<td>Meta Keywords</td><td>
				<?php
				echo functions::deformat_string($content->meta_keywords);
				?>
			 </td>
		</tr>
        <?php
		} 
		if($content->author!='')
		{
			?>

		<tr class="">
			<td>Author</td><td>
				<?php
				echo functions::deformat_string($content->author);
				?>
			 </td>
		</tr><?php 
		}
			?>
        

		<tr class="">
			<td>Content</td><td>
				<?php
				echo functions::deformat_string($content->content);
				?>
			 </td>
		</tr>
		<tr class="">
			<td>Status</td>
			<td><div id='content_status_text'><?php echo $content->status == 'Y' ? 'Active' : 'Inactive'; ?></div></td>
		</tr>
		<tr>
			<td style="vertical-align:top;">Created On</td><td>
			<?php		
			echo functions::get_format_date($content->added_date, "d-m-Y");
			?>
			</td>
		</tr>
		
	</table>
	</div>
	<?php 
}
?>
