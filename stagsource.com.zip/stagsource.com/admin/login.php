<?php

/*********************************************************************************************

Author 	: V V VIJESH

Date	: 16-June-2011

Purpose	: Validate admin login

*********************************************************************************************/

	ob_start();

	session_start();



	include_once("../includes/config.php");



	if (isset($_SESSION[ADMIN_ID]))

	{

		functions::redirect("index.php");

		exit;

	}

	

	$admin	= new admin();

	

	if (isset($_POST["login"]))

	{

		$admin->username	= functions::clean_string($_POST["username"]);

		$admin->password	= functions::clean_string($_POST["password"]);

		$validation			= new validation();

		$validation->check_blank($admin->username, "Username", "username");

		$validation->check_length($admin->username, 4, 25, "Username", "username");



		$validation->check_blank($admin->password, "Password", "password");

		$validation->check_length($admin->password, 5, 15, "Password", "password");



		if (!$validation->checkErrors())

		{

			if($admin->validate_login())

			{

				$_SESSION[ADMIN_ID]	= $admin->admin_id;

				functions::redirect("index.php");

				exit;

			} 

		}

		else

		{

			$admin->error	= $validation->getallerrors();

		}

	}

?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

    <head>

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

        <title><?php echo ADMIN_TITLE; ?></title>

        <link rel="shortcut icon" type="image/x-icon" href="<?php echo URI_ROOT; ?>image/favicon.ico">	

        <?php $theme = functions::deformat_string(ADMIN_THEME) . '/login.css'; ?>

        <link href="css/<?php echo $theme; ?>" rel="stylesheet" type="text/css" />

        <link rel="shortcut icon" type="image/x-icon" href="../images/favicon.ico">

		<script type="text/javascript" language="javascript" src="<?php echo ADMIN_JS_PATH; ?>validation.js"></script>



		<script type="text/javascript" language="javascript">

		<!--

			function validate_login()

			{

				var forms = document.login;



				if (!check_blank(forms.username, "Username cannot be empty!"))

				{	return false;	}

				if (!check_length(forms.username, 4, 25, "Username should be between 4 to 25 character!"))

				{	return false;	}

				if (!check_allowspecial(forms.username, "Username cannot contain special character!"))

				{	return false;	}



				if (!check_blank(forms.password, "Password cannot be empty!"))

				{	return false;	}

				if (!check_length(forms.password, 5, 15, "Password should be between 5 to 15 character!"))

				{	return false;	}



				return true;

			}

		//-->

		</script>

    </head>



    <body>

        <div id="loginWrapper">

            <div class="logo" style="padding-left:79px;"><img src="images/company-logo.png" alt="<?php echo functions::deformat_string(SITE_NAME);?>"  title="<?php echo functions::deformat_string(ADMIN_TITLE); ?>"/></div>

            <div class="loginBox">

                <div class="loginBoxTop">&nbsp;</div>

                <div class="loginBoxMiddle">

                    <span id="errmesg" class="infoMesg">

						<?php echo (strlen($admin->message) > 0 ? $admin->message : ""); ?>

                    </span>



                    <form id="login" name="login" method="post" action="<?php $_SERVER['PHP_SELF']; ?>">

                        <div class="forLabel">Username</div>

                        <div class="forInput">

                            <input type="text" id="username" name="username" maxlength="25" value="<?php echo stripslashes($admin->username); ?>" class="textbox" tabindex="1" />

                        </div>

						<?php if(!empty($admin->error["username"])) { ?>

                        <span id="errmesg" class="error">

                        	<?php echo $admin->error["username"]; ?>

                        </span>

						<?php } ?>

                        <div class="forLabel">Password</div>

                        <div class="forInput">

                        	<input type="password" id="password" name="password" maxlength="15" class="textbox" tabindex="2" />

                        </div>

						<?php if(!empty($admin->error["password"])) { ?>

                        <span id="errmesg" class="error">

                        	<?php echo $admin->error["password"]; ?>

                        </span>

						<?php } ?>

                        <div class="loginBtnArea">

	                       <input type="submit" id="login" name="login" value="Login" class="submit" tabindex="3" onclick="javascript:return validate_login();" />

                        </div>

					</form>

                </div>

                <div class="clear"></div>

                <div class="loginBoxBottom"></div> 

            </div>

        </div>

    </body>

</html>