<?php

/*********************************************************************************************

Author 	: Umesh C U

Date	: 15-Mar-2013

Purpose	: Register image category

*********************************************************************************************/

ob_start();

session_start();

include_once("../includes/config.php");



// Check the admin user is loged in or not

if (!isset($_SESSION[ADMIN_ID]))

{

	functions::redirect("login.php");

	exit;

}



$planning_id			= (isset($_REQUEST['planning_id']) &&  $_REQUEST['planning_id']) > 0 ? $_REQUEST['planning_id'] : 0;

$planning_gallery_id		= (isset($_REQUEST['planning_gallery_id']) &&  $_REQUEST['planning_gallery_id']) > 0 ? $_REQUEST['planning_gallery_id'] : 0;



$planning_gallery 			= new planning_gallery($planning_gallery_id);



$planning 			= new planning($planning_id);



if($planning->planning_id == 0)

{

	functions::redirect("manage_planning.php");

	exit;

}



if($planning_gallery->planning_gallery_id == 0)

{

	functions::redirect("manage_planning_gallery.php?planning_id=".$planning_id);

	exit;

}



$planning_gallery 		= new planning_gallery($planning_gallery_id);

$planning_gallery_id	= $planning_gallery->planning_gallery_id;

$image_name				= $planning_gallery->image_name;



if($planning_gallery_id == 0)

{

	functions::redirect("manage_planning_gallery.php?planning_id=".$planning_id);

	exit;

}



$page_title = 'Edit Image';



$default_page_title		= 'Manage Image';

$default_page_uri		= 'manage_planning_gallery.php?planning_id='.$planning_id;



// Cancel button action starts here

if(isset($_POST['cancel']))	

{

	functions::redirect($default_page_uri);

}



// Set template details

$template 				= new template();

$template->type			= 'ADMIN';

$template->left_menu	= true;

$template->admin_id		= $_SESSION[ADMIN_ID];

//$template->title		= $page_title;

$template->js			= '

<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>

<script type="text/javascript" language="javascript">

function validate_form()

{

	var forms = document.register_PLANNING_GALLERY;

	

	/*if (!check_blank(forms.title, "Title is required!"))

	{	return false;	}*/

	

	

	if (!check_blank(forms.image_name, "Image is required!"))

	{	return false;	}

		

	return true;

}



</script>';

$template->heading();



// Save button action starts here

if(isset($_POST['save']))

{

	$planning_gallery						= new planning_gallery();

	$planning_gallery->planning_id				= $planning_id;

	$planning_gallery->planning_gallery_id		= $planning_gallery_id;

	$planning_gallery->title				= functions::clean_string($_POST['title']);

	$planning_gallery->description			= functions::clean_string($_POST['description']);

	$planning_gallery->image_name			= functions::clean_string($_POST['image_name']);

		

	$validation							= new validation();

	//$validation->check_blank($planning_gallery->title, "Title", "title");



	if (!$validation->checkErrors())

	{

		if($planning_gallery->save())

		{

			if($planning_gallery->image_name != $image_name || !file_exists(DIR_PLANNING_GALLERY.'resize_'.$planning_gallery->image_name))

			{

				$size_array	= getimagesize(DIR_PLANNING_GALLERY.$planning_gallery->image_name);

			if($size_array[0] < $size_array[1])

			{

				$orientation	= 1;	

			}

			else if($size_array[0] > $size_array[1])

			{

				$orientation	= 2;

			}

			else

			{

				$orientation	= 3;	

			}

		    	//$imageLib = new imageLib(DIR_PROPERTY_GALLERY.$planning_gallery->image_name);

				//$imageLib->resizeImage(PROPERTY_GALLERY_MAX_WIDTH, PROPERTY_GALLERY_MAX_HEIGHT, $orientation3); //$height,$orientation(0-exact, 1-portrait, 2- landscape, 3-auto, 4-crop)

				//$imageLib->saveImage(DIR_PROPERTY_GALLERY.'resize_'.$image_name, 100);

			}

			

			//$planning_gallery->image_name			= $image_name;

			

			if($planning_gallery_id == 0)

			{

				$planning_gallery->planning_gallery_id	= 0;				

				$planning_gallery->category_name		= '';

			}

			

			$json_var 	= '{"title":"Success", "text":"'.$planning_gallery->message.'","type":"success","width":"100%","url":"manage_planning_gallery.php?planning_id='.$planning_id.'"}';

			$notify 	= new notify();

			$notify->show_message($json_var); 

		}

	}

	else

	{

		$planning_gallery->error	= $validation->getallerrors();

	}

}

else if (!isset($_POST["save"]))

{

	$planning_gallery	= new planning_gallery($planning_gallery_id);

	

}



?>


 <link rel="stylesheet" type="text/css" href="<?php echo URI_LIBRARY ?>image-upload/css/common.css" media="screen" />
<!--<script src="<?php echo URI_LIBRARY ?>jquery/jquery-min.js"> </script>-->



<link rel="stylesheet" href="<?php echo URI_LIBRARY; ?>colorbox/colorbox.css" />

<script src="<?php echo URI_LIBRARY; ?>colorbox/jquery.colorbox.js"></script>









<!--<script type="text/javascript" src="<?php echo URI_LIBRARY;?>fancy/lib/jquery.mousewheel-3.0.6.pack.js"></script>

<script type="text/javascript" src="<?php echo URI_LIBRARY;?>fancy/source/jquery.fancybox.js?v=2.1.5"></script>

<link rel="stylesheet" type="text/css" href="<?php echo URI_LIBRARY;?>fancy/source/jquery.fancybox.css?v=2.1.5" media="screen" />-->



<!--<link rel="stylesheet" href="<?php echo URI_LIBRARY; ?>imageareaselect/css/imageareaselect-default.css">

<link rel="stylesheet" href="<?php echo URI_LIBRARY; ?>imageareaselect/css/imageareaselect-animated.css">

<script src="<?php echo URI_LIBRARY ?>imageareaselect/scripts/jquery.imgareaselect.js"></script>

<script src="<?php echo URI_LIBRARY ?>imageareaselect/scripts/jquery.imgareaselect.min.js"></script>

<script src="<?php echo URI_LIBRARY ?>imageareaselect/scripts/jquery.imgareaselect.pack.js"></script>-->





<script>



$(document).ready(function() {

	

	$('#popupBoxClose, #popupBoxClose1').click( function() {			



		unloadPopupBox();

		//window.location.reload(true);



	});



	function unloadPopupBox() {	// TO Unload the Popupbox

		

		$('#popup_box, #popup_box1').fadeOut("fast");

		

	

		$(".main, .rightBlock, .content").css({ // this is just for style		

	

			"opacity": "1"  

	

		}); 

		

		

		var kk	=  '<?php echo URI_NEWS ?>'+'thumb_'+$('#image_name').val();

  		//$('#thumb_id1').attr('src','');

   		//$('#thumb_id1').attr('src',kk+'?'+Math.random());

        //$('#thumb_id1').show();

	}



		

	$('.rightBlock, .main, .content').click(function(){

		$("#popup_box, #popup_box1").fadeOut("fast");

		$(".main, .rightBlock, .content").css({ // this is just for style

			"opacity": "1" 

		});

	

	});

	

	

	$('#upload').click(function() {

	    var id	= '<?php echo $planning_id ?>';

		var planning_gallery_id	= $('#planning_gallery_id').val();

		

		//alert(planning_gallery_id);

		

		//$('#upload').colorbox({href:'popup_upload_single.php?folder=planning_gallery&id='+planning_gallery_id+'&edit=true'});

		

		$.ajax( {

	

			type: "POST",

	

			cache: false,

	

			url: "popup_upload_single.php?folder=planning_gallery&id="+planning_gallery_id+"&edit=1",

			//url: "popup_upload_single.php?folder=news&type=news&id="+id+"&news_temp_id="+news_temp_id,

	

			success: function (data)

			{

				$("#inline_content1").html(data);				

				$.colorbox({href:'#inline_content1', inline:true});	

			}

			

			

	

		});

		

	});

	

	

	$('#crop').click(function() {

		

		var thumb_width		= '<?php echo PLANNING_GALLERY_THUMB_WIDTH ?>';

		var thumb_height	= '<?php echo PLANNING_GALLERY_THUMB_HEIGHT ?>';

		var planning_gallery_id			= $('#planning_gallery_id').val();

		var img_name		= $('#image_name').val();

	

		$.ajax(

	

		{

	

			type: "POST",

	

			cache: false,

	

			url: "popup_crop_image.php?folder=planning_gallery&id="+planning_gallery_id+"&thumb_width="+thumb_width+"&thumb_height="+thumb_height+"&img="+$('#image_name').val(),

	

			success: function (data)

	

			{				

				$("#inline_content").html(data);		

				$.colorbox({href:'#inline_content', inline:true});

			}

	

		});

	

	});

		

});







</script>



<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">

	<tr>

		<td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>

		<td class="topRepeat">&nbsp;</td>

		<td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>

	</tr>

	<tr>

		<td rowspan="2" class="leftRepeat">&nbsp;</td>

		<td bgcolor="#FFFFFF"><div class="contentHeader">

				<div class="pageTitle">

					<?php

					echo functions::deformat_string($page_title);

				?>

				</div>

				<div class="contentSublinks txtBold"> <img src="images/manage-image.png" alt="<?php echo functions::deformat_string($default_page_title); ?>" title="<?php echo functions::deformat_string($default_page_title); ?>" width="24" height="24" class="imgBlock" /> <a href="<?php echo functions::deformat_string($default_page_uri); ?>"><?php echo functions::deformat_string($default_page_title); ?></a> </div>

			</div>

			<?php if(!empty($planning_gallery->message)) { ?>

			<span class="<?php echo $planning_gallery->warning ? 'warningMesg' : 'infoMesg'; ?>  formPageWidth"> <?php echo $planning_gallery->message; ?> </span>

			<?php } ?>

			<div class="spacer"></div></td>

		<td rowspan="2" class="rightRepeat">&nbsp;</td>

	</tr>

	<tr>

		<td bgcolor="#FFFFFF"><form name="register_PLANNING_GALLERY" id="register_PLANNING_GALLERY" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">

				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="form">

					<tr>

						<td width="18%">Title</td>

						<td width="88%"><input type="text" id="title" name="title" value="<?php echo functions::format_text_field($planning_gallery->title); ?>" class="textbox" maxlength="50" tabindex="1" />

							<div class="txtTheme noLineHeight note"><span class="txtRed">*Note: </span>Maximum 50 characters allowed.</div>

							<?php if(!empty($planning_gallery->error["title"])) { ?>

							<span id="errmesg" class="error"> <?php echo $planning_gallery->error["title"]; ?></span>

							<?php } ?>

							<div class="spacer"></div></td>

					</tr>

                    

                   

					

					<!--<tr>

						<td width="18%">Description</td>

						<td width="88%"><textarea id="description" name="description" cols="35" rows="5" class="textarea" tabindex="2" ><?php echo functions::format_text_field($planning_gallery->description); ?> </textarea>

							<?php if(!empty($planning_gallery->error["description"])) { ?>

							<span id="errmesg" class="error"> <?php echo $planning_gallery->error["description"]; ?></span>

							<?php } ?>

							<div class="spacer"></div></td>

					</tr>-->

                    

                    <tr>

						<td width="18%">Image<span class="txtRed">*</span></td>

						<td width="88%"><table width="100%" border="0" cellpadding="0" cellspacing="0" >

								<tbody>

									<tr>

										<td width="100" >

										     <div class="link1" style="float:left;"><ul><li><a style="cursor:pointer;text-align:center; " id="upload" class="submit" tabindex="4">Upload</a></li></ul></div>

									    </td>

										

										<td width="140">

										<!--<img src="images/edit-crop-image.png" alt="Create Thumb Image" title="Create Thumb Image" width="15" height="16" vspace="top"/>-->

										<div class="link1" id="crop1" <?php if(($planning_gallery->planning_gallery_id == 0 || $planning_gallery->planning_gallery_id == '') || ($planning_gallery->planning_gallery_id > 0 && $planning_gallery->image_name =='')) { echo 'style="display:none;"'; } ?> style="float:left;"><ul><li><a style="cursor:pointer;width:auto;text-align:center;" id="crop" tabindex="4" class="submit" >Create Thumbnail</a></li></ul></div>

										

																				

										</td>

										

										<td>

										   

											<img src="<?php echo URI_PLANNING_GALLERY . 'thumb_'. $planning_gallery->image_name; ?>?123" border="0" id="thumb_id1" <?php if(!file_exists(DIR_PLANNING_GALLERY.'thumb_'. $planning_gallery->image_name)) { echo 'style="display:none;"'; } ?> width="<?php echo PLANNING_GALLERY_THUMB_WIDTH ?>" height="<?php echo PLANNING_GALLERY_THUMB_HEIGHT ?>"/>

										 

											

										</td>

									</tr>

									<tr>

										<td style="padding-left: 20px;" width="155" align="left"></td>

									</tr>

								</tbody>

							</table>

							<?php if(!empty($planning_gallery->error["image_name"])) { ?>

							<span id="errmesg" class="error"> <?php echo $planning_gallery->error["image_name"]; ?></span>

							<?php } ?>

							

							<div class="spacer"></div></td>

					</tr>

					                                      

                    

					<tr>

						<td></td>

						<td ><input type="submit" id="button" name="save" value="Save" class="submit" title="Save" tabindex="3" onclick="javascript:return validate_form();" />

							<input type="submit" id="cancel" name="cancel" value="Cancel" class="submit" title="Cancel" tabindex="4" />

							<div class="spacer"></div></td>

					</tr>

					<tr>

						<td colspan="2" class="txtTheme required"><span class="txtRed">*</span> Required fields</td>

					</tr>

				</table>

				<input type="hidden" id="planning_id" name="planning_id" value="<?php echo $planning_id; ?>" />

				<input type="hidden" id="planning_gallery_id" name="planning_gallery_id" value="<?php echo $planning_gallery_id; ?>" />

                <input type="hidden" id="property_temp_id" name="property_temp_id" value="0" />

				<input type="hidden" id="image_name" name="image_name" value="<?php echo functions::format_text_field($planning_gallery->image_name); ?>" />

               

			</form></td>

	</tr>

	<tr>

		<td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>

		<td class="bottomRepeat">&nbsp;</td>

		<td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>

	</tr>

</table>

<?php 

	$template->footer();

?>



<div id="popup_box" class="popup" style="border: 4px solid gray; padding: 10px; overflow:none; ">	 



	<div id="resultcontent"></div>



	<div id="messagecontent"></div>

	<a id="popupBoxClose"><strong>CLOSE</strong></a>	



</div>



<div id="popup_box1" class="popup" style=" border: 4px solid gray; padding: 10px; overflow:none;display:none;" >	 <!-- 1026, 510overflow:scroll; -->



	<div id="resultcontent1"></div>



	<div id="messagecontent1"></div>

	<a id="popupBoxClose1"><strong>CLOSE</strong></a>	



</div>





<!--<link rel="stylesheet" href="<?php echo URI_LIBRARY ?>image-upload/css/bootstrap.min.css">-->

<!--<link rel="stylesheet" href="<?php echo URI_LIBRARY ?>image-upload/css/blueimp-gallery.min.css">

<link rel="stylesheet" href="<?php echo URI_LIBRARY ?>image-upload/css/jquery.fileupload-ui.css">-->



<!-- The blueimp Gallery widget -->

<div id="blueimp-gallery" class="blueimp-gallery blueimp-gallery-controls" data-filter=":even" style="display:none">

    <div class="slides"></div>

    <h3 class="title"></h3>

    <!--<a class="prev">‹</a>-->

	<a class="prev">&lsaquo;</a>

   <!-- <a class="next">›</a>-->

    <a class="next">&rsaquo;</a>

    <!--<a class="close">×</a>-->

	<a class="close">&times</a>

    <a class="play-pause"></a>

    <ol class="indicator"></ol>

</div>





<div style="display:none" >

			<div id='inline_content' style="background:#fff;  padding:-10px; position:relative; width:1024px !important; overflow:hidden;">

				

			</div>

		</div>



<div style="display:none" id="1a" >

			<div id='inline_content1' style="padding: 10px; background:#fff; height:300px; width:500px">

				

			</div>

		</div>





<script src="<?php echo URI_LIBRARY ?>image-upload/js/upload_image.js"> </script>

