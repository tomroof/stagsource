<?php 
   	
ob_start();
session_start();
include_once("../includes/config.php");

$show	= (	isset($_REQUEST['show']) &&  ($_REQUEST['show'] > 0) ) ? trim($_REQUEST['show']) : 0;
$content_option = new content_option();

$content_option_id=$_GET['content_option_id'];
$content_option_details	= new content_option($content_option_id);

if($show==1)
{
?>
<div class="expandSubContent">
<table cellpadding="0" cellspacing="0" width="100%" class="expandDataTable">
<tr><td style="vertical-align:top;" width="14%">Title</td><td><?php echo functions::format_text_field($content_option_details->title);?></td></tr>
<tr><td style="vertical-align:top;">Description</td><td><?php echo functions::format_text_field($content_option_details->description);?></td></tr>
<?php
if($content_option_details->image_name!='' && file_exists(DIR_CONTENT_OPTION.$content_option_details->image_name))
{
	?>
    <tr><td style="vertical-align:top;">Logo</td><td><?php echo '<img src="image_resize.php?image='.$content_option_details->image_name.'&dir=content_option&width=150&height=120"    border="0" />';?></td></tr>
<?php
}

?>


<tr><td>Date </td><td><?php echo   date('d-m-Y',strtotime($content_option_details->added_date));?></td></tr>

<tr class=""><td>Status</td><td><div id='content_status_text'><?php echo $content_option_details->status == 'Y' ? 'Active' : 'Inactive'; ?></div></td></tr>
</table>
</div>
<?php 
}
?>
