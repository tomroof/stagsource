<?php
/*********************************************************************************************
Author 	: V V VIJESH
Date	: 14-April-2011
Purpose	: Register page content
*********************************************************************************************/
ob_start();
session_start();

include_once("../includes/config.php");
//include_once("../library/fckeditor/fckeditor.php");

// Check the admin user is loged in or not
if (!isset($_SESSION[ADMIN_ID]))
{
	functions::redirect("login.php");
	exit;
}
$page_content_id	= (isset($_REQUEST['page_content_id']) &&  $_REQUEST['page_content_id']) > 0 ? $_REQUEST['page_content_id'] : 0;

if($page_content_id > 0)
{
	$page_title = 'Edit Page Content';
}
else
{
	$page_title = 'Add Page Content';
}

$default_page_title		= 'Manage Page Content';
$default_page_uri		= 'manage_page_content.php';
// Cancel button action starts here
if(isset($_POST['cancel']))	
{
	functions::redirect($default_page_uri);
}

$page_content_length 			= 1000;
// Set template details
$template 				= new template();
$template->type			= 'ADMIN';
$template->left_menu	= true;
$template->admin_id		= $_SESSION[ADMIN_ID];
//$template->title		= $page_title;
$template->js			= '
<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'validation.js"></script>
<script type="text/javascript" language="javascript" src="' . ADMIN_JS_PATH . 'page_content.js"></script>
<script type="text/javascript" language="javascript">
	function validate_form()
	{
		var forms = document.register_page_content;
		if (!check_blank(forms.page_name, "Page name is required!"))
		{	return false;	}
	/*	if(forms.page_content_id.value!=9)
		{
		if (!check_blank(forms.menu_name, "Menu name is required!"))
		{	return false;	}
		}*/
		
		if (!check_blank(forms.title, "Title is required!"))
		{	return false;	}
		if (!check_editor_content("content","Content is required"))
		{	return false;	}
		return true;
	}
</script>';
$template->css ='';	

$template->heading();
// Save button action starts here
if(isset($_POST['save']))
{
	$page_content					= new page_content();
	$page_content->page_content_id	= $page_content_id;
	$page_content->page_name		= functions::clean_string($_POST['page_name']);
	//$page_content->menu_name		= functions::clean_string($_POST['menu_name']);
	$page_content->title			= functions::clean_string($_POST['title']);
	$page_content->content			= functions::clean_string($_POST['content']);
	
	$validation		= new validation();
	$validation->check_blank($page_content->page_name, "Page Name", "page_name");
	$validation->check_blank($page_content->title, "Title", "title");
	$validation->check_editor_content($page_content->content, "Content", "content");
	//if($page_content->page_content_id!=9)
	//$validation->check_blank($page_content->menu_name, "Menu Name", "menu_name");
	
	if (!$validation->checkErrors())
	{
		if($page_content->save())
		{
			if($page_content_id == 0)
			{
				$page_content->page_content_id	= 0;
				$page_content->page_name		= '';
				$page_content->title			= '';
				$page_content->content			= '';
			}
		}
	}
	else
	{
		$page_content->error	= $validation->getallerrors();
		$page_content->warning				 =true;
	}
		if(!$page_content->warning)
		{
		  	$json_var 	= '{"title":"Success", "text":"'.$page_content->message.'","type":"success","width":"100%","url":"manage_page_content.php"}';
		  	$notify 	= new notify();
		  	$notify->show_message($json_var);
		}
		if($page_content->warning)
		{
		  	$json_var 	= '{"title":"Error", "text":"'.$page_content->message.'","type":"error","width":"100%"}';
		  	$notify 	= new notify();
		  	$notify->show_message($json_var);
		}
}
else if (!isset($_POST["save"]))
{
	$page_content	= new page_content($page_content_id);
}
?>
<script type="text/javascript" src="<?php echo URI_LIBRARY; ?>fckeditor/fckeditor.js"></script>
<script language="javascript" type="text/javascript">
window.onload = function()
{
	var oFCKeditor			= new FCKeditor( 'content' );
	oFCKeditor.BasePath		= "<?php echo URI_LIBRARY.'fckeditor/'; ?>";
	oFCKeditor.Height		= "500" ;
	oFCKeditor.Width		= "710" ;
	oFCKeditor.Config['SkinPath'] = 'skins/silver/' ;
	oFCKeditor.ToolbarSet	= "Cms"; //Cms
	oFCKeditor.ReplaceTextarea() ;
}
</script>
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="whiteBox">
	<tr>
		<td width="30" align="right" valign="bottom" class="cornerTopLeft"><img src="images/content-box-top-left.png" alt="box corner" width="30" height="30" /></td>
		<td class="topRepeat">&nbsp;</td>
		<td width="30" align="left" valign="bottom" class="cornerTopRight"><img src="images/content-box-top-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
	<tr>
		<td rowspan="2" class="leftRepeat">&nbsp;</td>
		<td bgcolor="#FFFFFF">
			<div class="contentHeader">
				<div class="pageTitle">
					<?php 
					if($page_content->page_content_id > 0)
					{
						$page_title = 'Edit Page Content';
					}
					echo functions::deformat_string($page_title);
					?>
				</div>
				<div class="contentSublinks txtBold"> <img src="images/manage-content.png" alt="<?php echo functions::deformat_string($default_page_title); ?>" title="<?php echo functions::deformat_string($default_page_title); ?>" width="24" height="24" class="imgBlock" /> <a href="<?php echo $default_page_uri; ?>"><?php echo functions::deformat_string($default_page_title); ?></a> </div>
			</div>
			<?php if(!empty($page_content->message)) { ?>
			<span class="<?php echo $page_content->warning ? 'warningMesg' : 'infoMesg'; ?>  formPageWidth"> <?php echo $page_content->message; ?> </span>
			<?php } ?>
			<div class="spacer"></div></td>
		<td rowspan="2" class="rightRepeat">&nbsp;</td>
	</tr>
	<tr>
		<td bgcolor="#FFFFFF"><form name="register_page_content" id="register_page_content" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data" >
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="form">
					<tr>
						<td width="18%" >Page Name<span class="txtRed">*</span></td>
						<td  width="88%"><input type="text" id="page_name" name="page_name" value="<?php echo functions::format_text_field($page_content->page_name); ?>" class="textbox" maxlength="50" tabindex="2" />
							<div class="txtTheme noLineHeight note"><span class="txtRed">*E.g.; </span>index.html</div>
							<?php if(!empty($page_content->error["page_name"])) { ?>
							<span id="errmesg" class="error"> <?php echo $page_content->error["page_name"]; ?></span>
							<?php } ?>
							<div class="spacer"></div></td>
					</tr>
                    
                        <?php
                       if($page_content_id!=9)
					 /*  {
					 
                       <tr>
						<td width="18%" >Menu Name
					   <span class="txtRed">*</span>
					 </td>
						<td  width="88%"><input type="text" id="menu_name" name="menu_name" value="<?php echo functions::format_text_field($page_content->menu_name); ?>" class="textbox" maxlength="50" tabindex="2" />
							<div class="txtTheme noLineHeight note"><span class="txtRed">*E.g.; </span>Home</div>
							<?php if(!empty($page_content->error["menu_name"])) { ?>
							<span id="errmesg" class="error"> <?php echo $page_content->error["menu_name"]; ?></span>
							<?php } ?>
							<div class="spacer"></div></td>
					</tr>
                  
					   }*/?>
					<tr>
						<td>Title<span class="txtRed">*</span></td>
						<td><input type="text" id="title" name="title" value="<?php echo functions::format_text_field($page_content->title); ?>" class="textbox" maxlength="100" tabindex="2" />
						<div class="txtTheme noLineHeight note"><span class="txtRed">*Note : </span>Maximum 40 characters allowed.</div>
							<?php if(!empty($page_content->error["title"])) { ?>
							<span id="errmesg" class="error"> <?php echo $page_content->error["title"]; ?></span>
							<?php } ?>
							<div class="spacer"></div></td>
					</tr>
					<tr>
						<td>Content<span class="txtRed">*</span></td>
						<td>
						<textarea name="content" id="content" cols="85" rows="30" tabindex="5" ><?php echo functions::format_text_field($page_content->content); ?></textarea>
						<?php
						if(!empty($page_content->error['content'])) { ?><span id="errmesg" class="error"><?php echo $page_content->error['content']; ?></span><?php } ?>  		      
						<div class="spacer"></div>
						</td>
					  </tr> 
					  <tr>
						<td></td>
						<td ><input type="submit" id="button" name="save" value="Save" class="submit" title="Save" tabindex="5" onclick="javascript:return validate_form();" />
							<input type="submit" id="cancel" name="cancel" value="Cancel" class="submit" title="Cancel" tabindex="6" />
							
							<div class="spacer"></div></td>
					</tr>
					<tr>
						<td colspan="2" class="txtTheme required"><span class="txtRed">*</span> Required fields</td>
					</tr>
				</table>
				<input type="hidden" id="page_content_id" name="page_content_id" value="<?php echo $page_content->page_content_id; ?>" />
			</form></td>
	</tr>
	<tr>
		<td align="right" valign="top" class="cornerBottomLeft"><img src="images/content-box-bottom-left.png" alt="box corner" width="30" height="30" /></td>
		<td class="bottomRepeat">&nbsp;</td>
		<td align="left" valign="top" class="cornerBottomRight"><img src="images/content-box-bottom-right.png" alt="box corner" width="30" height="30" /></td>
	</tr>
</table>
<?php 
	$template->footer();
?>
