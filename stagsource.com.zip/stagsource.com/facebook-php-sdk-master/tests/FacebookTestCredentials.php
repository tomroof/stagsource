<?php

class FacebookTestCredentials {

  /**
   * These must be filled out with valid Facebook app details for the tests to
   * run.
   */
  public static $appId = '';
  public static $appSecret = '';
  public static $appToken = '';

}

